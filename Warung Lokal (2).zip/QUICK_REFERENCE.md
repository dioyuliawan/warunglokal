# ⚡ QUICK REFERENCE - WARLOK

Panduan cepat untuk tugas-tugas umum development.

---

## 🆕 Menambah Warung Baru

```bash
# 1. Copy template
cp src/app/data/warungs/warung-bu-tini.ts src/app/data/warungs/warung-pak-joko.ts

# 2. Edit file baru, ubah:
- WARUNG_BU_TINI → WARUNG_PAK_JOKO
- id: "1" → id: "7"
- w1_p1 → w7_p1

# 3. Import di src/app/data/warungs/index.ts
```

---

## 🛒 Akses Cart di Screen

```tsx
import { useCart } from "@/context/CartContext";

function MyScreen() {
  const { items, addItem, removeItem, getTotalPrice } = useCart();
  
  return (
    <div>
      <p>Total: Rp {getTotalPrice().toLocaleString()}</p>
      <p>Items: {items.length}</p>
    </div>
  );
}
```

---

## 💰 Format Harga

```tsx
import { formatPrice, formatPriceWithUnit } from "@/utils/format";

// Simple
formatPrice(15000)  // "Rp 15.000"

// Dengan unit
formatPriceWithUnit(15000, "porsi")  // "Rp 15.000/porsi"
```

---

## 🎨 Gunakan Warna Brand

```tsx
import { COLORS } from "@/constants/colors";

// Dalam className Tailwind
className="bg-[#1B5E20]"  // ❌ Jangan hardcode

// Gunakan CSS variable atau konstanta
className="bg-primary"  // ✅ Better

// Atau dalam style inline
style={{ backgroundColor: COLORS.primary.main }}  // ✅ Good
```

---

## 🔍 Cari Warung/Produk

```tsx
import { searchWarungsAndProducts } from "@/data/warungs";

const results = searchWarungsAndProducts("ayam");
console.log(results.warungs);   // Array warung yang match
console.log(results.products);  // Array produk yang match
```

---

## 📦 Tampilkan Kartu Warung

```tsx
import { WarungCard } from "@/components/shared/WarungCard";

<WarungCard 
  warung={warungData}
  onClick={() => navigate(`/warung/${warungData.id}`)}
  variant="list"  // "default" | "compact" | "list"
  showDistance
  showRating
  showStatus
/>
```

---

## 🍕 Tampilkan Kartu Produk

```tsx
import { ProductCard } from "@/components/shared/ProductCard";

<ProductCard 
  product={productData}
  onClick={() => navigate(`/product/${productData.id}`)}
  onAddToCart={(p) => addItem(p, 1)}
  showAddButton
  variant="grid"  // "grid" | "list"
/>
```

---

## 🚫 Empty State

```tsx
import { EmptyState } from "@/components/shared/EmptyState";
import { ShoppingBag } from "lucide-react";

<EmptyState 
  icon={<ShoppingBag size={64} />}
  title="Keranjang masih kosong"
  message="Yuk, mulai belanja dari warung terdekatmu"
  actionLabel="Mulai Belanja"
  onAction={() => navigate("/home")}
/>
```

---

## 🔐 Validasi Input

```tsx
import { 
  isValidEmail, 
  validatePassword, 
  validatePrice 
} from "@/utils/validation";

// Email
if (!isValidEmail(email)) {
  alert("Email tidak valid");
}

// Password
const result = validatePassword(password);
if (!result.isValid) {
  alert(result.error);
}

// Harga
const priceCheck = validatePrice(price);
if (!priceCheck.isValid) {
  alert(priceCheck.error);
}
```

---

## ⏱️ Debounce Search

```tsx
import { useState } from "react";
import { useDebounce } from "@/hooks/useDebounce";

function SearchScreen() {
  const [query, setQuery] = useState("");
  const debouncedQuery = useDebounce(query, 500);
  
  // debouncedQuery hanya update 500ms setelah user berhenti mengetik
  useEffect(() => {
    // Lakukan search
    const results = searchWarungsAndProducts(debouncedQuery);
  }, [debouncedQuery]);
  
  return <input value={query} onChange={(e) => setQuery(e.target.value)} />;
}
```

---

## 💾 LocalStorage

```tsx
import { useLocalStorage } from "@/hooks/useLocalStorage";

function MyScreen() {
  const [favorites, setFavorites] = useLocalStorage<string[]>('favorites', []);
  
  const addFavorite = (id: string) => {
    setFavorites([...favorites, id]);  // Otomatis tersimpan
  };
  
  return <div>Favorites: {favorites.length}</div>;
}
```

---

## 🎯 Navigation Paths

```tsx
import { NAVIGATION_PATHS } from "@/constants/app";

// Customer
navigate(NAVIGATION_PATHS.customer.home);       // "/home"
navigate(NAVIGATION_PATHS.customer.cart);       // "/cart"
navigate(NAVIGATION_PATHS.customer.orders);     // "/orders"

// Mitra
navigate(NAVIGATION_PATHS.mitra.dashboard);     // "/mitra/dashboard"
navigate(NAVIGATION_PATHS.mitra.products);      // "/mitra/products"

// Admin
navigate(NAVIGATION_PATHS.admin.dashboard);     // "/admin/dashboard"
```

---

## 📊 Get Data Warung

```tsx
import { 
  getWarungById, 
  getProductsByWarungId,
  getOpenWarungs 
} from "@/data/warungs";

// Get warung by ID
const warung = getWarungById("1");

// Get produk dari warung (hanya aktif)
const products = getProductsByWarungId("1");

// Get semua warung yang buka
const openWarungs = getOpenWarungs();
```

---

## 📅 Format Tanggal & Waktu

```tsx
import { 
  formatDate, 
  formatTime, 
  formatRelativeTime 
} from "@/utils/format";

const now = new Date();

formatDate(now);           // "24 Mei 2024"
formatTime(now);           // "14:30"
formatRelativeTime(now);   // "2 jam yang lalu"
```

---

## 🎨 Tailwind Custom Classes

```tsx
// Primary Button
<button className="px-8 py-3 bg-[#1B5E20] text-white rounded-full">
  Konfirmasi
</button>

// Secondary Button (Outlined)
<button className="px-8 py-3 border-2 border-[#1B5E20] text-[#1B5E20] rounded-full">
  Batal
</button>

// Card
<div className="bg-white rounded-2xl p-4 shadow-sm">
  Content
</div>

// Badge
<span className="px-2 py-0.5 bg-[#F1F8E9] text-[#1B5E20] text-xs font-semibold rounded-full">
  Buka
</span>
```

---

## 🔄 Update Product Stock

```tsx
// Edit file: src/app/data/warungs/warung-bu-tini.ts

export const PRODUCTS_WARUNG_BU_TINI: Product[] = [
  {
    id: "w1_p1",
    // ...
    stock: 50,        // Ubah stock di sini
    active: true,     // Ubah ke false jika stok habis permanent
  }
];
```

---

## 🚫 Menonaktifkan Produk

```tsx
// Set active: false dan stock: 0

{
  id: "w1_p6",
  name: "Kepala Ayam",
  stock: 0,           // ← Set ke 0
  active: false,      // ← Set ke false
  // ...
}
```

Produk akan otomatis tampil dengan overlay "Stok Habis" dan tidak bisa diklik.

---

## 🏪 Update Status Warung

```tsx
// Edit file warung

export const WARUNG_TOKO_MAJU: WarungData = {
  // ...
  status: "TUTUP — Buka besok 07.00",
  statusColor: "red",     // "green" | "red" | "orange"
  isOpen: false,          // true = buka, false = tutup
  openTime: "07.00",
  closeTime: "21.00",
};
```

---

## 🎯 Generate Order ID

```tsx
import { generateOrderId } from "@/utils/format";

const orderId = generateOrderId();  // "WLK-2024-0042"
```

---

## 🖼️ Image Handling

```tsx
import { ImageWithFallback } from "@/components/figma/ImageWithFallback";

// Gunakan ImageWithFallback instead of <img>
<ImageWithFallback 
  src={product.image}
  alt={product.name}
  className="w-full h-full object-cover"
/>
```

---

## 🎛️ App Config

```tsx
import { APP_CONFIG } from "@/constants/app";

console.log(APP_CONFIG.name);           // "Warlok — Warung Lokal"
console.log(APP_CONFIG.version);        // "1.0.0"
console.log(APP_CONFIG.adminPassword);  // "admin2024"
```

---

## 🚚 Delivery Costs

```tsx
import { DELIVERY_COSTS } from "@/constants/app";

const cost = DELIVERY_COSTS.antarSendiri;   // 5000
const cost2 = DELIVERY_COSTS.ojekOnline;    // 12000
const cost3 = DELIVERY_COSTS.ambilSendiri;  // 0
```

---

## 📱 Icon Usage

```tsx
import { ShoppingCart, Heart, MapPin, Star } from "lucide-react";

<ShoppingCart size={24} className="text-[#1B5E20]" />
<Heart size={20} className="text-red-500 fill-red-500" />
<MapPin size={16} className="text-gray-600" />
<Star size={14} className="text-[#FF6F00] fill-[#FF6F00]" />
```

---

## 🔥 Common Patterns

### Loading State
```tsx
const [loading, setLoading] = useState(false);

{loading ? (
  <div className="flex justify-center p-8">
    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#1B5E20]"></div>
  </div>
) : (
  <YourContent />
)}
```

### Conditional Rendering
```tsx
{items.length === 0 ? (
  <EmptyState 
    icon={<ShoppingBag size={64} />}
    title="Keranjang kosong"
  />
) : (
  <CartItems items={items} />
)}
```

### List Rendering
```tsx
{products.map((product) => (
  <ProductCard 
    key={product.id}  // ← PENTING: unique key
    product={product}
    onClick={() => navigate(`/product/${product.id}`)}
  />
))}
```

---

## 🆘 Common Errors & Solutions

### Error: "warungId undefined"
✅ Pastikan product memiliki field `warungId`

### Error: "Cannot read property 'name' of undefined"
✅ Tambahkan optional chaining: `warung?.name`

### Cart tidak update
✅ Gunakan `useCart()` hook, bukan state lokal

### Image tidak muncul
✅ Gunakan `ImageWithFallback` component
✅ Cek URL image valid

### Warna tidak sesuai
✅ Gunakan konstanta dari `COLORS` atau CSS variables

---

**Last updated: 2024**
