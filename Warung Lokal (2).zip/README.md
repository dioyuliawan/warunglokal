
  # Warung Lokal

  This is a code bundle for Warung Lokal. The original project is available at https://www.figma.com/design/xfF1iZlhs3YjGnLvwl5bwq/Warung-Lokal.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  