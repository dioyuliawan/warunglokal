
Build a complete, fully interactive mobile app prototype for WARLOK — a hyperlocal marketplace for Indonesian local UMKM (small businesses). The app name is Warung Lokal, shortened to Warlok. The app connects nearby warung/kios owners with local customers based on GPS radius.

App Overview: Warlok (Warung Lokal) is a B2C hyperlocal marketplace. Its core differentiator is Hyperlocal Discovery — automatically showing nearby UMKM to customers based on GPS distance, not national algorithms. Think of it as digitizing the trust and habits of traditional Indonesian warung culture.

Brand & Visual Identity:

App name display: Warung Lokal (with "Warlok" as shorthand)

Primary color: #1B5E20 (Deep Green)

Secondary color: #43A047 (Fresh Green)

Surface/background: #F1F8E9 (Light Green tint) and #FFFFFF

Accent: #FF6F00 (Amber — for flash sale and alerts)

Text: #1B1B1B (dark) and #555555 (secondary)

Border radius: 12–16px on cards, 24px on buttons

Typography: Clean sans-serif, warm and friendly

Shadow: Subtle soft shadow on cards (0 2px 8px rgba(0,0,0,0.08))

Overall feel: Warm, local, Indonesian — NOT cold or corporate

Product Categories (4 categories only):

🍽️ Makanan & Minuman — warung nasi, mie ayam, es teh, jajanan, keripik, sambal kemasan, kue tradisional

🥬 Bahan Makanan Segar — kios sayur, buah, ikan, daging, telur, ayam potong

🛒 Toko Kelontong — sembako, toiletries, kebutuhan rumah tangga

🧺 Usaha Jasa Lokal — laundry kiloan, fotokopi, tambal ban

Prototype Interactions Required:

Bottom navigation bar clickable across all screens in each flow

All CTA buttons navigate to the correct next screen

Back buttons functional on all screens

Tab switching (e.g. Aktif/Selesai, Baru/Diproses) shows different content states

Toggle components (Buka/Tutup, Active/Inactive) show visual state change

Scroll behavior on long screens

Build all 23 screens across 3 flows:

FLOW 1 — CUSTOMER (12 screens)

S1 — Splash & Onboarding 3-slide onboarding carousel: Slide 1: Illustration of map with warung pins + text "Temukan warung terdekat dari rumahmu" Slide 2: Illustration of familiar warung + text "Pesan dari kios langganan yang sudah kamu percaya" Slide 3: Illustration of fast delivery + text "Terima hari ini — tanpa ekspedisi jauh" Progress dots below slides. CTA: "Mulai Belanja" → navigates to S2.

S2 — Register / Login Phone number input field. "Kirim OTP" button → navigates to S3 (treat as verified). "Daftar sebagai Mitra Warung" text link at bottom.

S3 — Home / Hyperlocal Feed Top bar: Warung Lokal logo left + "📍 Dalam radius 2 km" location chip right. Search bar below top bar. Horizontal scrollable category chips: Semua / Makanan & Minuman / Bahan Makanan Segar / Toko Kelontong / Usaha Jasa Lokal. Flash Sale banner (amber background): "⚡ Flash Sale Lokal — Warung Bu Tini: Nasi Bungkus -20% | Habis jam 14.00" Warung card list (show 6 cards, scrollable): Each card: warung photo, name, category badge, distance badge, rating (⭐), open status badge (green "Buka"), delivery estimate. Sample warungs:

Warung Bu Tini (Makanan & Minuman, 300m, ⭐4.8, Buka)

Kios Ayam Potong Pak Hendra (Bahan Makanan Segar, 450m, ⭐4.7, Buka)

Toko Kelontong Maju (Toko Kelontong, 600m, ⭐4.6, Buka)

Warung Sate Mang Ujang (Makanan & Minuman, 800m, ⭐4.9, Buka)

Kios Sayur & Buah Bu Sari (Bahan Makanan Segar, 950m, ⭐4.5, Buka)

Laundry Kiloan Bersih (Usaha Jasa Lokal, 1.2km, ⭐4.6, Buka) Bottom nav: 🏠 Beranda / 🔍 Cari / 📦 Pesanan / ❤️ Favorit / 👤 Profil. Clicking warung card → S5. Clicking search bar → S4.

S4 — Search & Filter Active search bar at top with back button. Filter chips: Kategori / Jarak (500m / 1km / 2km / 5km) / Rating / Buka Sekarang. Recent searches: "Ayam potong", "Warung nasi", "Sayur segar". Search results (4 warung cards same format as S3). Back → S3.

S5 — Profil Warung Use "Kios Ayam Potong Pak Hendra" as the sample warung for this screen. Full-width hero photo of the kios. Warung name: "Kios Ayam Potong Pak Hendra". Owner: "Pemilik: Bapak Hendra Wijaya". Since: "Berdiri sejak 2010". Green badge: ✅ Warung Terverifikasi Warga. Status: 🟢 BUKA SEKARANG — Tutup jam 17.00. Distance: 📍 450 meter dari lokasimu. Rating: ⭐ 4.7 (98 ulasan). Owner story box (light green bg): "Kios ayam potong kami sudah melayani warga sekitar sejak 2010. Ayam segar setiap hari langsung dari peternak lokal. Bisa potong sesuai permintaan." Product tabs: Semua / Ayam Utuh / Potongan / Jeroan & Lainnya. Product grid (2 columns, 4 products shown):

Ayam Utuh Segar — Rp 38.000/ekor

Ayam Potong 1/2 — Rp 20.000

Dada Ayam Fillet — Rp 25.000/250gr

Hati & Ampela — Rp 10.000/250gr Floating bottom bar: "💬 Chat ke Pemilik" (outline) + "Lihat Semua Produk" (green filled). Clicking product → S6.

S6 — Detail Produk Use "Ayam Utuh Segar" as sample product. Large product photo. Product name: "Ayam Utuh Segar". Price: "Rp 38.000 / ekor". Warung link: "dari Kios Ayam Potong Pak Hendra →". Stock: ✅ Stok tersedia — 15 ekor hari ini. Description: "Ayam kampung segar dipotong hari ini. Langsung dari peternak lokal. Bisa request potongan sesuai kebutuhan, tinggal chat ke pemilik." Quantity selector: [ − ] 1 [ + ]. Note field: "Catatan: minta potongan..." Green CTA button: "Tambah ke Keranjang" → S7.

S7 — Keranjang Belanja Header: "Keranjang". Items list: product photo, name, quantity controls, price. Sample items: Ayam Utuh Segar x1 = Rp 38.000, Hati & Ampela x2 = Rp 20.000. Order summary card: Subtotal Rp 58.000 / Ongkir (pilih dulu) / Total Rp 58.000. Green CTA: "Pilih Pengiriman & Checkout" → S8.

S8 — Checkout & Pilih Pengiriman Section: Alamat Pengiriman (filled address: "Jl. Melati No. 12, RT 03/RW 05"). Delivery method — 3 selectable cards: 🛵 Antar Sendiri — "Diantar langsung oleh mitra warung" — Rp 5.000 🛺 Ojek Online — "Estimasi 30–60 menit" — Rp 12.000 🚶 Ambil Sendiri — "Datang langsung ke warung" — Gratis Payment method selector: Transfer Bank / COD / Dompet Digital. Optional notes field: "Catatan untuk warung..." Price breakdown: Subtotal Rp 58.000 / Ongkir Rp 5.000 / Total Rp 63.000. Green CTA: "Konfirmasi Pesanan" → S9.

S9 — Konfirmasi Pesanan Large green checkmark centered. "Pesanan Berhasil!" heading. Order number: #WLK-2024-0042. Summary: "Kios Ayam Potong Pak Hendra", items, total Rp 63.000, estimated arrival "± 45 menit". "Lacak Pesanan" green button → S10. "Kembali ke Beranda" text link → S3.

S10 — Tracking Pesanan Order ID: #WLK-2024-0042 and warung name at top. Status timeline (vertical): ✅ Pesanan Diterima — 10:30 ✅ Sedang Disiapkan — 10:35 🔵 Sedang Dikirim — (active, pulsing dot) ⬜ Selesai — (pending) Estimated arrival: "Estimasi tiba: 11:15" Items summary card. "💬 Chat ke Mitra" button.

S11 — Riwayat Pesanan & Repeat Order Tabs: Aktif / Selesai / Dibatalkan. Selesai tab shown by default. Past order cards (3 cards):

"Kios Ayam Potong Pak Hendra" — Ayam Utuh x1, Hati & Ampela x2 — Rp 63.000 — 2 hari lalu — "Pesan Lagi" button

"Warung Bu Tini" — Nasi Bungkus x2, Es Teh x1 — Rp 40.000 — 5 hari lalu — "Pesan Lagi" button

"Toko Kelontong Maju" — Minyak Goreng, Gula — Rp 52.000 — 1 minggu lalu — "Pesan Lagi" button Langganan Rutin section: "Ayam Potong Mingguan — Setiap Jumat pagi" with edit button. "Pesan Lagi" button → S7.

S12 — Profil & Warung Favorit Customer avatar, name: "Rina Kusuma", phone: 0812-xxxx-xxxx. Menu items: 📍 Alamat Saya / 💳 Metode Pembayaran / 🔔 Notifikasi / ⚙️ Pengaturan. Warung Favorit section. Grid of 4 followed warungs:

Kios Ayam Potong Pak Hendra

Warung Bu Tini

Kios Sayur & Buah Bu Sari

Toko Kelontong Maju Each with ❤️ icon and distance.

FLOW 2 — MITRA WARUNG (8 screens)

S13 — Register & Onboarding Mitra Step progress bar: Step 1 of 4. Friendly heading: "Selamat datang! Mari daftarkan warungmu dalam beberapa langkah mudah." Step 1 — Info Warung: fields: Nama Warung / Nama Pemilik / Nomor HP / Kategori Usaha (dropdown with 4 categories). "Lanjut →" green button → S14. "Sudah punya akun? Masuk" text link.

S14 — Dashboard Mitra Greeting: "Selamat pagi, Pak Hendra! 👋" Large prominent status toggle: 🟢 BUKA — tap to change to TUTUP. Stats row (3 cards): Pesanan Masuk: 4 / Pendapatan Hari Ini: Rp 247.000 / Produk Aktif: 8. Recent orders section (2 preview cards) with "Lihat Semua" link → S17. Quick actions row: [+ Tambah Produk → S16] [📦 Update Stok → S19] [⚡ Flash Sale → S19]. Bottom nav: 🏠 Dashboard / 📦 Produk / 🧾 Pesanan / 📊 Laporan / 👤 Profil.

S15 — Kelola Produk Search bar + filter icon. Product grid (2 columns, 6 products):

Ayam Utuh Segar — Rp 38.000 — Stok: 15 — toggle ON

Ayam Potong 1/2 — Rp 20.000 — Stok: 20 — toggle ON

Dada Ayam Fillet — Rp 25.000 — Stok: 12 — toggle ON

Hati & Ampela — Rp 10.000 — Stok: 8 — toggle ON

Ceker Ayam — Rp 8.000 — Stok: 10 — toggle ON

Kepala Ayam — Rp 7.000 — Stok: 0 — toggle OFF (out of stock) FAB green button: "+ Tambah Produk" → S16.

S16 — Tambah / Edit Produk Photo upload box with camera icon placeholder. Fields: Nama Produk: "Ayam Utuh Segar" Kategori: "Bahan Makanan Segar" Harga: "Rp 38.000" Satuan: "per ekor" (dropdown: per ekor / per kg / per gram / per ikat / per buah / per porsi) Stok: "15" Deskripsi: "Ayam kampung segar dipotong hari ini..." Active toggle: "Tampilkan di Warung Lokal". "Simpan Produk" green CTA → S15.

S17 — Pesanan Masuk Tabs: 🔴 Baru (4) / 🔵 Diproses (1) / ✅ Selesai. Baru tab default. 4 order cards:

#WLK-0042 — Rina Kusuma — Ayam Utuh x1, Hati & Ampela x2 — Rp 63.000 — Antar Sendiri — 5 menit lalu

#WLK-0041 — Budi Santoso — Dada Fillet x2 — Rp 50.000 — Ojek Online — 12 menit lalu

#WLK-0040 — Siti Aminah — Ayam 1/2 x2, Ceker x1 — Rp 48.000 — Ambil Sendiri — 20 menit lalu

#WLK-0039 — Rudi Hartono — Ayam Utuh x2 — Rp 76.000 — Antar Sendiri — 35 menit lalu Each card: "✅ Konfirmasi" green button + "❌ Tolak" red outline button. Clicking order card → S18.

S18 — Detail Pesanan Order: #WLK-0042 — Rina Kusuma. Delivery: 🛵 Antar Sendiri — "Jl. Melati No. 12, RT 03/RW 05". Items: Ayam Utuh Segar x1 = Rp 38.000, Hati & Ampela x2 = Rp 20.000. Notes: "Ayamnya minta dibersihkan ya Pak". Subtotal: Rp 58.000 / Ongkir: Rp 5.000 / Total: Rp 63.000. Primary CTA: "Tandai Sedang Dikirim" green button. Secondary: "💬 Chat ke Customer" outline button.

S19 — Kelola Stok & Flash Sale Stock update section: Each product row: photo thumbnail, name, [ − ] stock number [ + ]. Sample: Ayam Utuh Segar [−] 15 [+] / Ayam Potong 1/2 [−] 20 [+] / Dada Fillet [−] 12 [+]. "Simpan Stok" button. Divider. Flash Sale Lokal section (amber tint background): Toggle switch: "Aktifkan Flash Sale Hari Ini". Product selector: "Pilih produk..." dropdown. Discount input: "20 %". End time: "Habis jam 17.00 hari ini". Preview notification box (amber bg): "⚡ Notifikasi akan dikirim ke semua customer dalam radius 2km dari warungmu." "Aktifkan Flash Sale Sekarang" amber CTA button.

S20 — Laporan Penjualan Date range tabs: Hari Ini / Minggu Ini / Bulan Ini. Minggu Ini tab (default). Bar chart: 7 bars (Mon–Sun) with Rp values, today's bar highlighted green. Summary cards: Total Pendapatan: Rp 1.240.000 / Total Transaksi: 38 / Rata-rata per Order: Rp 32.600. Top Produk section:

🥇 Ayam Utuh Segar — 42 terjual

🥈 Dada Ayam Fillet — 31 terjual

🥉 Hati & Ampela — 28 terjual

FLOW 3 — ADMIN (3 screens)

S21 — Dashboard Admin Header: "Warung Lokal — Admin Panel". Stats cards: Mitra Aktif: 142 / Transaksi Hari Ini: 89 / Pending Verifikasi: 7. Quick action buttons: "Verifikasi Mitra →" → S22 / "Kelola Kategori →" → S23. Recent activity feed: "[5 mnt lalu] Kios Ayam Pak Budi mendaftar sebagai mitra baru" "[1 jam lalu] Warung Sate Mang Ujang diverifikasi" "[2 jam lalu] 3 produk baru ditambahkan oleh Toko Kelontong Maju"

S22 — Verifikasi Mitra Header: "Mitra Pending Verifikasi (7)". List of 3 pending registration cards:

"Kios Ayam Pak Budi" — Bahan Makanan Segar — "Daftar: 1 jam lalu" — dokumen uploaded ✅

"Warung Nasi Ibu Dewi" — Makanan & Minuman — "Daftar: 3 jam lalu" — dokumen uploaded ✅

"Laundry Kiloan Bersih" — Usaha Jasa Lokal — "Daftar: 5 jam lalu" — dokumen uploaded ✅ Each card: "✅ Approve" green button + "❌ Tolak" red outline button. Approving shows green "Terverifikasi" badge on card.

S23 — Kelola Kategori Header: "Kategori UMKM". List of 4 active categories with icon, name, and jumlah mitra: 🍽️ Makanan & Minuman — 58 mitra — toggle ON 🥬 Bahan Makanan Segar — 41 mitra — toggle ON 🛒 Toko Kelontong — 29 mitra — toggle ON 🧺 Usaha Jasa Lokal — 14 mitra — toggle ON Each row has active/inactive toggle. "+ Tambah Kategori" green button at bottom.

Final Instructions:

Frame size: 375 x 812px per screen (iPhone standard, portrait)

Organize all frames in 3 clearly labeled sections: CUSTOMER FLOW / MITRA WARUNG FLOW / ADMIN FLOW

Connect all screens with prototype arrows based on the navigation described above

All dummy data must be in Indonesian language with prices in Rupiah (Rp)

Maintain visual consistency across all 23 screens using brand colors and component styles defined above

The overall feel must be warm, trustworthy, and locally Indonesian — not a generic Western marketplace clone

Bottom navigation bar must be consistent and functional across all Customer and Mitra screens



