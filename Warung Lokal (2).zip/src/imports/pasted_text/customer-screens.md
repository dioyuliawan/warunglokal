BUILD THESE ADDITIONAL SCREENS and connect all 
existing dead-end buttons to their proper destinations.

═══════════════════════════════════════════════
CUSTOMER FLOW — ADDITIONAL SCREENS
═══════════════════════════════════════════════

───────────────────────────────────────────────
CS1 — CHAT KE MITRA (Full Chat Screen)
───────────────────────────────────────────────
Accessed from: "Chat ke Pemilik" button on 
  warung profile page (S5)

Top app bar:
  Back arrow left
  Center: warung photo (small circle) + 
    "Kios Ayam Pak Hendra" + 
    "Buka Sekarang" green dot
  Right: phone icon

Chat interface:
  Chat bubbles — customer side (right, green bubbles):
    "Pak, ayam utuh masih ada stok?"
    "Oke pak, saya pesan 2 ekor ya"
    
  Chat bubbles — mitra side (left, white bubbles 
    with gray border):
    "Masih ada pak/bu, hari ini 15 ekor"
    "Siap, langsung saya proses pesanannya"
    
  Timestamp between message groups: "10:32"
  
  Message input bar at bottom:
    Text field: "Tulis pesan..."
    Camera icon (for sending product photo)
    Send button (green arrow)
    
  Quick reply chips above input bar:
    [Stok masih ada?] [Bisa request potongan?] 
    [Berapa ongkirnya?] [Kapan buka?]

Navigation: back arrow → S5 Profil Warung

───────────────────────────────────────────────
CS2 — SEMUA PRODUK (Full Product List per Warung)
───────────────────────────────────────────────
Accessed from: "Lihat Semua Produk" on S5

Top app bar:
  Back arrow + warung name as title
  Right: search icon + filter icon

Category tab bar (scrollable horizontal):
  Semua / [category tabs specific to warung]
  
  For Kios Ayam Pak Hendra:
    Semua / Ayam Utuh / Potongan / Jeroan & Lainnya
    
  For Warung Bu Tini:
    Semua / Nasi & Lauk / Minuman / Snack
    
  For Kios Sayur Bu Sari:
    Semua / Sayuran / Buah / Paket Bundling
    
  For Toko Kelontong Maju:
    Semua / Sembako / Minuman / Kebersihan
    
  For Warung Sate Mang Ujang:
    Semua / Sate / Nasi & Lontong / Minuman
    
  For Laundry Kiloan Bersih:
    Semua Layanan

Product grid (2 columns):
  Show ALL products from that warung's 
  master product list (6-7 products each)
  Each card: real product photo, name, 
  price, stock, "+" add button
  
  IMPORTANT: Each warung shows ONLY its own 
  products — strictly use master product list 
  defined previously for each warung

Tapping product card → S6 Detail Produk
Floating bottom: "Chat ke Pemilik" button → CS1

───────────────────────────────────────────────
CS3 — PESANAN AKTIF
───────────────────────────────────────────────
Accessed from: S12 Profil menu 
  "Pesanan Aktif" OR bottom nav Pesanan tab

Top app bar: back arrow + "Pesanan Aktif"

Active order card (full detail):
  Order #WLK-2024-0042
  Status pill: "🔵 Sedang Dikirim" (pulsing)
  Warung: Kios Ayam Pak Hendra
  Items: Ayam Utuh Segar x1, Hati & Ampela x2
  Total: Rp 63.000
  Estimated arrival: "Tiba ~11:15"
  Progress bar: 3 of 4 steps complete
  
  Action buttons:
    "Lacak Pesanan" green button → S10 Tracking
    "Chat ke Mitra" outlined button → CS1

If no active orders:
  Illustration of empty state
  Text: "Belum ada pesanan aktif"
  "Mulai Belanja" green button → S3 Home

───────────────────────────────────────────────
CS4 — METODE PEMBAYARAN
───────────────────────────────────────────────
Accessed from: S12 Profil → "Metode Pembayaran"

Top app bar: back arrow + "Metode Pembayaran"

Saved payment methods list:
  Card 1: BCA icon + "BCA Virtual Account" + 
    "****1234" + default badge (green)
  Card 2: GoPay icon + "GoPay" + 
    "Rina Kusuma" + linked badge
  Card 3: OVO icon + "OVO" + "081234****" 
  Each card: radio button to set default + 
    trash icon to remove

Divider

"+ Tambah Metode Pembayaran" outlined button
  Opens bottom sheet with options:
    Transfer Bank (BCA, BNI, BRI, Mandiri)
    Dompet Digital (GoPay, OVO, Dana, ShopeePay)
    COD (Bayar di Tempat)

Bottom: "Simpan" green button

───────────────────────────────────────────────
CS5 — ALAMAT SAYA
───────────────────────────────────────────────
Accessed from: S12 Profil → "Alamat Saya"

Top app bar: back arrow + "Alamat Saya"

Saved addresses list:

  Address Card 1 (default):
    Green "Utama" badge
    Label: "Rumah"
    Name: Rina Kusuma
    Phone: 0812-3456-7890
    Address: Jl. Melati No. 12, RT 03/RW 05, 
      Kel. Tebet Barat, Kec. Tebet, 
      Jakarta Selatan 12810
    [Edit] [Hapus] text buttons
    
  Address Card 2:
    Label: "Kantor"
    Address: Jl. Sudirman No. 45, Lt. 8, 
      Jakarta Pusat 10220
    [Jadikan Utama] [Edit] [Hapus]
    
"+ Tambah Alamat Baru" outlined green button
  → Opens map view to pin location + 
    form to fill address detail

───────────────────────────────────────────────
CS6 — NOTIFIKASI CUSTOMER
───────────────────────────────────────────────
Accessed from: S12 Profil → "Notifikasi" OR
  bell icon on home screen

Top app bar: back arrow + "Notifikasi"

Tab bar: Semua / Pesanan / Promo / Warung Favorit

Notification list (today):
  [Pesanan] blue icon
    "Pesanan #WLK-0042 sedang dalam perjalanan"
    "10 menit lalu"
    
  [Flash Sale] amber icon
    "⚡ Warung Bu Tini: Nasi Bungkus -20% 
    Habis jam 14.00!"
    "32 menit lalu"
    
  [Warung Favorit] green icon
    "Kios Sayur Bu Sari baru restok: 
    Mangga Harum Manis tersedia"
    "1 jam lalu"

Yesterday:
  [Pesanan] blue icon
    "Pesanan #WLK-0039 telah selesai. 
    Beri ulasan untuk Warung Bu Tini"
    → tapping navigates to rating screen
    
  [Promo] purple icon
    "Kode voucher WARLOK10 berlaku hari ini!"

Tapping each notification → relevant screen

───────────────────────────────────────────────
CS7 — KEAMANAN
───────────────────────────────────────────────
Accessed from: S12 Profil → "Keamanan"

Top app bar: back arrow + "Keamanan"

Menu list with chevron:
  Nomor HP Terdaftar
    "0812-3456-7890" in gray subtitle
    → tapping: form to change phone number
    
  Ubah PIN Aplikasi
    → tapping: old PIN → new PIN → confirm
    
  Verifikasi Dua Langkah
    Toggle switch — currently OFF
    Description: "Tambahan keamanan saat login 
    dari perangkat baru"
    
  Riwayat Login
    → tapping: list of recent login activity
    "Hari ini, 08:30 — Jakarta (perangkat ini)"
    "Kemarin, 19:22 — Jakarta"
    
  Keluar dari Semua Perangkat
    Red text, tap shows confirmation dialog

───────────────────────────────────────────────
CS8 — BANTUAN
───────────────────────────────────────────────
Accessed from: S12 Profil → "Bantuan"

Top app bar: back arrow + "Bantuan"

Search bar: "Cari pertanyaan atau topik..."

Popular topics (chip row):
  Pesanan / Pembayaran / Pengiriman / Akun

FAQ list (expandable accordion):
  "Bagaimana cara melacak pesanan saya?"
    → expands: step by step explanation
    
  "Apa yang harus dilakukan jika pesanan 
  tidak datang?"
    → expands: contact mitra first, 
    then contact support
    
  "Bagaimana cara membatalkan pesanan?"
    → expands: cancellation steps
    
  "Bagaimana cara menghubungi warung?"
    → expands: use chat feature

Contact support section:
  "Masih butuh bantuan?"
  [Live Chat] green button — chat icon
  [WhatsApp Support] outlined button
  Operating hours: "Senin-Sabtu, 08.00-20.00"

───────────────────────────────────────────────
CS9 — TENTANG WARLOK
───────────────────────────────────────────────
Accessed from: S12 Profil → "Tentang Warlok"

Top app bar: back arrow + "Tentang Warlok"

Warlok logo centered (large, green)
Version: "Versi 1.0.0"
Tagline: "Warungmu, Dekat di Genggaman"

About text (short paragraph):
  "Warlok — Warung Lokal adalah marketplace 
  hyperlokal yang menghubungkan UMKM lokal 
  dengan pelanggan di sekitar mereka. 
  Kami hadir untuk mendigitalkan kepercayaan 
  lokal, bukan menggantinya."

Menu list:
  Syarat & Ketentuan → CS10
  Kebijakan Privasi → simple text screen
  Lisensi Open Source → simple text screen

Social media row:
  Instagram / Twitter / TikTok icons

Legal text (small gray):
  "© 2024 Warlok — Warung Lokal"
  "Dikembangkan di Indonesia 🇮🇩"

─────────────────────────────────────
ADMIN ACCESS — HIDDEN ENTRY POINT
─────────────────────────────────────
At the very bottom of CS9 Tentang Warlok screen,
below the legal text, add:

  Small gray text (very small, 10sp, subtle):
  "v1.0.0 build 2024.12"
  
  This small version text is TAPPABLE (no visual 
  indicator that it's tappable — looks like 
  regular text):
  
  When tapped 3 times consecutively:
    Small bottom sheet appears:
    Title: "Akses Panel Admin"
    Input field: "Masukkan kode akses"
    (dummy code: admin2024)
    [Masuk ke Admin Panel] green button → S21
    
  This entry is intentionally subtle and 
  hidden from regular users.
  Same hidden entry available in Mitra's 
  "Tentang Warlok" screen (MS8).

───────────────────────────────────────────────
CS10 — SYARAT & KETENTUAN
───────────────────────────────────────────────
Accessed from: CS9 Tentang Warlok

Top app bar: back arrow + "Syarat & Ketentuan"
Last updated: "Terakhir diperbarui: 1 Januari 2024"

Scrollable long text with section headers:
  1. Ketentuan Umum
     "Dengan menggunakan aplikasi Warlok, 
     pengguna menyetujui seluruh syarat dan 
     ketentuan yang berlaku..."
     
  2. Hak dan Kewajiban Pengguna
     "Pengguna wajib memberikan informasi 
     yang akurat dan bertanggung jawab atas 
     aktivitas akun..."
     
  3. Transaksi dan Pembayaran
     "Warlok berfungsi sebagai fasilitator 
     transaksi antara customer dan mitra 
     warung..."
     
  4. Kebijakan Pengiriman
     "Metode dan biaya pengiriman ditentukan 
     berdasarkan kesepakatan antara customer 
     dan mitra warung..."
     
  5. Penyelesaian Sengketa
     "Apabila terjadi perselisihan antara 
     customer dan mitra warung..."

═══════════════════════════════════════════════
MITRA FLOW — ADDITIONAL SCREENS
═══════════════════════════════════════════════

───────────────────────────────────────────────
MS1 — ONBOARDING MITRA — STEPS 2, 3, 4
───────────────────────────────────────────────
Accessed from: S13 Step 1 "Lanjut" button

STEP 2 of 4 — Lokasi & Jam Operasional:
  Top: progress bar step 2 highlighted
  Title: "Lokasi Warung"
  
  Map picker (Google Maps style):
    Pin centered on map
    User drags map to position pin on 
    warung location
    Address auto-filled below map:
    "Jl. Tebet Barat Dalam No. 5, 
    Kel. Tebet Barat, Jakarta Selatan"
    
  Jam Operasional section:
    Each day row: Mon Tue Wed Thu Fri Sat Sun
    Toggle ON/OFF per day
    Time picker: Buka [07:00] — Tutup [17:00]
    Default: all days ON, 07:00-17:00
    
  "Lanjut →" green button

STEP 3 of 4 — Foto & Deskripsi Warung:
  Top: progress bar step 3 highlighted
  Title: "Kenalkan Warungmu"
  
  Photo upload (large square dashed box):
    Camera icon centered
    "Upload Foto Warung"
    "Foto warung yang bagus meningkatkan 
    kepercayaan customer"
    
  Nama Warung field (pre-filled from step 1)
  
  Cerita Warung (multiline textarea):
    Placeholder: "Ceritakan warungmu kepada 
    customer — sudah berapa lama berdiri, 
    produk unggulan, atau hal unik lainnya..."
    Character count: 0/200
    
  Kategori Usaha (already filled, shown as 
    read-only chip with edit option)
    
  "Lanjut →" green button

STEP 4 of 4 — Review & Konfirmasi:
  Top: progress bar step 4 highlighted (complete)
  Title: "Periksa Data Warungmu"
  
  Summary card showing all info:
    Warung photo (circle, large)
    Nama: Kios Ayam Potong Pak Hendra
    Pemilik: Bapak Hendra Wijaya
    Kategori: Bahan Makanan Segar
    Alamat: Jl. Tebet Barat Dalam No. 5
    Jam Buka: Setiap hari 07.00-17.00
    
  Each section has "Edit" text link
  
  Checkbox: "Saya menyetujui Syarat & Ketentuan 
    Mitra Warlok"
    
  "Daftarkan Warungku" green filled button
    → Success screen:
      Green checkmark animation
      "Pendaftaran Berhasil!"
      "Warungmu sedang dalam proses verifikasi. 
      Kami akan memberitahu kamu dalam 1x24 jam."
      "Mengerti" button → S14 Dashboard Mitra

───────────────────────────────────────────────
MS2 — SETELAH TANDAI SEDANG DIKIRIM
───────────────────────────────────────────────
Accessed from: S18 "Tandai Sedang Dikirim" button

Order status update confirmation screen:
  Green checkmark icon (medium)
  "Pesanan Ditandai Sedang Dikirim"
  Order #WLK-0042
  
  Info card:
    Customer: Rina Kusuma
    Alamat: Jl. Melati No. 12
    Estimasi tiba: "± 30 menit"
    
  Status timeline (updated):
    ✅ Pesanan Diterima
    ✅ Sedang Disiapkan
    ✅ Sedang Dikirim ← (now active)
    ⬜ Selesai
    
  Action buttons:
    "Tandai Pesanan Selesai" green button
      → Success: order moved to Selesai tab
        Pendapatan +Rp 63.000 tercatat
        "Pesanan Berhasil Diselesaikan!" 
        green toast notification
    "Chat ke Customer" outlined button → MS3

───────────────────────────────────────────────
MS3 — CHAT KE CUSTOMER (Mitra Side)
───────────────────────────────────────────────
Accessed from: S18 "Chat ke Customer" OR
  MS2 "Chat ke Customer"

Top app bar:
  Back arrow
  Customer avatar + "Rina Kusuma" + 
  "Online" green dot
  Phone icon right

Chat interface (mirror of CS1 but mitra POV):
  Customer bubbles (left, white):
    "Pak, ayam utuh masih ada stok?"
    "Oke pak, saya pesan 2 ekor ya"
    "Tolong dibersihkan dulu ya pak"
    
  Mitra bubbles (right, green):
    "Masih ada pak/bu, hari ini 15 ekor"
    "Siap, langsung saya proses pesanannya"
    "Baik siap, sudah dibersihkan"
    
  Quick reply chips:
    [Pesanan siap] [Sedang dikirim]
    [Mohon tunggu] [Stok habis]
    
  Message input bar same as CS1

───────────────────────────────────────────────
MS4 — EDIT PROFIL WARUNG
───────────────────────────────────────────────
Accessed from: Mitra Profile → "Profil Warung"
  OR from S13 Step 4 edit buttons

Top app bar: back arrow + "Edit Profil Warung" 
  + "Simpan" text button right

Sections:
  Foto Warung:
    Current warung photo (large, tappable)
    "Ganti Foto" text below
    
  Informasi Dasar:
    Nama Warung: [Kios Ayam Potong Pak Hendra]
    Nama Pemilik: [Bapak Hendra Wijaya]
    Nomor HP: [0812-xxxx-xxxx]
    Kategori: [Bahan Makanan Segar] (dropdown)
    
  Cerita Warung:
    Multiline text area with current story
    Character count shown
    
  Alamat:
    Full address field
    "Ubah di Peta" link → map picker
    
  Jam Operasional:
    Each day with toggle + time picker
    
  "Simpan Perubahan" green button at bottom

───────────────────────────────────────────────
MS5 — INFORMASI WARUNG (View Mode)
───────────────────────────────────────────────
Accessed from: Mitra side drawer → 
  "Informasi Warung"

Top app bar: back arrow + "Informasi Warung"
  + edit icon right → MS4

Preview card: "Begini tampilan warungmu 
  di aplikasi customer"

Shows exact same layout as S5 Profil Warung 
  (customer view) with Pak Hendra's data:
  Hero photo, name, badge, status, 
  rating, story, product grid
  
Bottom note (amber info box):
  "Ini adalah tampilan yang dilihat customer. 
  Tap edit untuk mengubah informasi warungmu."

───────────────────────────────────────────────
MS6 — PENGATURAN MITRA
───────────────────────────────────────────────
Accessed from: Mitra bottom nav or drawer 
  → "Pengaturan"

Top app bar: back arrow + "Pengaturan"

Sections:

PENGATURAN WARUNG:
  Radius Pengiriman
    "Maksimal 5 km dari warung" → tappable
    Opens radius picker: 1km/2km/3km/5km/10km
    
  Tarif Ongkos Kirim Default
    Four editable rows:
    Di bawah 1 km   : Rp 3.000
    1 km – 2 km     : Rp 6.000
    2 km – 3 km     : Rp 9.000
    Di atas 3 km    : Rp 12.000
    "Simpan Tarif" green button
    
  Minimum Order
    Toggle + "Rp [25.000]" input
    
  Auto-Terima Pesanan
    Toggle OFF (default manual confirmation)
    Description: "Pesanan otomatis terkonfirmasi 
    tanpa perlu kamu konfirmasi manual"

NOTIFIKASI:
  Pesanan Masuk — Toggle ON
  Pesan Baru dari Customer — Toggle ON
  Pengingat Update Stok (07.00) — Toggle ON
  Laporan Harian — Toggle OFF

AKUN:
  Ubah Nomor HP → form
  Ubah PIN → form
  Keamanan Akun → same as CS7

  [Keluar dari Akun Mitra] 
    Red text with logout icon
    Confirmation dialog before logout

───────────────────────────────────────────────
MS7 — BANTUAN & DUKUNGAN MITRA
───────────────────────────────────────────────
Accessed from: Mitra drawer → "Bantuan"

Top app bar: back arrow + "Bantuan & Dukungan"

Search bar: "Cari pertanyaan..."

Mitra-specific FAQ:
  "Bagaimana cara menambah produk baru?"
  "Bagaimana cara mengaktifkan Flash Sale?"
  "Kapan pendapatan saya dicairkan?"
  "Bagaimana cara update stok harian?"
  "Apa yang terjadi jika saya tolak pesanan?"
  Each → expands with answer text

Video tutorial section (3 cards):
  "Cara upload produk pertama"
  "Cara proses pesanan masuk"
  "Cara aktivasi Flash Sale"
  Each card: thumbnail + duration

Contact support:
  [Live Chat dengan Tim Warlok] green button
  [WhatsApp Mitra Support] outlined button
  "Khusus Mitra: 08.00-22.00 setiap hari"

───────────────────────────────────────────────
MS8 — TENTANG WARLOK (Mitra Version)
───────────────────────────────────────────────
Accessed from: Mitra drawer → "Tentang Warlok"

Same structure as CS9 but with:
  Additional section "Program Mitra Warlok":
    "Bergabung dengan ribuan mitra UMKM yang 
    sudah terdigitalisasi bersama Warlok"
    Stats: 142 Mitra Aktif / 89 Transaksi Hari Ini
    
  Syarat & Ketentuan Mitra → MS9

Same hidden admin entry point at bottom:
  Small gray version text "v1.0.0 build 2024.12"
  Tap 3 times → admin access bottom sheet
  Same code: admin2024 → S21 Admin Dashboard

───────────────────────────────────────────────
MS9 — SYARAT & KETENTUAN MITRA
───────────────────────────────────────────────
Accessed from: MS8 or S13 Step 4

Top app bar: back + "Syarat & Ketentuan Mitra"

Sections:
  1. Ketentuan Menjadi Mitra Warlok
  2. Kewajiban Mitra
     "Mitra wajib menjaga kualitas produk, 
     memperbarui stok secara rutin, dan 
     merespons pesanan dalam 15 menit..."
  3. Komisi dan Pembayaran
     "Warlok mengambil komisi sebesar X% 
     dari setiap transaksi yang berhasil..."
  4. Penonaktifan Akun Mitra
  5. Kebijakan Produk

───────────────────────────────────────────────
NOTIFIKASI — BOTH FLOWS
───────────────────────────────────────────────
Customer notification bell (top right S3 Home)
  → navigates to CS6 Notifikasi

Mitra notification bell (top right S14 Dashboard)
  → opens MS-NOTIF screen:

Top app bar: back arrow + "Notifikasi"

Tab: Semua / Pesanan / Sistem

List:
  [Pesanan] blue icon
    "Pesanan baru masuk! #WLK-0043 
    dari Budi Santoso — Dada Fillet x2"
    "3 menit lalu" — UNREAD (blue dot)
    → tapping: S17 Pesanan Masuk
    
  [Pesanan] blue icon
    "Pesanan #WLK-0042 berhasil diselesaikan. 
    Pendapatan +Rp 63.000 tercatat"
    "45 menit lalu"
    
  [Sistem] gray icon
    "Jangan lupa update stok harianmu 
    agar customer tidak kecewa"
    "07.00 tadi pagi"
    
  [Sistem] gray icon
    "Selamat! Warungmu mendapat 
    5 ulasan bintang baru minggu ini"
    "Kemarin"

═══════════════════════════════════════════════
COMPLETE NAVIGATION MAP — ALL CONNECTIONS
═══════════════════════════════════════════════

CUSTOMER CONNECTIONS (fix all dead ends):
S3 Home bell icon → CS6 Notifikasi
S5 "Chat ke Pemilik" → CS1 Chat
S5 "Lihat Semua Produk" → CS2 Semua Produk
S12 "Pesanan Aktif" → CS3 Pesanan Aktif
S12 "Metode Pembayaran" → CS4 Metode Pembayaran
S12 "Alamat Saya" → CS5 Alamat
S12 "Notifikasi" → CS6 Notifikasi
S12 "Keamanan" → CS7 Keamanan
S12 "Bantuan" → CS8 Bantuan
S12 "Tentang Warlok" → CS9 Tentang Warlok
CS9 "Syarat & Ketentuan" → CS10
CS9 version text x3 taps → Admin access → S21

MITRA CONNECTIONS (fix all dead ends):
S13 Step 1 "Lanjut" → MS1 Step 2
MS1 Step 2 "Lanjut" → MS1 Step 3
MS1 Step 3 "Lanjut" → MS1 Step 4
MS1 Step 4 "Daftarkan" → Success → S14
S18 "Tandai Sedang Dikirim" → MS2
MS2 "Tandai Pesanan Selesai" → success state
S18 "Chat ke Customer" → MS3
Mitra drawer "Profil Warung" → MS4
Mitra drawer "Informasi Warung" → MS5
Mitra drawer "Pengaturan" → MS6
Mitra drawer "Bantuan" → MS7
Mitra drawer "Tentang Warlok" → MS8
MS8 "Syarat & Ketentuan Mitra" → MS9
MS8 version text x3 taps → Admin access → S21
S14 bell icon → MS-NOTIF
MS6 "Tarif Ongkos Kirim" → editable rows
MS6 "Keluar" → confirmation → S2 Login

ADMIN CONNECTION:
CS9 & MS8 hidden entry → S21 Admin Dashboard
S21 → S22 Verifikasi Mitra
S21 → S23 Kelola Kategori
All admin screens: back arrow → S21