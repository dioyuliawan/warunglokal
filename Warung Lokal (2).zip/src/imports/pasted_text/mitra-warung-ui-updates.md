

**GLOBAL FIXES untuk semua screen Mitra Warung:**

```
CRITICAL — Apply to ALL Mitra Warung screens (S13-S20):
- Remove ALL emoji from every screen in Mitra flow
- Replace every emoji with proper icon from Phosphor Icons 
  or similar professional icon set
- Every product listing must show real food photography, 
  NOT emoji or illustration
- Every screen must have a proper top app bar with:
  Left: Back arrow icon OR hamburger menu
  Center: Page title text
  Right: contextual action icon (notification bell, 
  settings gear, etc.)
- Bottom navigation must have a visible EXIT / LOGOUT option
  or access to account settings from every screen
```

---

**S13 — Register & Onboarding Mitra (Update top bar):**

```
Add proper top app bar:
- Back arrow icon (left) → returns to S12 Profile page
- Title: "Daftar Mitra Warung"
- Progress bar below top bar: Step 1 of 4
All form fields use proper text input components, 
no emoji labels.
```

---

**S14 — Dashboard Utama Mitra (Major Update):**

```
TOP APP BAR:
- Left: Hamburger menu icon → opens side drawer
- Center: "Warung Lokal" logo (small, green)
- Right: Notification bell icon (with badge count) + 
  Avatar circle (tappable → opens account menu with 
  LOGOUT option)

SIDE DRAWER (when hamburger tapped):
- Warung photo + name + owner name at top
- Menu items: Dashboard / Produk / Pesanan / Laporan / 
  Pengaturan Warung / Bantuan
- Bottom of drawer: [Keluar dari Akun Mitra] 
  red text with logout icon

MAPS SECTION (Key Feature — place prominently below stats):
Full-width map card (height ~220px) with rounded corners 
and shadow.
Map shows REALISTIC street map (Google Maps style) of a 
fictional Indonesian neighborhood.

Fictional location: Kelurahan Menteng Dalam, 
Jakarta Selatan area.
Street names visible on map: 
Jl. Tebet Raya, Jl. Wolter Monginsidi, Jl. Gatot Subroto.

Fictional warung pins on map (use circular photo pins, 
real food photography):
Pin 1 (GREEN — Buka): "Warung Bu Tini" — 
  Jl. Tebet Raya No. 12 — Makanan & Minuman — 
  pin at coordinate slightly northwest on map
Pin 2 (GREEN — Buka): "Kios Pak Hendra" — 
  Jl. Tebet Barat No. 5 — Bahan Makanan Segar — 
  pin at coordinate northeast
Pin 3 (RED — Tutup): "Toko Kelontong Maju" — 
  Jl. Tebet Timur No. 8 — Kelontong — 
  pin at coordinate southeast
Pin 4 (GREEN — Buka): "Warung Sate Mang Ujang" — 
  Jl. Wolter Monginsidi No. 3 — Makanan & Minuman — 
  pin slightly south
Pin 5 (ORANGE — Istirahat): "Kios Sayur Bu Sari" — 
  Jl. Gatot Subroto No. 22 — Bahan Makanan Segar — 
  pin slightly west
YOUR WARUNG PIN (BLUE — special color for own warung): 
  "Kios Ayam Pak Hendra" — center of map — 
  larger pin with blue ring to distinguish from others

RADIUS FILTER below the map:
Label: "Tampilkan warung dalam radius:"
Horizontal pill selector: [500m] [1 km] [2 km] [5 km] 
  [10 km]
Currently selected "2 km" highlighted in green.
Selecting different radius animates map zoom level.
Small text below: 
  "Menampilkan 5 warung dalam radius 2 km dari lokasimu"

Map controls (inside map, bottom right):
[+] zoom in / [-] zoom out
[Lokasiku] button with crosshair icon — recenters to 
  warung location
```

---

**S15 — Kelola Produk (Fix icons & images):**

```
Remove ALL emoji from this screen.
Product grid cards must use:
- Real food photography for each product thumbnail 
  (square, rounded corners 8px)
- Product name in bold black text
- Price in green text
- Stock count with proper package/box ICON (not emoji)
- Active/inactive toggle switch component
- Three-dot menu icon on each card for edit/delete options

Category filter tabs at top:
Use proper text tabs, no emoji:
Semua Produk / Ayam Utuh / Potongan / Jeroan & Lainnya

FAB button bottom right: 
Plus icon inside green circle — "+ Tambah Produk"
Clean, no emoji anywhere.
```

---

**S16 — Tambah / Edit Produk (Fix icons):**

```
Top app bar: Back arrow + "Tambah Produk" title + 
  "Simpan" text button right.

Photo upload area: 
Large square dashed border box.
Camera icon (proper icon) centered.
Text: "Tambah Foto Produk" 
Sub text: "Tap untuk pilih foto dari galeri atau kamera"
NO emoji.

All form field labels use proper text only, no emoji prefix:
- Nama Produk
- Kategori (dropdown with real category icons)
- Harga Jual (Rp prefix inside field)
- Satuan (dropdown: per ekor / per kg / per gram / 
  per ikat / per buah / per porsi)
- Jumlah Stok
- Deskripsi Produk (multiline text area)

Toggle row: "Tampilkan produk di Warung Lokal" 
  with proper toggle switch — no emoji.
```

---

**S17 — Pesanan Masuk (Fix icons):**

```
Top app bar: Hamburger menu left + "Pesanan Masuk" 
  title center + filter icon right.

Tab bar: Baru / Diproses / Selesai
Use number badge on "Baru" tab (e.g. red circle with "4")
NO emoji on tabs — use clean text only.

Order cards:
- Customer avatar (initials circle) + customer name
- Order ID in gray small text
- Items list in normal text (no emoji)
- Total price bold green
- Timestamp in gray
- Delivery method shown as pill badge: 
  "Antar Sendiri" / "Ojek Online" / "Ambil Sendiri"
  with proper vehicle icons inside badge
- Two action buttons: 
  [Konfirmasi] green filled button
  [Tolak] red outlined button
NO emoji anywhere on this screen.
```

---

**S18 — Detail Pesanan (Fix icons + Pengiriman Update):**

```
Top app bar: Back arrow + "Detail Pesanan #WLK-0042"

Customer section: avatar + name + address (no emoji prefix)

Delivery method section (IMPORTANT UPDATE):
Show selected delivery as: "Antar Sendiri oleh Mitra"
Below delivery method, add ONGKOS KIRIM section:
  Label: "Ongkos Kirim"
  Sub label: "Jarak ke customer: 1.2 km"
  Input field with Rp prefix — pre-filled with 
    suggested price: "Rp 6.000"
  Small helper text: 
    "Kamu bisa sesuaikan ongkos kirim berdasarkan jarak"
  Distance-based suggestion chips below input:
    [< 1 km → Rp 3.000] [1-2 km → Rp 6.000] 
    [2-3 km → Rp 9.000] [> 3 km → Rp 12.000]
  Currently selected: "1-2 km → Rp 6.000" 
    highlighted in green
  Note: "Ongkos kirim yang kamu tentukan akan 
    dikonfirmasi customer sebelum pesanan diproses"

Items section: product photo + name + qty + price 
  (real photos, no emoji)

Notes from customer: shown in light yellow box, 
  text only, no emoji

Total section:
  Subtotal: Rp 58.000
  Ongkos Kirim: Rp 6.000 (editable via field above)
  Total: Rp 64.000

Action buttons (no emoji):
  Primary: "Tandai Sedang Dikirim" — green filled
  Secondary: "Chat ke Customer" — green outlined
```

---

**S19 — Kelola Stok & Flash Sale (Fix icons):**

```
Top app bar: Back arrow + "Stok & Flash Sale"

Stock section header: "Update Stok Hari Ini" 
  (text only, no emoji)
Each product row:
  Real product photo thumbnail (40x40px circle)
  Product name + current stock number
  [ − ] [stock number] [ + ] stepper component
  NO emoji anywhere

Divider line between sections.

Flash Sale section header: "Flash Sale Lokal" 
  (text only, no emoji)
Amber tint background card with:
  Toggle switch: "Aktifkan Flash Sale"
  When toggle ON, fields appear:
    - Product selector dropdown (shows product photo + name)
    - Discount % input (number field with % suffix)
    - End time picker: "Habis pukul 17.00"
  Preview notification card (amber bg, no emoji):
    Text: "Notifikasi akan dikirim ke customer 
      dalam radius 2 km dari warungmu"
    Shows estimated reach: "± 47 customer"
  "Aktifkan Flash Sale Sekarang" amber filled button
```

---

**S20 — Laporan Penjualan (Fix icons):**

```
Top app bar: Back arrow + "Laporan Penjualan" + 
  export icon right

Date range tabs: Hari Ini / Minggu Ini / Bulan Ini
(text only tabs, NO emoji)

Summary cards row (3 cards):
  Card 1: "Total Pendapatan" — Rp 1.240.000
  Card 2: "Total Transaksi" — 38 pesanan  
  Card 3: "Rata-rata Order" — Rp 32.600
  Use proper chart/money icons from icon library inside cards
  NO emoji

Bar chart: clean 7-bar weekly chart
  X axis: labels Sen Sel Rab Kam Jum Sab Min
  Y axis: Rp values
  Active bar: solid green
  Inactive bars: light green
  Today's bar: darker green with value label on top

Top Produk section:
  Ranking list with:
    Rank number (1, 2, 3) in colored circle
    Real product photo thumbnail
    Product name
    "XX terjual" in gray text
  NO emoji, NO trophy emoji — use clean numbered ranking

Bottom: "Unduh Laporan" outlined button with 
  download icon (proper icon)
```

---

