/**
 * WARLOK COLOR PALETTE
 * Centralized color constants for consistent branding
 */

export const COLORS = {
  // Primary Brand Colors
  primary: {
    main: "#1B5E20",      // Dark Green - Main brand color
    light: "#43A047",     // Light Green - Secondary actions
    lighter: "#F1F8E9",   // Very Light Green - Backgrounds
  },

  // Accent Colors
  accent: {
    orange: "#FF6F00",    // Flash sale & promotions
    red: "#DC2626",       // Errors & destructive actions
  },

  // Status Colors
  status: {
    success: "#1B5E20",   // Green - Success/Open
    warning: "#F59E0B",   // Orange - Warning/Break
    error: "#DC2626",     // Red - Error/Closed
  },

  // Neutral Colors
  neutral: {
    black: "#1B1B1B",     // Text primary
    gray: {
      50: "#F9FAFB",
      100: "#F3F4F6",
      200: "#E5E7EB",
      300: "#D1D5DB",
      400: "#9CA3AF",
      500: "#6B7280",
      600: "#4B5563",
      700: "#374151",
      800: "#1F2937",
      900: "#111827",
    },
    white: "#FFFFFF",
  },

  // Background Colors
  background: {
    primary: "#FFFFFF",
    secondary: "#F1F8E9",
    tertiary: "#F9FAFB",
  },
} as const;
