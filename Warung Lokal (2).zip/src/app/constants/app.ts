/**
 * WARLOK APP CONSTANTS
 * Centralized app configuration and constants
 */

export const APP_CONFIG = {
  name: "Warlok — Warung Lokal",
  tagline: "Warungmu, Dekat di Genggaman",
  version: "1.0.0",
  buildVersion: "2024.12",
  adminPassword: "admin2024",
} as const;

export const LOCATION = {
  default: "Menteng, Jakarta Pusat",
} as const;

export const DELIVERY_COSTS = {
  antarSendiri: 5000,
  ojekOnline: 12000,
  ambilSendiri: 0,
} as const;

export const RADIUS_OPTIONS = ["500 m", "1 km", "2 km", "5 km", "10 km"] as const;

export const NAVIGATION_PATHS = {
  // Customer paths
  customer: {
    home: "/home",
    login: "/login",
    search: "/search",
    cart: "/cart",
    checkout: "/checkout",
    orders: "/orders",
    favorites: "/favorites",
    profile: "/profile",
    orderConfirmation: "/order-confirmation",
  },
  // Mitra paths
  mitra: {
    register: "/mitra/register",
    dashboard: "/mitra/dashboard",
    products: "/mitra/products",
    orders: "/mitra/orders",
    reports: "/mitra/reports",
    profile: "/mitra/profile",
  },
  // Admin paths
  admin: {
    dashboard: "/admin/dashboard",
    verification: "/admin/verification",
    categories: "/admin/categories",
  },
} as const;

export const PAYMENT_METHODS = [
  { id: "transfer", label: "Transfer Bank" },
  { id: "cod", label: "COD (Bayar di Tempat)" },
  { id: "dompet", label: "Dompet Digital" },
] as const;

export const DELIVERY_METHODS = [
  {
    id: "antar",
    icon: "",
    label: "Antar Sendiri",
    description: "Diantar langsung oleh mitra warung",
    note: "Ongkir ditentukan oleh mitra",
    estimatedCost: 6000,
    estimatedTime: "~30-45 menit",
  },
  {
    id: "ojek",
    icon: "",
    label: "Ojek Online",
    description: "Estimasi 30-60 menit",
    cost: 12000,
  },
  {
    id: "ambil",
    icon: "",
    label: "Ambil Sendiri",
    description: "Datang langsung ke warung",
    cost: 0,
  },
] as const;
