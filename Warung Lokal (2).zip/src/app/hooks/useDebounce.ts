/**
 * USE DEBOUNCE HOOK
 * Custom hook for debouncing rapidly changing values
 *
 * Usage:
 * const debouncedSearchQuery = useDebounce(searchQuery, 500);
 */

import { useState, useEffect } from "react";

export function useDebounce<T>(value: T, delay: number = 500): T {
  const [debouncedValue, setDebouncedValue] = useState<T>(value);

  useEffect(() => {
    // Set up the timeout
    const handler = setTimeout(() => {
      setDebouncedValue(value);
    }, delay);

    // Clean up the timeout if value changes before delay expires
    return () => {
      clearTimeout(handler);
    };
  }, [value, delay]);

  return debouncedValue;
}
