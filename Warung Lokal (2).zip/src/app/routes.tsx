import { createBrowserRouter, Navigate } from "react-router";
import { lazy, Suspense } from "react";

// Loading component for lazy-loaded routes
function RouteLoader() {
  return (
    <div className="flex items-center justify-center min-h-screen bg-[#F1F8E9]">
      <div className="text-center">
        <div className="w-16 h-16 border-4 border-[#1B5E20] border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
        <p className="text-gray-600">Memuat...</p>
      </div>
    </div>
  );
}

// Wrapper component to add Suspense boundary
function LazyRoute({ Component }: { Component: React.ComponentType }) {
  return (
    <Suspense fallback={<RouteLoader />}>
      <Component />
    </Suspense>
  );
}

// Customer screens
import { OnboardingScreen } from "./screens/customer/OnboardingScreen";
import { LoginScreen } from "./screens/customer/LoginScreen";
import { HomeScreen } from "./screens/customer/HomeScreen";
import { SearchScreen } from "./screens/customer/SearchScreen";
import { WarungProfileScreen } from "./screens/customer/WarungProfileScreen";
import { ProductDetailScreen } from "./screens/customer/ProductDetailScreen";
import { CartScreen } from "./screens/customer/CartScreen";
import { CheckoutScreen } from "./screens/customer/CheckoutScreen";
import { OrderConfirmationScreen } from "./screens/customer/OrderConfirmationScreen";
import { TrackingScreen } from "./screens/customer/TrackingScreen";
import { OrderHistoryScreen } from "./screens/customer/OrderHistoryScreen";
import { CustomerProfileScreen } from "./screens/customer/CustomerProfileScreen";
import { FavoritesScreen } from "./screens/customer/FavoritesScreen";

// Customer additional screens (CS1-CS10)
// Lazy-loaded chat screen
const ChatKeWarung = lazy(() => import("./components/customer/ChatKeWarung"));
import SemuaProduk from "./components/customer/SemuaProduk";
import PesananAktif from "./components/customer/PesananAktif";
import MetodePembayaran from "./components/customer/MetodePembayaran";
import AlamatSaya from "./components/customer/AlamatSaya";
import NotifikasiCustomer from "./components/customer/NotifikasiCustomer";
import Keamanan from "./components/customer/Keamanan";
import Bantuan from "./components/customer/Bantuan";
import TentangWarlok from "./components/customer/TentangWarlok";
import SyaratKetentuan from "./components/customer/SyaratKetentuan";

// Mitra screens
import { MitraRegisterScreen } from "./screens/mitra/MitraRegisterScreen";
import { MitraDashboardScreen } from "./screens/mitra/MitraDashboardScreen";
import { MitraProductsScreen } from "./screens/mitra/MitraProductsScreen";
import { MitraAddProductScreen } from "./screens/mitra/MitraAddProductScreen";
import { MitraOrdersScreen } from "./screens/mitra/MitraOrdersScreen";
import { MitraOrderDetailScreen } from "./screens/mitra/MitraOrderDetailScreen";
import { MitraStockFlashSaleScreen } from "./screens/mitra/MitraStockFlashSaleScreen";
// Lazy-loaded heavy screens
const MitraReportsScreen = lazy(() =>
  import("./screens/mitra/MitraReportsScreen").then((m) => ({ default: m.MitraReportsScreen }))
);
import { MitraProfileScreen } from "./screens/mitra/MitraProfileScreen";

// Mitra additional screens (MS1-MS9)
import OnboardingStep2 from "./components/mitra/OnboardingStep2";
import OnboardingStep3 from "./components/mitra/OnboardingStep3";
import OnboardingStep4 from "./components/mitra/OnboardingStep4";
import KonfirmasiSedangDikirim from "./components/mitra/KonfirmasiSedangDikirim";
// Lazy-loaded chat screen
const ChatKeCustomer = lazy(() => import("./components/mitra/ChatKeCustomer"));
import EditProfilWarung from "./components/mitra/EditProfilWarung";
import InformasiWarung from "./components/mitra/InformasiWarung";
import PengaturanMitra from "./components/mitra/PengaturanMitra";
import BantuanMitra from "./components/mitra/BantuanMitra";
import TentangWarlokMitra from "./components/mitra/TentangWarlokMitra";
import SyaratKetentuanMitra from "./components/mitra/SyaratKetentuanMitra";

// Admin screens - lazy loaded (admin-only screens)
const AdminDashboardScreen = lazy(() =>
  import("./screens/admin/AdminDashboardScreen").then((m) => ({ default: m.AdminDashboardScreen }))
);
const AdminVerificationScreen = lazy(() =>
  import("./screens/admin/AdminVerificationScreen").then((m) => ({ default: m.AdminVerificationScreen }))
);
const AdminCategoryScreen = lazy(() =>
  import("./screens/admin/AdminCategoryScreen").then((m) => ({ default: m.AdminCategoryScreen }))
);

export const router = createBrowserRouter([
  {
    path: "/",
    element: <OnboardingScreen />,
    errorElement: <Navigate to="/" replace />,
  },
  // Customer routes
  {
    path: "/login",
    element: <LoginScreen />,
  },
  {
    path: "/home",
    element: <HomeScreen />,
  },
  {
    path: "/search",
    element: <SearchScreen />,
  },
  {
    path: "/warung/:id",
    element: <WarungProfileScreen />,
  },
  {
    path: "/product/:id",
    element: <ProductDetailScreen />,
  },
  {
    path: "/cart",
    element: <CartScreen />,
  },
  {
    path: "/checkout",
    element: <CheckoutScreen />,
  },
  {
    path: "/order-confirmation",
    element: <OrderConfirmationScreen />,
  },
  {
    path: "/tracking/:orderId",
    element: <TrackingScreen />,
  },
  {
    path: "/orders",
    element: <OrderHistoryScreen />,
  },
  {
    path: "/favorites",
    element: <FavoritesScreen />,
  },
  {
    path: "/profile",
    element: <CustomerProfileScreen />,
  },
  // Customer additional routes (CS1-CS10)
  {
    path: "/warung/:warungId/chat",
    element: <LazyRoute Component={ChatKeWarung} />,
  },
  {
    path: "/warung/:warungId/produk",
    element: <SemuaProduk />,
  },
  {
    path: "/warung/:warungId/produk/:productId",
    element: <ProductDetailScreen />,
  },
  {
    path: "/pesanan-aktif",
    element: <PesananAktif />,
  },
  {
    path: "/metode-pembayaran",
    element: <MetodePembayaran />,
  },
  {
    path: "/alamat-saya",
    element: <AlamatSaya />,
  },
  {
    path: "/notifikasi",
    element: <NotifikasiCustomer />,
  },
  {
    path: "/keamanan",
    element: <Keamanan />,
  },
  {
    path: "/bantuan",
    element: <Bantuan />,
  },
  {
    path: "/tentang-warlok",
    element: <TentangWarlok />,
  },
  {
    path: "/syarat-ketentuan",
    element: <SyaratKetentuan />,
  },
  // Mitra routes
  {
    path: "/mitra/register",
    element: <MitraRegisterScreen />,
  },
  {
    path: "/mitra/dashboard",
    element: <MitraDashboardScreen />,
  },
  {
    path: "/mitra/products",
    element: <MitraProductsScreen />,
  },
  {
    path: "/mitra/add-product",
    element: <MitraAddProductScreen />,
  },
  {
    path: "/mitra/orders",
    element: <MitraOrdersScreen />,
  },
  {
    path: "/mitra/order/:orderId",
    element: <MitraOrderDetailScreen />,
  },
  {
    path: "/mitra/stock-flashsale",
    element: <MitraStockFlashSaleScreen />,
  },
  {
    path: "/mitra/reports",
    element: <LazyRoute Component={MitraReportsScreen} />,
  },
  {
    path: "/mitra/profile",
    element: <MitraProfileScreen />,
  },
  // Mitra additional routes (MS1-MS9)
  {
    path: "/mitra/onboarding/step2",
    element: <OnboardingStep2 />,
  },
  {
    path: "/mitra/onboarding/step3",
    element: <OnboardingStep3 />,
  },
  {
    path: "/mitra/onboarding/step4",
    element: <OnboardingStep4 />,
  },
  {
    path: "/mitra/konfirmasi-sedang-dikirim",
    element: <KonfirmasiSedangDikirim />,
  },
  {
    path: "/mitra/chat/:customerId",
    element: <LazyRoute Component={ChatKeCustomer} />,
  },
  {
    path: "/mitra/edit-profil",
    element: <EditProfilWarung />,
  },
  {
    path: "/mitra/informasi-warung",
    element: <InformasiWarung />,
  },
  {
    path: "/mitra/pengaturan",
    element: <PengaturanMitra />,
  },
  {
    path: "/mitra/bantuan",
    element: <BantuanMitra />,
  },
  {
    path: "/mitra/tentang-warlok",
    element: <TentangWarlokMitra />,
  },
  {
    path: "/mitra/syarat-ketentuan",
    element: <SyaratKetentuanMitra />,
  },
  // Admin routes
  {
    path: "/admin",
    element: <Navigate to="/admin/dashboard" replace />,
  },
  {
    path: "/admin/dashboard",
    element: <LazyRoute Component={AdminDashboardScreen} />,
  },
  {
    path: "/admin/verification",
    element: <LazyRoute Component={AdminVerificationScreen} />,
  },
  {
    path: "/admin/categories",
    element: <LazyRoute Component={AdminCategoryScreen} />,
  },
  // Catch all - redirect to home
  {
    path: "*",
    element: <Navigate to="/" replace />,
  },
]);