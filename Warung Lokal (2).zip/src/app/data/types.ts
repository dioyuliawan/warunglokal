/**
 * TYPE DEFINITIONS
 * Core data types used throughout the app
 */

export interface Product {
  id: string;
  name: string;
  price: number;
  unit: string;
  stock: number;
  description: string;
  active: boolean;
  image: string;
  category: string;
  warungId: string;
}

export interface WarungData {
  id: string;
  name: string;
  ownerName: string;
  address: string;
  category: string;
  distance: string;
  rating: number;
  reviewCount: number;
  status: string;
  statusColor: "green" | "red" | "orange";
  isOpen: boolean;
  openTime: string;
  closeTime: string;
  image: string;
  heroImage: string;
  position: { top: string; left: string };
  ownerStory: string;
  establishedYear: string;
  verified: boolean;
}

export type WarungCategory =
  | "Makanan & Minuman"
  | "Bahan Makanan Segar"
  | "Toko Kelontong"
  | "Usaha Jasa Lokal";

export type WarungStatus = "BUKA" | "TUTUP" | "ISTIRAHAT";
