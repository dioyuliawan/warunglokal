/**
 * WARUNG DATA INDEX
 * Central export point for all warung and product data
 *
 * To add a new warung:
 * 1. Create a new file: warung-[name].ts
 * 2. Export WARUNG_[NAME] and PRODUCTS_[NAME]
 * 3. Import and add to ALL_WARUNGS and ALL_PRODUCTS arrays below
 */

import { WarungData, Product } from "../types";

// Import individual warung data
import { WARUNG_BU_TINI, PRODUCTS_WARUNG_BU_TINI } from "./warung-bu-tini";
import { WARUNG_PAK_HENDRA, PRODUCTS_PAK_HENDRA } from "../products"; // Will be migrated
import { WARUNG_TOKO_MAJU, PRODUCTS_TOKO_MAJU } from "../products"; // Will be migrated
import { WARUNG_MANG_UJANG, PRODUCTS_MANG_UJANG } from "../products"; // Will be migrated
import { WARUNG_BU_SARI, PRODUCTS_BU_SARI } from "../products"; // Will be migrated
import { WARUNG_LAUNDRY_BERSIH, PRODUCTS_LAUNDRY_BERSIH } from "../products"; // Will be migrated

/**
 * ALL WARUNGS
 * Complete list of all registered warungs in the system
 */
export const ALL_WARUNGS: WarungData[] = [
  WARUNG_BU_TINI,
  WARUNG_PAK_HENDRA,
  WARUNG_TOKO_MAJU,
  WARUNG_MANG_UJANG,
  WARUNG_BU_SARI,
  WARUNG_LAUNDRY_BERSIH,
];

/**
 * ALL PRODUCTS
 * Complete list of all products from all warungs
 */
export const ALL_PRODUCTS: Product[] = [
  ...PRODUCTS_WARUNG_BU_TINI,
  ...PRODUCTS_PAK_HENDRA,
  ...PRODUCTS_TOKO_MAJU,
  ...PRODUCTS_MANG_UJANG,
  ...PRODUCTS_BU_SARI,
  ...PRODUCTS_LAUNDRY_BERSIH,
];

/**
 * HELPER FUNCTIONS
 * Utility functions for accessing warung and product data
 */

/**
 * Get warung by ID
 * @param id - The warung ID
 * @returns Warung data or undefined if not found
 */
export function getWarungById(id: string): WarungData | undefined {
  return ALL_WARUNGS.find((w) => w.id === id);
}

/**
 * Get all active products for a specific warung
 * @param warungId - The warung ID
 * @returns Array of active products for the warung
 */
export function getProductsByWarungId(warungId: string): Product[] {
  return ALL_PRODUCTS.filter((p) => p.warungId === warungId && p.active);
}

/**
 * Get all products for a specific warung (including inactive)
 * @param warungId - The warung ID
 * @returns Array of all products for the warung
 */
export function getAllProductsByWarungId(warungId: string): Product[] {
  return ALL_PRODUCTS.filter((p) => p.warungId === warungId);
}

/**
 * Get product by ID
 * @param id - The product ID
 * @returns Product data or undefined if not found
 */
export function getProductById(id: string): Product | undefined {
  return ALL_PRODUCTS.find((p) => p.id === id);
}

/**
 * Get warungs by category
 * @param category - The category to filter by
 * @returns Array of warungs in the category
 */
export function getWarungsByCategory(category: string): WarungData[] {
  if (category === "all" || category === "Semua") {
    return ALL_WARUNGS;
  }
  return ALL_WARUNGS.filter((w) => w.category === category);
}

/**
 * Get open warungs
 * @returns Array of currently open warungs
 */
export function getOpenWarungs(): WarungData[] {
  return ALL_WARUNGS.filter((w) => w.isOpen);
}

/**
 * Search warungs and products
 * @param query - Search query string
 * @returns Object with matching warungs and products
 */
export function searchWarungsAndProducts(query: string): {
  warungs: WarungData[];
  products: Product[];
} {
  const lowercaseQuery = query.toLowerCase();

  const warungs = ALL_WARUNGS.filter(
    (w) =>
      w.name.toLowerCase().includes(lowercaseQuery) ||
      w.category.toLowerCase().includes(lowercaseQuery) ||
      w.address.toLowerCase().includes(lowercaseQuery)
  );

  const products = ALL_PRODUCTS.filter(
    (p) =>
      p.active &&
      (p.name.toLowerCase().includes(lowercaseQuery) ||
        p.description.toLowerCase().includes(lowercaseQuery) ||
        p.category.toLowerCase().includes(lowercaseQuery))
  );

  return { warungs, products };
}
