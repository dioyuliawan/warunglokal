// Master Product List - All Warungs
// Single source of truth for product data across Customer and Mitra flows
// Each warung has its own unique products - NO CROSS-CONTAMINATION

export interface Product {
  id: string;
  name: string;
  price: number;
  unit: string;
  stock: number;
  description: string;
  active: boolean;
  image: string;
  category: string;
  warungId: string; // Added to link products to specific warung
}

export interface WarungData {
  id: string;
  name: string;
  ownerName: string;
  address: string;
  category: string;
  distance: string;
  rating: number;
  reviewCount: number;
  status: string;
  statusColor: "green" | "red" | "orange";
  isOpen: boolean;
  openTime: string;
  closeTime: string;
  image: string;
  heroImage: string;
  position: { top: string; left: string };
  ownerStory: string;
  establishedYear: string;
  verified: boolean;
}

// ============================================
// WARUNG 1: WARUNG BU TINI
// Category: Makanan & Minuman
// ============================================
export const WARUNG_BU_TINI: WarungData = {
  id: "1",
  name: "Warung Bu Tini",
  ownerName: "Ibu Tini Rahayu",
  address: "Jl. Tebet Raya No. 12",
  category: "Makanan & Minuman",
  distance: "300m",
  rating: 4.8,
  reviewCount: 156,
  status: "BUKA — Tutup 20.00",
  statusColor: "green",
  isOpen: true,
  openTime: "06.00",
  closeTime: "20.00",
  image: "https://images.unsplash.com/photo-1661830974665-7da532cfaba2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxuYXNpJTIwcGFkYW5nJTIwYm93bCUyMGluZG9uZXNpYW4lMjBmb29kfGVufDF8fHx8MTc3NTAxMzg5MHww&ixlib=rb-4.1.0&q=80&w=1080",
  heroImage: "https://images.unsplash.com/photo-1661830974665-7da532cfaba2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxuYXNpJTIwcGFkYW5nJTIwYm93bCUyMGluZG9uZXNpYW4lMjBmb29kfGVufDF8fHx8MTc3NTAxMzg5MHww&ixlib=rb-4.1.0&q=80&w=1080",
  position: { top: "25%", left: "30%" },
  ownerStory: "Warung keluarga yang sudah berdiri sejak 2008. Kami menyajikan masakan rumahan dengan cita rasa khas Padang yang autentik. Semua masakan dibuat fresh setiap hari dengan bumbu racikan keluarga.",
  establishedYear: "2008",
  verified: true,
};

export const PRODUCTS_WARUNG_BU_TINI: Product[] = [
  {
    id: "w1_p1",
    warungId: "1",
    name: "Nasi Bungkus Ayam",
    price: 15000,
    unit: "porsi",
    stock: 30,
    description: "Nasi putih dengan ayam goreng, sambal, dan lalapan. Porsi pas untuk makan siang.",
    active: true,
    image: "https://images.unsplash.com/photo-1569058242252-623df46b5025?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRvbmVzaWFuJTIwbmFzaSUyMGF5YW0lMjBmcmllZCUyMGNoaWNrZW4lMjByaWNlJTIwcGxhdGV8ZW58MXx8fHwxNzgwMDAzMTc1fDA&ixlib=rb-4.1.0&q=80&w=1080",
    category: "Nasi Bungkus",
  },
  {
    id: "w1_p2",
    warungId: "1",
    name: "Nasi Bungkus Telur",
    price: 10000,
    unit: "porsi",
    stock: 35,
    description: "Nasi putih dengan telur goreng/dadar, sambal, dan lalapan. Menu ekonomis favorit.",
    active: true,
    image: "https://images.unsplash.com/photo-1661830948845-1eb54cd9e1fd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwzfHxpbmRvbmVzaWFuJTIwcmljZSUyMHdpdGglMjBlZ2clMjBuYXNpJTIwdGVsdXJ8ZW58MXx8fHwxNzgwMDAzMTc2fDA&ixlib=rb-4.1.0&q=80&w=1080",
    category: "Nasi Bungkus",
  },
  {
    id: "w1_p3",
    warungId: "1",
    name: "Ayam Goreng Kremes",
    price: 12000,
    unit: "potong",
    stock: 20,
    description: "Ayam goreng dengan bumbu kuning dan taburan kremes renyah. Enak dimakan dengan nasi hangat.",
    active: true,
    image: "https://images.unsplash.com/photo-1626082927389-6cd097cdc6ec?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmcmllZCUyMGNoaWNrZW4lMjBpbmRvbmVzaWFuJTIwY3Jpc3B5fGVufDF8fHx8MTc0NjUzMDY3MHww&ixlib=rb-4.1.0&q=80&w=1080",
    category: "Lauk Pauk",
  },
  {
    id: "w1_p4",
    warungId: "1",
    name: "Tempe Tahu Goreng",
    price: 5000,
    unit: "porsi (isi 5)",
    stock: 40,
    description: "Tempe dan tahu goreng renyah. Cocok untuk lauk atau cemilan.",
    active: true,
    image: "https://images.unsplash.com/photo-1690949237809-3f0336b9ba33?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmcmllZCUyMHRlbXBlaCUyMHRvZnUlMjBpbmRvbmVzaWFuJTIwZ29yZW5nfGVufDF8fHx8MTc4MDAwMzE3Nnww&ixlib=rb-4.1.0&q=80&w=1080",
    category: "Lauk Pauk",
  },
  {
    id: "w1_p5",
    warungId: "1",
    name: "Es Teh Manis",
    price: 3000,
    unit: "gelas",
    stock: 50,
    description: "Es teh manis segar, cocok untuk menemani makan siang.",
    active: true,
    image: "https://images.unsplash.com/photo-1556881286-fc6915169721?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpY2VkJTIwdGVhJTIwZ2xhc3N8ZW58MXx8fHwxNzc1MDEzODkwfDA&ixlib=rb-4.1.0&q=80&w=1080",
    category: "Minuman",
  },
  {
    id: "w1_p6",
    warungId: "1",
    name: "Es Jeruk Peras",
    price: 5000,
    unit: "gelas",
    stock: 30,
    description: "Jeruk peras asli tanpa pemanis buatan. Segar dan menyegarkan.",
    active: true,
    image: "https://images.unsplash.com/photo-1600271886742-f049cd451bba?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvcmFuZ2UlMjBqdWljZSUyMGdsYXNzfGVufDF8fHx8MTc3NTAxMzg5MHww&ixlib=rb-4.1.0&q=80&w=1080",
    category: "Minuman",
  },
];

// ============================================
// WARUNG 2: KIOS AYAM POTONG PAK HENDRA
// Category: Bahan Makanan Segar
// ============================================
export const WARUNG_PAK_HENDRA: WarungData = {
  id: "2",
  name: "Kios Ayam Potong Pak Hendra",
  ownerName: "Bapak Hendra Wijaya",
  address: "Jl. Tebet Barat Dalam No. 5",
  category: "Bahan Makanan Segar",
  distance: "450m",
  rating: 4.7,
  reviewCount: 98,
  status: "BUKA — Tutup 18.00",
  statusColor: "green",
  isOpen: true,
  openTime: "05.00",
  closeTime: "18.00",
  image: "https://images.unsplash.com/photo-1600986390025-f554510b3faa?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3aG9sZSUyMGZyZXNoJTIwcmF3JTIwY2hpY2tlbiUyMGN1dHRpbmclMjBib2FyZHxlbnwxfHx8fDE3NzUwMTM4ODR8MA&ixlib=rb-4.1.0&q=80&w=1080",
  heroImage: "https://images.unsplash.com/photo-1758346973307-f43d89b39800?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmcmVzaCUyMGNoaWNrZW4lMjBtZWF0JTIwbWFya2V0fGVufDF8fHx8MTc3NTAwNzAwNHww&ixlib=rb-4.1.0&q=80&w=1080",
  position: { top: "50%", left: "50%" },
  ownerStory: "Kios ayam potong kami sudah melayani warga sekitar sejak 2010. Ayam segar setiap hari langsung dari peternak lokal. Bisa potong sesuai permintaan.",
  establishedYear: "2010",
  verified: true,
};

export const PRODUCTS_PAK_HENDRA: Product[] = [
  {
    id: "w2_p1",
    warungId: "2",
    name: "Ayam Utuh Segar",
    price: 38000,
    unit: "ekor",
    stock: 15,
    description: "Ayam kampung segar dipotong hari ini. Langsung dari peternak lokal. Bisa request potongan sesuai kebutuhan.",
    active: true,
    image: "https://images.unsplash.com/photo-1600986390025-f554510b3faa?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3aG9sZSUyMGZyZXNoJTIwcmF3JTIwY2hpY2tlbiUyMGN1dHRpbmclMjBib2FyZHxlbnwxfHx8fDE3NzUwMTM4ODR8MA&ixlib=rb-4.1.0&q=80&w=1080",
    category: "Ayam Utuh",
  },
  {
    id: "w2_p2",
    warungId: "2",
    name: "Ayam Potong 1/2",
    price: 20000,
    unit: "potong",
    stock: 20,
    description: "Setengah ekor ayam segar, sudah dibersihkan. Cocok untuk 2-3 porsi.",
    active: true,
    image: "https://images.unsplash.com/photo-1584932894085-f095355f4c40?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoYWx2ZWQlMjByYXclMjBjaGlja2VuJTIwd29vZGVuJTIwYm9hcmR8ZW58MXx8fHwxNzc1MDEzODg1fDA&ixlib=rb-4.1.0&q=80&w=1080",
    category: "Potongan",
  },
  {
    id: "w2_p3",
    warungId: "2",
    name: "Dada Ayam Fillet",
    price: 25000,
    unit: "250gr",
    stock: 12,
    description: "Dada ayam tanpa tulang dan tanpa kulit. Ideal untuk diet dan masakan sehat.",
    active: true,
    image: "https://images.unsplash.com/photo-1675984491214-609854c3ab8d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaGlja2VuJTIwYnJlYXN0JTIwZmlsbGV0JTIwc2xpY2VkJTIwd2hpdGUlMjBwbGF0ZXxlbnwxfHx8fDE3NzUwMTM4ODZ8MA&ixlib=rb-4.1.0&q=80&w=1080",
    category: "Potongan",
  },
  {
    id: "w2_p4",
    warungId: "2",
    name: "Hati & Ampela",
    price: 10000,
    unit: "250gr",
    stock: 8,
    description: "Hati dan ampela ayam segar, dibersihkan dan siap masak.",
    active: true,
    image: "https://images.unsplash.com/photo-1640261402285-d3ac38770c4f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaGlja2VuJTIwbGl2ZXIlMjBnaXp6YXJkJTIwYm93bCUyMHJhd3xlbnwxfHx8fDE3NzUwMTM4ODZ8MA&ixlib=rb-4.1.0&q=80&w=1080",
    category: "Jeroan & Lainnya",
  },
  {
    id: "w2_p5",
    warungId: "2",
    name: "Ceker Ayam",
    price: 8000,
    unit: "250gr",
    stock: 10,
    description: "Ceker ayam segar, cocok untuk soto, semur, atau digoreng.",
    active: true,
    image: "https://images.unsplash.com/photo-1722411488140-f0beb2521814?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaGlja2VuJTIwZmVldCUyMHRyYXklMjBhc2lhbiUyMG1hcmtldHxlbnwxfHx8fDE3NzUwMTM4ODd8MA&ixlib=rb-4.1.0&q=80&w=1080",
    category: "Jeroan & Lainnya",
  },
];

// ============================================
// WARUNG 3: TOKO KELONTONG MAJU
// Category: Toko Kelontong
// ============================================
export const WARUNG_TOKO_MAJU: WarungData = {
  id: "3",
  name: "Toko Kelontong Maju",
  ownerName: "Bapak Suparman",
  address: "Jl. Tebet Utara No. 3",
  category: "Toko Kelontong",
  distance: "600m",
  rating: 4.6,
  reviewCount: 124,
  status: "TUTUP — Buka besok 07.00",
  statusColor: "red",
  isOpen: false,
  openTime: "07.00",
  closeTime: "21.00",
  image: "https://images.unsplash.com/photo-1761992678011-fa9668aaa0ab?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxncm9jZXJ5JTIwc2hlbHZlcyUyMHJpY2UlMjBvaWwlMjBzdWdhciUyMHBhY2thZ2VkJTIwZ29vZHN8ZW58MXx8fHwxNzc1MDEzODkxfDA&ixlib=rb-4.1.0&q=80&w=1080",
  heroImage: "https://images.unsplash.com/photo-1753288589313-3030a6d3c1d7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRvbmVzaWFuJTIwZ3JvY2VyeSUyMHN0b3JlfGVufDF8fHx8MTc3NTAxMDM3NHww&ixlib=rb-4.1.0&q=80&w=1080",
  position: { top: "65%", left: "70%" },
  ownerStory: "Toko kelontong lengkap yang melayani kebutuhan sehari-hari warga sekitar. Dari beras, minyak, gula, hingga kebutuhan dapur lainnya. Harga bersahabat dan bisa kredit untuk pelanggan tetap.",
  establishedYear: "2005",
  verified: true,
};

export const PRODUCTS_TOKO_MAJU: Product[] = [
  {
    id: "w3_p1",
    warungId: "3",
    name: "Minyak Goreng 2L",
    price: 32000,
    unit: "botol",
    stock: 25,
    description: "Minyak goreng berkualitas untuk kebutuhan memasak sehari-hari.",
    active: true,
    image: "https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb29raW5nJTIwb2lsJTIwYm90dGxlfGVufDF8fHx8MTc3NTAxMzg5MXww&ixlib=rb-4.1.0&q=80&w=1080",
    category: "Bahan Pokok",
  },
  {
    id: "w3_p2",
    warungId: "3",
    name: "Gula Pasir 1kg",
    price: 15000,
    unit: "pack",
    stock: 40,
    description: "Gula pasir halus untuk kebutuhan memasak dan minuman.",
    active: true,
    image: "https://images.unsplash.com/photo-1673791031093-eb8eefa60083?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwyfHx3aGl0ZSUyMHN1Z2FyJTIwZ3JhbnVsYXRlZCUyMHBpbGV8ZW58MXx8fHwxNzgwMDAzMTkyfDA&ixlib=rb-4.1.0&q=80&w=1080",
    category: "Bahan Pokok",
  },
  {
    id: "w3_p3",
    warungId: "3",
    name: "Beras 5kg",
    price: 65000,
    unit: "pack",
    stock: 30,
    description: "Beras premium kualitas terbaik, pulen dan wangi. Cocok untuk nasi sehari-hari.",
    active: true,
    image: "https://images.unsplash.com/photo-1586201375761-83865001e31c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyaWNlJTIwYmFnJTIwd2hpdGV8ZW58MXx8fHwxNzc1MDEzODkxfDA&ixlib=rb-4.1.0&q=80&w=1080",
    category: "Bahan Pokok",
  },
  {
    id: "w3_p4",
    warungId: "3",
    name: "Sabun Lifebuoy",
    price: 8000,
    unit: "batang",
    stock: 50,
    description: "Sabun mandi Lifebuoy dengan perlindungan antibakteri.",
    active: true,
    image: "https://images.unsplash.com/photo-1618840313409-66c0d92d6f26?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzb2FwJTIwYmFycyUyMGh5Z2llbmUlMjBjbGVhbnxlbnwxfHx8fDE3ODAwMDMyMDB8MA&ixlib=rb-4.1.0&q=80&w=1080",
    category: "Kebersihan",
  },
  {
    id: "w3_p5",
    warungId: "3",
    name: "Indomie Goreng",
    price: 3000,
    unit: "bungkus",
    stock: 100,
    description: "Mie instan goreng favorit Indonesia. Rasa original yang legendaris.",
    active: true,
    image: "https://images.unsplash.com/photo-1628610688436-e635552020fc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwyfHxpbnN0YW50JTIwbm9vZGxlcyUyMHJhbWVuJTIwcGFja2FnZXxlbnwxfHx8fDE3ODAwMDMyMDF8MA&ixlib=rb-4.1.0&q=80&w=1080",
    category: "Makanan Instan",
  },
  {
    id: "w3_p6",
    warungId: "3",
    name: "Telur Ayam",
    price: 28000,
    unit: "1kg (isi 16)",
    stock: 15,
    description: "Telur ayam negeri segar, ukuran sedang. Cocok untuk berbagai masakan.",
    active: true,
    image: "https://images.unsplash.com/photo-1582722872445-44dc5f7e3c8f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlZ2dzJTIwdHJheSUyMGZyZXNofGVufDF8fHx8MTc3NTAxMzg5Mnww&ixlib=rb-4.1.0&q=80&w=1080",
    category: "Protein & Telur",
  },
  {
    id: "w3_p7",
    warungId: "3",
    name: "Kecap ABC",
    price: 18000,
    unit: "botol 600ml",
    stock: 20,
    description: "Kecap manis ABC kualitas premium untuk masakan Indonesia.",
    active: true,
    image: "https://images.unsplash.com/photo-1638324396179-61035bc1e645?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwyfHxzb3klMjBzYXVjZSUyMGJvdHRsZSUyMGtlY2FwfGVufDF8fHx8MTc4MDAwMzIwMXww&ixlib=rb-4.1.0&q=80&w=1080",
    category: "Bumbu & Saus",
  },
];

// ============================================
// WARUNG 4: WARUNG SATE MANG UJANG
// Category: Makanan & Minuman
// ============================================
export const WARUNG_MANG_UJANG: WarungData = {
  id: "4",
  name: "Warung Sate Mang Ujang",
  ownerName: "Bapak Ujang Suhendar",
  address: "Jl. Tebet Raya No. 45",
  category: "Makanan & Minuman",
  distance: "800m",
  rating: 4.9,
  reviewCount: 203,
  status: "BUKA — Tutup 22.00",
  statusColor: "green",
  isOpen: true,
  openTime: "16.00",
  closeTime: "22.00",
  image: "https://images.unsplash.com/photo-1636301175138-08aba8191957?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRvbmVzaWFuJTIwc2F0YXklMjBncmlsbGVkJTIwc2tld2Vyc3xlbnwxfHx8fDE3NzUwMTM4OTZ8MA&ixlib=rb-4.1.0&q=80&w=1080",
  heroImage: "https://images.unsplash.com/photo-1636301175138-08aba8191957?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRvbmVzaWFuJTIwc2F0YXklMjBncmlsbGVkJTIwc2tld2Vyc3xlbnwxfHx8fDE3NzUwMTM4OTZ8MA&ixlib=rb-4.1.0&q=80&w=1080",
  position: { top: "70%", left: "35%" },
  ownerStory: "Warung sate legendaris sejak 1998. Resep bumbu sate turun temurun dari Mang Ujang sendiri. Daging sapi pilihan dibakar dengan arang khusus untuk cita rasa yang sempurna.",
  establishedYear: "1998",
  verified: true,
};

export const PRODUCTS_MANG_UJANG: Product[] = [
  {
    id: "w4_p1",
    warungId: "4",
    name: "Sate Ayam 10 tusuk",
    price: 25000,
    unit: "10 tusuk",
    stock: 30,
    description: "Sate ayam dengan bumbu kacang spesial. Lebih lembut dan cocok untuk anak-anak.",
    active: true,
    image: "https://images.unsplash.com/photo-1603360946369-dc9bb6258143?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaGlja2VuJTIwc2F0YXklMjBza2V3ZXJzfGVufDF8fHx8MTc3NTAxMzg5Nnww&ixlib=rb-4.1.0&q=80&w=1080",
    category: "Sate",
  },
  {
    id: "w4_p2",
    warungId: "4",
    name: "Sate Kambing 10 tusuk",
    price: 45000,
    unit: "10 tusuk",
    stock: 20,
    description: "Sate kambing muda tanpa prengus. Cocok untuk pecinta daging kambing.",
    active: true,
    image: "https://images.unsplash.com/photo-1529563021893-cc83c992d75d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRvbmVzaWFuJTIwc2F0YXklMjBnb2F0JTIwc2tld2VycyUyMHNhdGUlMjBrYW1iaW5nfGVufDF8fHx8MTc4MDAwMzE3N3ww&ixlib=rb-4.1.0&q=80&w=1080",
    category: "Sate",
  },
  {
    id: "w4_p3",
    warungId: "4",
    name: "Sate Taichan",
    price: 8000,
    unit: "porsi",
    stock: 35,
    description: "Sate ayam taichan dengan bumbu kecap pedas, tanpa bumbu kacang. Cocok untuk yang suka rasa simple dan pedas.",
    active: true,
    image: "https://images.unsplash.com/photo-1696385793103-71f51f6fd3b7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwzfHxzYXRlJTIwdGFpY2hhbiUyMGluZG9uZXNpYW4lMjBzYXRheSUyMGNoaWNrZW4lMjBza2V3ZXJzfGVufDF8fHx8MTc4MDAwMzc3M3ww&ixlib=rb-4.1.0&q=80&w=1080",
    category: "Sate",
  },
  {
    id: "w4_p4",
    warungId: "4",
    name: "Nasi Goreng Sate",
    price: 18000,
    unit: "porsi",
    stock: 25,
    description: "Nasi goreng khas warung sate dengan bumbu kacang dan potongan daging sate.",
    active: true,
    image: "https://images.unsplash.com/photo-1647093953000-9065ed6f85ef?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxuYXNpJTIwZ29yZW5nJTIwaW5kb25lc2lhbiUyMGZyaWVkJTIwcmljZSUyMHNhdGF5fGVufDF8fHx8MTc4MDAwMzE5MXww&ixlib=rb-4.1.0&q=80&w=1080",
    category: "Nasi & Lontong",
  },
  {
    id: "w4_p5",
    warungId: "4",
    name: "Sate Campur",
    price: 35000,
    unit: "10 tusuk",
    stock: 15,
    description: "Kombinasi sate ayam dan kambing dalam satu porsi. Best value!",
    active: true,
    image: "https://images.unsplash.com/photo-1636301175138-08aba8191957?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRvbmVzaWFuJTIwc2F0YXklMjBncmlsbGVkJTIwc2tld2Vyc3xlbnwxfHx8fDE3NzUwMTM4OTZ8MA&ixlib=rb-4.1.0&q=80&w=1080",
    category: "Sate",
  },
  {
    id: "w4_p6",
    warungId: "4",
    name: "Es Kelapa Muda",
    price: 8000,
    unit: "gelas",
    stock: 40,
    description: "Es kelapa muda segar, manis alami. Sempurna untuk hilangkan dahaga.",
    active: true,
    image: "https://images.unsplash.com/photo-1662364368432-ebea02c6e1da?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb2NvbnV0JTIwd2F0ZXIlMjBkcmluayUyMHRyb3BpY2FsfGVufDF8fHx8MTc4MDAwMzIwMHww&ixlib=rb-4.1.0&q=80&w=1080",
    category: "Minuman",
  },
];

// ============================================
// WARUNG 5: KIOS SAYUR & BUAH BU SARI
// Category: Bahan Makanan Segar
// ============================================
export const WARUNG_BU_SARI: WarungData = {
  id: "5",
  name: "Kios Sayur & Buah Bu Sari",
  ownerName: "Ibu Sari Wulandari",
  address: "Jl. Tebet Timur Dalam No. 8",
  category: "Bahan Makanan Segar",
  distance: "950m",
  rating: 4.5,
  reviewCount: 87,
  status: "BUKA — Tutup 15.00",
  statusColor: "green",
  isOpen: true,
  openTime: "05.00",
  closeTime: "15.00",
  image: "https://images.unsplash.com/photo-1641417567586-b9686bc4bc91?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmcmVzaCUyMHZlZ2V0YWJsZXMlMjBrYW5na3VuZyUyMGJheWFtJTIwdG9tYXR8ZW58MXx8fHwxNzc1MDEzODkxfDA&ixlib=rb-4.1.0&q=80&w=1080",
  heroImage: "https://images.unsplash.com/photo-1641417567586-b9686bc4bc91?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmcmVzaCUyMHZlZ2V0YWJsZXMlMjBrYW5na3VuZyUyMGJheWFtJTIwdG9tYXR8ZW58MXx8fHwxNzc1MDEzODkxfDA&ixlib=rb-4.1.0&q=80&w=1080",
  position: { top: "20%", left: "65%" },
  ownerStory: "Menyediakan sayur dan buah segar setiap hari langsung dari petani. Semua produk fresh, tidak ada yang kemarin. Kami jamin kesegaran dan kualitas untuk keluarga Anda.",
  establishedYear: "2015",
  verified: true,
};

export const PRODUCTS_BU_SARI: Product[] = [
  {
    id: "w5_p1",
    warungId: "5",
    name: "Tomat",
    price: 8000,
    unit: "500gr",
    stock: 30,
    description: "Tomat merah segar dan matang sempurna. Cocok untuk masakan dan sambal.",
    active: true,
    image: "https://images.unsplash.com/photo-1582284540020-8acbe03f4924?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmcmVzaCUyMHRvbWF0b2VzJTIwcmVkJTIwdmVnZXRhYmxlc3xlbnwxfHx8fDE3ODAwMDMyMDJ8MA&ixlib=rb-4.1.0&q=80&w=1080",
    category: "Sayuran",
  },
  {
    id: "w5_p2",
    warungId: "5",
    name: "Wortel",
    price: 7000,
    unit: "500gr",
    stock: 25,
    description: "Wortel segar kaya vitamin A. Cocok untuk sup, jus, atau capcay.",
    active: true,
    image: "https://images.unsplash.com/photo-1598170845058-32b9d6a5da37?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
    category: "Sayuran",
  },
  {
    id: "w5_p3",
    warungId: "5",
    name: "Brokoli",
    price: 12000,
    unit: "500gr",
    stock: 20,
    description: "Brokoli segar kaya serat dan vitamin. Cocok untuk tumis, sup, atau salad.",
    active: true,
    image: "https://images.unsplash.com/photo-1685504445355-0e7bdf90d415?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxicm9jY29saSUyMGZyZXNoJTIwZ3JlZW4lMjB2ZWdldGFibGV8ZW58MXx8fHwxNzc5ODk1NzQ4fDA&ixlib=rb-4.1.0&q=80&w=1080",
    category: "Sayuran",
  },
  {
    id: "w5_p4",
    warungId: "5",
    name: "Cabai Merah",
    price: 15000,
    unit: "250gr",
    stock: 18,
    description: "Cabai merah segar untuk bumbu masakan dan sambal. Pedas dan harum.",
    active: true,
    image: "https://images.unsplash.com/photo-1583119022894-919a68a3d0e3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyZWQlMjBjaGlsaSUyMHBlcHBlcnMlMjBmcmVzaCUyMHNwaWN5fGVufDF8fHx8MTc4MDAwMzIxMXww&ixlib=rb-4.1.0&q=80&w=1080",
    category: "Sayuran",
  },
  {
    id: "w5_p5",
    warungId: "5",
    name: "Mangga Harum Manis",
    price: 20000,
    unit: "1kg",
    stock: 15,
    description: "Mangga harum manis matang sempurna. Manis dan segar.",
    active: true,
    image: "https://images.unsplash.com/photo-1601493700631-2b16ec4b4716?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYW5nbyUyMGZydWl0fGVufDF8fHx8MTc0NjUzMDczNXww&ixlib=rb-4.1.0&q=80&w=1080",
    category: "Buah-buahan",
  },
  {
    id: "w5_p6",
    warungId: "5",
    name: "Pisang Kepok",
    price: 10000,
    unit: "sisir (1kg)",
    stock: 12,
    description: "Pisang kepok matang, cocok untuk digoreng atau dikukus.",
    active: true,
    image: "https://images.unsplash.com/photo-1571771894821-ce9b6c11b08e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwbGFudGFpbiUyMGJhbmFuYXxlbnwxfHx8fDE3NDY1MzA3MzZ8MA&ixlib=rb-4.1.0&q=80&w=1080",
    category: "Buah-buahan",
  },
  {
    id: "w5_p7",
    warungId: "5",
    name: "Paket Sayur Sop",
    price: 12000,
    unit: "paket",
    stock: 20,
    description: "Paket sayur lengkap untuk membuat sop: kentang, wortel, kol, tomat, dan buncis.",
    active: true,
    image: "https://images.unsplash.com/photo-1597362925123-77861d3fbac7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2ZWdldGFibGUlMjBtaXglMjBmcmVzaHxlbnwxfHx8fDE3NDY1MzA3Mzd8MA&ixlib=rb-4.1.0&q=80&w=1080",
    category: "Paket Sayur",
  },
];

// ============================================
// WARUNG 6: LAUNDRY KILOAN BERSIH
// Category: Usaha Jasa Lokal
// ============================================
export const WARUNG_LAUNDRY_BERSIH: WarungData = {
  id: "6",
  name: "Laundry Kiloan Bersih",
  ownerName: "Ibu Rina Susanti",
  address: "Gang Tebet No. 7",
  category: "Usaha Jasa Lokal",
  distance: "1.2km",
  rating: 4.6,
  reviewCount: 72,
  status: "ISTIRAHAT — Buka lagi 13.00",
  statusColor: "orange",
  isOpen: false,
  openTime: "08.00",
  closeTime: "18.00",
  image: "https://images.unsplash.com/photo-1517677208171-0bc6725a3e60?w=1080&h=720&fit=crop",
  heroImage: "https://images.unsplash.com/photo-1545173168-9f1947eebb7f?w=1080&h=720&fit=crop",
  position: { top: "45%", left: "18%" },
  ownerStory: "Laundry kiloan dengan hasil bersih dan wangi. Kami gunakan deterjen berkualitas dan pewangi yang tahan lama. Gratis antar jemput untuk radius 1 km. Proses cepat 1-2 hari.",
  establishedYear: "2018",
  verified: true,
};

export const PRODUCTS_LAUNDRY_BERSIH: Product[] = [
  {
    id: "w6_p1",
    warungId: "6",
    name: "Cuci+Kering",
    price: 5000,
    unit: "per kg",
    stock: 999,
    description: "Cuci dan kering saja tanpa setrika. Selesai dalam 1-2 hari. Minimum 3 kg.",
    active: true,
    image: "https://images.unsplash.com/photo-1517677208171-0bc6725a3e60?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsYXVuZHJ5JTIwbWFjaGluZSUyMHdhc2hpbmd8ZW58MXx8fHwxNzQ2NTMwNzU5fDA&ixlib=rb-4.1.0&q=80&w=1080",
    category: "Laundry Kiloan",
  },
  {
    id: "w6_p2",
    warungId: "6",
    name: "Cuci+Kering+Setrika",
    price: 8000,
    unit: "per kg",
    stock: 999,
    description: "Paket lengkap cuci, kering, dan setrika rapi. Selesai 2-3 hari. Minimum 3 kg.",
    active: true,
    image: "https://images.unsplash.com/photo-1572689535562-3c54a15292d3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmb2xkZWQlMjBsYXVuZHJ5JTIwY2xvdGhlcyUyMHBsYXN0aWMlMjBiYWdzfGVufDF8fHx8MTc3NTAxMzg5Mnww&ixlib=rb-4.1.0&q=80&w=1080",
    category: "Laundry Kiloan",
  },
  {
    id: "w6_p3",
    warungId: "6",
    name: "Setrika Saja",
    price: 4000,
    unit: "per kg",
    stock: 999,
    description: "Hanya jasa setrika untuk pakaian yang sudah bersih. Rapi dan harum.",
    active: true,
    image: "https://images.unsplash.com/photo-1489274495757-95c7c837b101?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpcm9uJTIwaXJvbmluZyUyMGNsb3RoZXMlMjBsYXVuZHJ5fGVufDF8fHx8MTc4MDAwMzIxMXww&ixlib=rb-4.1.0&q=80&w=1080",
    category: "Laundry Kiloan",
  },
  {
    id: "w6_p4",
    warungId: "6",
    name: "Cuci Sepatu",
    price: 25000,
    unit: "per pasang",
    stock: 999,
    description: "Cuci sepatu sneakers hingga bersih maksimal. Treatment khusus untuk berbagai material.",
    active: true,
    image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzbmVha2VycyUyMGNsZWFuJTIwd2hpdGV8ZW58MXx8fHwxNzc1MDEzODk4fDA&ixlib=rb-4.1.0&q=80&w=1080",
    category: "Cuci Sepatu & Tas",
  },
  {
    id: "w6_p5",
    warungId: "6",
    name: "Cuci+Kering Mantel",
    price: 8000,
    unit: "per kg",
    stock: 999,
    description: "Layanan khusus cuci dan kering untuk mantel, jaket tebal, dan pakaian berbahan khusus. Treatment lembut dengan deterjen premium.",
    active: true,
    image: "https://images.unsplash.com/photo-1543076447-215ad9ba6923?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3aW50ZXIlMjBjb2F0JTIwamFja2V0JTIwaGFuZ2luZ3xlbnwxfHx8fDE3ODAwMDMyMTJ8MA&ixlib=rb-4.1.0&q=80&w=1080",
    category: "Layanan Khusus",
  },
];

// ============================================
// MASTER DATA AGGREGATORS
// ============================================

export const ALL_WARUNGS: WarungData[] = [
  WARUNG_BU_TINI,
  WARUNG_PAK_HENDRA,
  WARUNG_TOKO_MAJU,
  WARUNG_MANG_UJANG,
  WARUNG_BU_SARI,
  WARUNG_LAUNDRY_BERSIH,
];

export const ALL_PRODUCTS: Product[] = [
  ...PRODUCTS_WARUNG_BU_TINI,
  ...PRODUCTS_PAK_HENDRA,
  ...PRODUCTS_TOKO_MAJU,
  ...PRODUCTS_MANG_UJANG,
  ...PRODUCTS_BU_SARI,
  ...PRODUCTS_LAUNDRY_BERSIH,
];

// Helper functions
export function getWarungById(id: string): WarungData | undefined {
  return ALL_WARUNGS.find((w) => w.id === id);
}

export function getProductsByWarungId(warungId: string): Product[] {
  return ALL_PRODUCTS.filter((p) => p.warungId === warungId && p.active);
}

export function getAllProductsByWarungId(warungId: string): Product[] {
  return ALL_PRODUCTS.filter((p) => p.warungId === warungId);
}

export function getProductById(id: string): Product | undefined {
  return ALL_PRODUCTS.find((p) => p.id === id);
}

// For backward compatibility with Mitra flow (Pak Hendra)
export const MASTER_PRODUCTS = PRODUCTS_PAK_HENDRA;
export const PRODUCT_CATEGORIES = [
  "Semua Produk",
  "Ayam Utuh",
  "Potongan",
  "Jeroan & Lainnya",
];