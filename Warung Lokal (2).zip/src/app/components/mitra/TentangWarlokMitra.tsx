import { ArrowLeft, ChevronRight } from "lucide-react";
import { useNavigate } from "react-router";
import { useState } from "react";

export default function TentangWarlokMitra() {
  const navigate = useNavigate();
  const [tapCount, setTapCount] = useState(0);
  const [showAdminSheet, setShowAdminSheet] = useState(false);
  const [adminCode, setAdminCode] = useState("");

  const menuItems = [
    { title: "Syarat & Ketentuan Mitra", path: "/mitra/syarat-ketentuan" },
    { title: "Kebijakan Privasi", path: "#" },
    { title: "Lisensi Open Source", path: "#" }
  ];

  const socialMedia = [
    { name: "Instagram", icon: "" },
    { name: "Twitter", icon: "" },
    { name: "TikTok", icon: "" }
  ];

  const handleVersionTap = () => {
    const newCount = tapCount + 1;
    setTapCount(newCount);

    if (newCount >= 3) {
      setShowAdminSheet(true);
      setTapCount(0);
    }

    setTimeout(() => {
      setTapCount(0);
    }, 2000);
  };

  const handleAdminLogin = () => {
    if (adminCode === "admin2024") {
      setShowAdminSheet(false);
      navigate("/admin");
    } else {
      alert("Kode akses salah!");
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Top App Bar */}
      <div className="bg-white border-b border-gray-200 px-4 py-3 flex items-center gap-3 sticky top-0 z-10">
        <button onClick={() => navigate(-1)} aria-label="Kembali" className="p-1">
          <ArrowLeft className="w-5 h-5 text-gray-700" />
        </button>
        <h1 className="font-medium text-gray-900">Tentang Warlok</h1>
      </div>

      <div className="p-4">
        {/* Logo and Version */}
        <div className="text-center mb-8">
          <div className="w-24 h-24 bg-[#1B5E20] rounded-3xl mx-auto mb-4 flex items-center justify-center">
            <span className="text-white text-3xl font-bold">W</span>
          </div>
          <p className="text-sm text-gray-600 mb-1">Versi 1.0.0</p>
          <p className="font-medium text-gray-900 mb-2">Warungmu, Dekat di Genggaman</p>
        </div>

        {/* About Text */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 mb-6">
          <p className="text-sm text-gray-700 leading-relaxed mb-4">
            <span className="font-medium text-[#1B5E20]">Warlok — Warung Lokal</span> adalah
            marketplace hyperlokal yang menghubungkan UMKM lokal dengan pelanggan di sekitar
            mereka. Kami hadir untuk mendigitalkan kepercayaan lokal, bukan menggantinya.
          </p>
        </div>

        {/* Program Mitra Section */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 mb-6">
          <h3 className="font-medium text-gray-900 mb-2">Program Mitra Warlok</h3>
          <p className="text-sm text-gray-700 mb-4">
            Bergabung dengan ribuan mitra UMKM yang sudah terdigitalisasi bersama Warlok
          </p>
          <div className="grid grid-cols-2 gap-4">
            <div className="text-center p-3 bg-green-50 rounded-lg">
              <p className="text-2xl font-bold text-[#1B5E20] mb-1">142</p>
              <p className="text-xs text-gray-600">Mitra Aktif</p>
            </div>
            <div className="text-center p-3 bg-green-50 rounded-lg">
              <p className="text-2xl font-bold text-[#1B5E20] mb-1">89</p>
              <p className="text-xs text-gray-600">Transaksi Hari Ini</p>
            </div>
          </div>
        </div>

        {/* Menu List */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden mb-6">
          {menuItems.map((item, index) => (
            <button
              key={index}
              onClick={() => item.path !== "#" && navigate(item.path)}
              className={`w-full px-4 py-4 flex items-center justify-between hover:bg-gray-50 transition-colors ${
                index !== menuItems.length - 1 ? "border-b border-gray-200" : ""
              }`}
            >
              <span className="text-gray-900">{item.title}</span>
              <ChevronRight className="w-5 h-5 text-gray-400" />
            </button>
          ))}
        </div>

        {/* Social Media */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 mb-6">
          <h3 className="font-medium text-gray-900 mb-3 text-center">
            Ikuti Kami di Media Sosial
          </h3>
          <div className="flex justify-center gap-4">
            {socialMedia.map((social, index) => (
              <button
                key={index}
                className="px-4 py-2 bg-gray-100 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-200 transition-colors"
              >
                {social.name}
              </button>
            ))}
          </div>
        </div>

        {/* Legal Text */}
        <div className="text-center space-y-1">
          <p className="text-xs text-gray-500">© 2024 Warlok — Warung Lokal</p>
          <p className="text-xs text-gray-500">Dikembangkan di Indonesia</p>

          {/* Hidden Admin Entry - Tappable Version Text */}
          <p
            onClick={handleVersionTap}
            className="text-[10px] text-gray-400 cursor-default select-none pt-2"
          >
            v1.0.0 build 2024.12
          </p>
        </div>
      </div>

      {/* Admin Access Bottom Sheet */}
      {showAdminSheet && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-end">
          <div className="bg-white rounded-t-3xl w-full p-6">
            <div className="mb-4">
              <h2 className="font-medium text-gray-900 mb-2">Akses Panel Admin</h2>
              <p className="text-sm text-gray-600">
                Masukkan kode akses untuk melanjutkan
              </p>
            </div>
            <input
              type="password"
              value={adminCode}
              onChange={(e) => setAdminCode(e.target.value)}
              placeholder="Masukkan kode akses"
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1B5E20] focus:border-transparent mb-4"
            />
            <div className="flex gap-2">
              <button
                onClick={() => {
                  setShowAdminSheet(false);
                  setAdminCode("");
                }}
                className="flex-1 border border-gray-300 text-gray-700 py-3 rounded-lg font-medium hover:bg-gray-50 transition-colors"
              >
                Batal
              </button>
              <button
                onClick={handleAdminLogin}
                className="flex-1 bg-[#1B5E20] text-white py-3 rounded-lg font-medium hover:bg-[#2E7D32] transition-colors"
              >
                Masuk ke Admin Panel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
