import { ArrowLeft, Edit2, Star, MapPin, Clock } from "lucide-react";
import { useNavigate } from "react-router";

export default function InformasiWarung() {
  const navigate = useNavigate();

  const warungData = {
    id: "kios-ayam-pak-hendra",
    name: "Kios Ayam Potong Pak Hendra",
    image: "https://images.unsplash.com/photo-1604719312566-8912e9227c6a?w=800&h=400&fit=crop",
    category: "Bahan Makanan Segar",
    rating: 4.8,
    totalReviews: 127,
    isOpen: true,
    address: "Jl. Tebet Barat Dalam No. 5",
    distance: "0.3 km",
    story:
      "Kios ayam potong yang sudah berdiri sejak 2015. Menyediakan ayam segar berkualitas dengan harga terjangkau untuk warga sekitar.",
    products: [
      {
        id: 1,
        name: "Ayam Utuh Segar",
        price: "Rp 38.000",
        stock: "12 ekor",
        image: "https://images.unsplash.com/photo-1587593810167-a84920ea0781?w=200&h=200&fit=crop"
      },
      {
        id: 2,
        name: "Dada Fillet",
        price: "Rp 42.000",
        stock: "8 kg",
        image: "https://images.unsplash.com/photo-1604503468506-a8da13d82791?w=200&h=200&fit=crop"
      },
      {
        id: 3,
        name: "Paha Atas",
        price: "Rp 36.000",
        stock: "10 kg",
        image: "https://images.unsplash.com/photo-1587593810167-a84920ea0781?w=200&h=200&fit=crop"
      }
    ]
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Top App Bar */}
      <div className="bg-white border-b border-gray-200 px-4 py-3 flex items-center justify-between sticky top-0 z-10">
        <div className="flex items-center gap-3">
          <button onClick={() => navigate(-1)} aria-label="Kembali" className="p-1">
            <ArrowLeft className="w-5 h-5 text-gray-700" />
          </button>
          <h1 className="font-medium text-gray-900">Informasi Warung</h1>
        </div>
        <button
          onClick={() => navigate("/mitra/edit-profil")}
          aria-label="Edit"
          className="p-2 hover:bg-gray-100 rounded-full"
        >
          <Edit2 className="w-5 h-5 text-gray-700" />
        </button>
      </div>

      {/* Preview Note */}
      <div className="bg-amber-50 border border-amber-200 p-3 mx-4 mt-4 rounded-lg">
        <p className="text-sm text-amber-800">
          Ini adalah tampilan yang dilihat customer. Tap edit untuk mengubah informasi warungmu.
        </p>
      </div>

      {/* Customer View Preview */}
      <div className="p-4">
        {/* Hero Image */}
        <div className="bg-white rounded-xl overflow-hidden shadow-sm border border-gray-200 mb-4">
          <div className="relative h-48">
            <img
              src={warungData.image}
              alt={warungData.name}
              className="w-full h-full object-cover"
            />
          </div>

          {/* Info Section */}
          <div className="p-4">
            <div className="flex items-start justify-between mb-2">
              <div className="flex-1">
                <h2 className="font-medium text-gray-900 mb-1">
                  {warungData.name}
                </h2>
                <p className="text-sm text-gray-600">{warungData.category}</p>
              </div>
              <div className="flex items-center gap-1.5 bg-green-50 px-2 py-1 rounded-full">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                <span className="text-xs font-medium text-green-700">
                  {warungData.isOpen ? "Buka" : "Tutup"}
                </span>
              </div>
            </div>

            {/* Rating & Distance */}
            <div className="flex items-center gap-4 mb-3">
              <div className="flex items-center gap-1">
                <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                <span className="text-sm font-medium text-gray-900">
                  {warungData.rating}
                </span>
                <span className="text-sm text-gray-600">
                  ({warungData.totalReviews})
                </span>
              </div>
              <div className="flex items-center gap-1 text-gray-600">
                <MapPin className="w-4 h-4" />
                <span className="text-sm">{warungData.distance}</span>
              </div>
            </div>

            {/* Address */}
            <div className="flex items-start gap-2 text-sm text-gray-600 mb-3">
              <MapPin className="w-4 h-4 mt-0.5 flex-shrink-0" />
              <span>{warungData.address}</span>
            </div>

            {/* Operating Hours */}
            <div className="flex items-center gap-2 text-sm text-gray-600">
              <Clock className="w-4 h-4" />
              <span>Setiap hari 07.00-17.00</span>
            </div>
          </div>
        </div>

        {/* Story */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4 mb-4">
          <h3 className="font-medium text-gray-900 mb-2">Tentang Warung</h3>
          <p className="text-sm text-gray-700 leading-relaxed">
            {warungData.story}
          </p>
        </div>

        {/* Products Preview */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-medium text-gray-900">Produk</h3>
            <button className="text-sm text-[#1B5E20] font-medium">
              Lihat Semua
            </button>
          </div>
          <div className="grid grid-cols-3 gap-3">
            {warungData.products.map((product) => (
              <div
                key={product.id}
                className="border border-gray-200 rounded-lg overflow-hidden"
              >
                <div className="aspect-square bg-gray-100">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="p-2">
                  <p className="text-xs text-gray-900 line-clamp-2 mb-1">
                    {product.name}
                  </p>
                  <p className="text-xs font-medium text-[#1B5E20]">
                    {product.price}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
