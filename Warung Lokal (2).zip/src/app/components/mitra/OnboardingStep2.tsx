import { ArrowLeft, MapPin } from "lucide-react";
import { useNavigate } from "react-router";
import { useState } from "react";

export default function OnboardingStep2() {
  const navigate = useNavigate();
  const [openTime, setOpenTime] = useState("07:00");
  const [closeTime, setCloseTime] = useState("17:00");
  const [operatingHours, setOperatingHours] = useState({
    Mon: { enabled: true, open: "07:00", close: "17:00" },
    Tue: { enabled: true, open: "07:00", close: "17:00" },
    Wed: { enabled: true, open: "07:00", close: "17:00" },
    Thu: { enabled: true, open: "07:00", close: "17:00" },
    Fri: { enabled: true, open: "07:00", close: "17:00" },
    Sat: { enabled: true, open: "07:00", close: "17:00" },
    Sun: { enabled: true, open: "07:00", close: "17:00" }
  });

  const days = [
    { key: "Mon", label: "Sen" },
    { key: "Tue", label: "Sel" },
    { key: "Wed", label: "Rab" },
    { key: "Thu", label: "Kam" },
    { key: "Fri", label: "Jum" },
    { key: "Sat", label: "Sab" },
    { key: "Sun", label: "Min" }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Top App Bar */}
      <div className="bg-white border-b border-gray-200 px-4 py-3 flex items-center gap-3">
        <button onClick={() => navigate(-1)} className="p-1">
          <ArrowLeft className="w-5 h-5 text-gray-700" />
        </button>
        <h1 className="font-medium text-gray-900">Daftar Mitra</h1>
      </div>

      {/* Progress Bar */}
      <div className="bg-white px-4 py-4">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm text-gray-600">Langkah 2 dari 4</span>
          <span className="text-sm font-medium text-[#1B5E20]">50%</span>
        </div>
        <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
          <div className="h-full bg-[#1B5E20] w-1/2 transition-all duration-300"></div>
        </div>
      </div>

      <div className="p-4">
        <h2 className="text-xl font-medium text-gray-900 mb-6">
          Lokasi & Jam Operasional
        </h2>

        {/* Map Picker Section */}
        <div className="mb-6">
          <h3 className="font-medium text-gray-900 mb-3">Lokasi Warung</h3>
          <div className="bg-gray-200 rounded-lg h-48 mb-3 relative overflow-hidden">
            <div className="absolute inset-0 flex items-center justify-center">
              <MapPin className="w-12 h-12 text-[#1B5E20]" />
            </div>
            <div className="absolute bottom-0 left-0 right-0 bg-white bg-opacity-90 p-3 text-xs text-gray-700">
              Geser peta untuk memposisikan pin di lokasi warung Anda
            </div>
          </div>
          <div className="bg-white rounded-lg border border-gray-300 p-3">
            <p className="text-sm text-gray-700">
              Jl. Tebet Barat Dalam No. 5, Kel. Tebet Barat, Jakarta Selatan
            </p>
          </div>
        </div>

        {/* Operating Hours Section */}
        <div className="mb-6">
          <h3 className="font-medium text-gray-900 mb-3">Jam Operasional</h3>

          {/* Day Toggles */}
          <div className="bg-white rounded-lg border border-gray-300 p-4 mb-3">
            <div className="grid grid-cols-7 gap-2 mb-4">
              {days.map((day) => (
                <button
                  key={day.key}
                  onClick={() =>
                    setOperatingHours({
                      ...operatingHours,
                      [day.key]: {
                        ...operatingHours[day.key as keyof typeof operatingHours],
                        enabled: !operatingHours[day.key as keyof typeof operatingHours].enabled
                      }
                    })
                  }
                  className={`aspect-square rounded-lg text-xs font-medium transition-colors ${
                    operatingHours[day.key as keyof typeof operatingHours].enabled
                      ? "bg-[#1B5E20] text-white"
                      : "bg-gray-100 text-gray-400"
                  }`}
                >
                  {day.label}
                </button>
              ))}
            </div>

            {/* Time Picker */}
            <div className="flex items-center gap-3">
              <div className="flex-1">
                <label className="text-xs text-gray-600 mb-1 block">Buka</label>
                <input
                  type="time"
                  value={openTime}
                  onChange={(e) => setOpenTime(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1B5E20] focus:border-transparent"
                />
              </div>
              <span className="text-gray-400 mt-5">—</span>
              <div className="flex-1">
                <label className="text-xs text-gray-600 mb-1 block">Tutup</label>
                <input
                  type="time"
                  value={closeTime}
                  onChange={(e) => setCloseTime(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1B5E20] focus:border-transparent"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Next Button */}
        <button
          onClick={() => navigate("/mitra/onboarding/step3")}
          className="w-full bg-[#1B5E20] text-white py-3 rounded-lg font-medium hover:bg-[#2E7D32] transition-colors"
        >
          Lanjut →
        </button>
      </div>
    </div>
  );
}
