import { ArrowLeft, ChevronRight, LogOut } from "lucide-react";
import { useNavigate } from "react-router";
import { useState } from "react";

export default function PengaturanMitra() {
  const navigate = useNavigate();
  const [settings, setSettings] = useState({
    radius: "5 km",
    minimumOrder: 25000,
    minimumOrderEnabled: true,
    autoAccept: false,
    notifPesanan: true,
    notifPesan: true,
    notifUpdateStok: true,
    notifLaporanHarian: false
  });

  const [tarifsOngkir, setTarifsOngkir] = useState([
    { range: "Di bawah 1 km", price: 3000 },
    { range: "1 km – 2 km", price: 6000 },
    { range: "2 km – 3 km", price: 9000 },
    { range: "Di atas 3 km", price: 12000 }
  ]);

  const handleLogout = () => {
    if (confirm("Apakah Anda yakin ingin keluar dari akun mitra?")) {
      navigate("/login");
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Top App Bar */}
      <div className="bg-white border-b border-gray-200 px-4 py-3 flex items-center gap-3 sticky top-0 z-10">
        <button onClick={() => navigate(-1)} aria-label="Kembali" className="p-1">
          <ArrowLeft className="w-5 h-5 text-gray-700" />
        </button>
        <h1 className="font-medium text-gray-900">Pengaturan</h1>
      </div>

      <div className="p-4">
        {/* Pengaturan Warung */}
        <div className="mb-6">
          <h3 className="text-xs font-medium text-gray-500 mb-3 uppercase">
            Pengaturan Warung
          </h3>

          {/* Radius Pengiriman */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 mb-3">
            <button className="w-full px-4 py-4 flex items-center justify-between hover:bg-gray-50 transition-colors">
              <div>
                <p className="font-medium text-gray-900">Radius Pengiriman</p>
                <p className="text-sm text-gray-600">Maksimal {settings.radius} dari warung</p>
              </div>
              <ChevronRight className="w-5 h-5 text-gray-400" />
            </button>
          </div>

          {/* Tarif Ongkos Kirim */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 mb-3">
            <h4 className="font-medium text-gray-900 mb-3">
              Tarif Ongkos Kirim Default
            </h4>
            <div className="space-y-3 mb-4">
              {tarifsOngkir.map((tarif, index) => (
                <div key={index} className="flex items-center justify-between">
                  <span className="text-sm text-gray-700">{tarif.range}</span>
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-gray-600">Rp</span>
                    <input
                      type="number"
                      value={tarif.price}
                      onChange={(e) => {
                        const newTarifs = [...tarifsOngkir];
                        newTarifs[index].price = parseInt(e.target.value);
                        setTarifsOngkir(newTarifs);
                      }}
                      className="w-24 px-3 py-1.5 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-[#1B5E20] focus:border-transparent"
                    />
                  </div>
                </div>
              ))}
            </div>
            <button className="w-full bg-[#1B5E20] text-white py-2 rounded-lg text-sm font-medium hover:bg-[#2E7D32] transition-colors">
              Simpan Tarif
            </button>
          </div>

          {/* Minimum Order */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 mb-3">
            <div className="flex items-center justify-between mb-3">
              <div className="flex-1">
                <p className="font-medium text-gray-900">Minimum Order</p>
                <p className="text-sm text-gray-600">Tetapkan minimal belanja</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.minimumOrderEnabled}
                  onChange={(e) =>
                    setSettings({
                      ...settings,
                      minimumOrderEnabled: e.target.checked
                    })
                  }
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-[#1B5E20] rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#1B5E20]"></div>
              </label>
            </div>
            {settings.minimumOrderEnabled && (
              <div className="flex items-center gap-2">
                <span className="text-sm text-gray-600">Rp</span>
                <input
                  type="number"
                  value={settings.minimumOrder}
                  onChange={(e) =>
                    setSettings({
                      ...settings,
                      minimumOrder: parseInt(e.target.value)
                    })
                  }
                  className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1B5E20] focus:border-transparent"
                />
              </div>
            )}
          </div>

          {/* Auto-Terima Pesanan */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
            <div className="flex items-start justify-between">
              <div className="flex-1 pr-4">
                <p className="font-medium text-gray-900 mb-1">
                  Auto-Terima Pesanan
                </p>
                <p className="text-sm text-gray-600">
                  Pesanan otomatis terkonfirmasi tanpa perlu kamu konfirmasi manual
                </p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.autoAccept}
                  onChange={(e) =>
                    setSettings({ ...settings, autoAccept: e.target.checked })
                  }
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-[#1B5E20] rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#1B5E20]"></div>
              </label>
            </div>
          </div>
        </div>

        {/* Notifikasi */}
        <div className="mb-6">
          <h3 className="text-xs font-medium text-gray-500 mb-3 uppercase">
            Notifikasi
          </h3>
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 divide-y divide-gray-200">
            {[
              { key: "notifPesanan", label: "Pesanan Masuk" },
              { key: "notifPesan", label: "Pesan Baru dari Customer" },
              { key: "notifUpdateStok", label: "Pengingat Update Stok (07.00)" },
              { key: "notifLaporanHarian", label: "Laporan Harian" }
            ].map((item) => (
              <div key={item.key} className="px-4 py-3 flex items-center justify-between">
                <span className="text-gray-900">{item.label}</span>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={settings[item.key as keyof typeof settings] as boolean}
                    onChange={(e) =>
                      setSettings({ ...settings, [item.key]: e.target.checked })
                    }
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-[#1B5E20] rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#1B5E20]"></div>
                </label>
              </div>
            ))}
          </div>
        </div>

        {/* Akun */}
        <div className="mb-6">
          <h3 className="text-xs font-medium text-gray-500 mb-3 uppercase">Akun</h3>
          <div className="bg-white rounded-lg shadow-sm border border-gray-200">
            <button className="w-full px-4 py-4 flex items-center justify-between hover:bg-gray-50 transition-colors border-b border-gray-200">
              <span className="text-gray-900">Ubah Nomor HP</span>
              <ChevronRight className="w-5 h-5 text-gray-400" />
            </button>
            <button className="w-full px-4 py-4 flex items-center justify-between hover:bg-gray-50 transition-colors border-b border-gray-200">
              <span className="text-gray-900">Ubah PIN</span>
              <ChevronRight className="w-5 h-5 text-gray-400" />
            </button>
            <button className="w-full px-4 py-4 flex items-center justify-between hover:bg-gray-50 transition-colors">
              <span className="text-gray-900">Keamanan Akun</span>
              <ChevronRight className="w-5 h-5 text-gray-400" />
            </button>
          </div>
        </div>

        {/* Logout */}
        <button
          onClick={handleLogout}
          className="w-full bg-white border border-red-300 text-red-600 py-3 rounded-lg font-medium flex items-center justify-center gap-2 hover:bg-red-50 transition-colors"
        >
          <LogOut className="w-5 h-5" />
          Keluar dari Akun Mitra
        </button>
      </div>
    </div>
  );
}
