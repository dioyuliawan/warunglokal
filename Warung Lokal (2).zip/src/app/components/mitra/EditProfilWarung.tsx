import { ArrowLeft, Camera, MapPin } from "lucide-react";
import { useNavigate } from "react-router";
import { useState } from "react";

export default function EditProfilWarung() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: "Kios Ayam Potong Pak Hendra",
    ownerName: "Bapak Hendra Wijaya",
    phone: "0812-xxxx-xxxx",
    category: "Bahan Makanan Segar",
    story:
      "Kios ayam potong yang sudah berdiri sejak 2015. Menyediakan ayam segar berkualitas dengan harga terjangkau untuk warga sekitar.",
    address: "Jl. Tebet Barat Dalam No. 5, Kel. Tebet Barat, Jakarta Selatan"
  });

  const categories = [
    "Bahan Makanan Segar",
    "Warung Makan",
    "Toko Kelontong",
    "Laundry & Kebersihan",
    "Lainnya"
  ];

  const handleSave = () => {
    alert("Perubahan berhasil disimpan!");
    navigate(-1);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Top App Bar */}
      <div className="bg-white border-b border-gray-200 px-4 py-3 flex items-center justify-between sticky top-0 z-10">
        <div className="flex items-center gap-3">
          <button onClick={() => navigate(-1)} aria-label="Kembali" className="p-1">
            <ArrowLeft className="w-5 h-5 text-gray-700" />
          </button>
          <h1 className="font-medium text-gray-900">Edit Profil Warung</h1>
        </div>
        <button
          onClick={handleSave}
          className="text-sm font-medium text-[#1B5E20]"
        >
          Simpan
        </button>
      </div>

      <div className="p-4">
        {/* Photo Section */}
        <div className="mb-6">
          <h3 className="font-medium text-gray-900 mb-3">Foto Warung</h3>
          <div className="relative w-32 h-32 mx-auto">
            <img
              src="https://images.unsplash.com/photo-1604719312566-8912e9227c6a?w=400&h=400&fit=crop"
              alt="Warung"
              className="w-full h-full rounded-xl object-cover"
              loading="lazy"
            />
            <button aria-label="Ganti foto" className="absolute bottom-0 right-0 bg-[#1B5E20] p-2 rounded-full shadow-lg hover:bg-[#2E7D32] transition-colors">
              <Camera className="w-4 h-4 text-white" />
            </button>
          </div>
          <p className="text-center text-sm text-gray-600 mt-2">Ganti Foto</p>
        </div>

        {/* Informasi Dasar */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 mb-4">
          <h3 className="font-medium text-gray-900 mb-4">Informasi Dasar</h3>
          <div className="space-y-4">
            <div>
              <label className="text-sm text-gray-700 mb-1 block">Nama Warung</label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) =>
                  setFormData({ ...formData, name: e.target.value })
                }
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1B5E20] focus:border-transparent"
              />
            </div>
            <div>
              <label className="text-sm text-gray-700 mb-1 block">
                Nama Pemilik
              </label>
              <input
                type="text"
                value={formData.ownerName}
                onChange={(e) =>
                  setFormData({ ...formData, ownerName: e.target.value })
                }
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1B5E20] focus:border-transparent"
              />
            </div>
            <div>
              <label className="text-sm text-gray-700 mb-1 block">Nomor HP</label>
              <input
                type="tel"
                value={formData.phone}
                onChange={(e) =>
                  setFormData({ ...formData, phone: e.target.value })
                }
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1B5E20] focus:border-transparent"
              />
            </div>
            <div>
              <label className="text-sm text-gray-700 mb-1 block">Kategori</label>
              <select
                value={formData.category}
                onChange={(e) =>
                  setFormData({ ...formData, category: e.target.value })
                }
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1B5E20] focus:border-transparent"
              >
                {categories.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Cerita Warung */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 mb-4">
          <h3 className="font-medium text-gray-900 mb-3">Cerita Warung</h3>
          <textarea
            value={formData.story}
            onChange={(e) => setFormData({ ...formData, story: e.target.value })}
            rows={4}
            maxLength={200}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1B5E20] focus:border-transparent resize-none"
          />
          <div className="flex justify-end mt-1">
            <span className="text-xs text-gray-600">
              {formData.story.length}/200
            </span>
          </div>
        </div>

        {/* Alamat */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 mb-4">
          <h3 className="font-medium text-gray-900 mb-3">Alamat</h3>
          <textarea
            value={formData.address}
            onChange={(e) =>
              setFormData({ ...formData, address: e.target.value })
            }
            rows={3}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1B5E20] focus:border-transparent resize-none mb-2"
          />
          <button className="flex items-center gap-2 text-sm text-[#1B5E20] font-medium">
            <MapPin className="w-4 h-4" />
            Ubah di Peta
          </button>
        </div>

        {/* Jam Operasional */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 mb-6">
          <h3 className="font-medium text-gray-900 mb-3">Jam Operasional</h3>
          <div className="space-y-3">
            {["Senin-Jumat", "Sabtu", "Minggu"].map((day, index) => (
              <div key={index} className="flex items-center gap-3">
                <input
                  type="checkbox"
                  defaultChecked
                  className="w-4 h-4 text-[#1B5E20] focus:ring-[#1B5E20] rounded"
                />
                <span className="text-sm text-gray-700 w-24">{day}</span>
                <input
                  type="time"
                  defaultValue="07:00"
                  className="flex-1 px-3 py-1.5 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-[#1B5E20] focus:border-transparent"
                />
                <span className="text-gray-400">—</span>
                <input
                  type="time"
                  defaultValue="17:00"
                  className="flex-1 px-3 py-1.5 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-[#1B5E20] focus:border-transparent"
                />
              </div>
            ))}
          </div>
        </div>

        {/* Save Button */}
        <button
          onClick={handleSave}
          className="w-full bg-[#1B5E20] text-white py-3 rounded-lg font-medium hover:bg-[#2E7D32] transition-colors"
        >
          Simpan Perubahan
        </button>
      </div>
    </div>
  );
}
