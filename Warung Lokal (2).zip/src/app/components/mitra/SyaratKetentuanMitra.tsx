import { ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router";

export default function SyaratKetentuanMitra() {
  const navigate = useNavigate();

  const sections = [
    {
      title: "1. Ketentuan Menjadi Mitra Warlok",
      content:
        "Untuk menjadi Mitra Warlok, calon mitra harus memiliki usaha lokal yang sah dan beroperasi di wilayah yang dilayani oleh platform Warlok. Mitra wajib memberikan informasi yang akurat dan lengkap mengenai profil usaha, produk, dan layanan yang ditawarkan."
    },
    {
      title: "2. Kewajiban Mitra",
      content:
        "Mitra wajib menjaga kualitas produk dan layanan yang ditawarkan melalui platform. Mitra harus memperbarui informasi stok secara rutin dan akurat untuk menghindari kekecewaan customer. Mitra wajib merespons pesanan dalam waktu maksimal 15 menit sejak pesanan masuk. Penolakan pesanan yang terlalu sering dapat mempengaruhi rating dan status kemitraan."
    },
    {
      title: "3. Komisi dan Pembayaran",
      content:
        "Warlok mengambil komisi sebesar 8% dari setiap transaksi yang berhasil diselesaikan. Pembayaran kepada mitra akan dilakukan setiap minggu (setiap hari Senin) untuk transaksi minggu sebelumnya yang sudah dikonfirmasi selesai. Mitra wajib memastikan informasi rekening bank yang didaftarkan benar dan aktif."
    },
    {
      title: "4. Penonaktifan Akun Mitra",
      content:
        "Warlok berhak menonaktifkan akun mitra jika ditemukan pelanggaran terhadap syarat dan ketentuan, termasuk namun tidak terbatas pada: produk tidak sesuai deskripsi, penipuan, rating yang terus menurun, atau tidak merespons pesanan dalam waktu yang ditentukan. Mitra akan diberikan peringatan terlebih dahulu sebelum penonaktifan permanen."
    },
    {
      title: "5. Kebijakan Produk",
      content:
        "Semua produk yang dijual melalui platform harus memenuhi standar kualitas dan keamanan yang berlaku. Mitra dilarang menjual produk ilegal, berbahaya, atau yang melanggar hukum. Foto dan deskripsi produk harus akurat dan tidak menyesatkan customer. Warlok berhak menghapus produk yang dianggap tidak sesuai dengan kebijakan platform."
    },
    {
      title: "6. Dukungan dan Pelatihan",
      content:
        "Warlok menyediakan materi pelatihan dan dukungan teknis untuk membantu mitra memaksimalkan penggunaan platform. Mitra dapat menghubungi tim support Warlok melalui Live Chat atau WhatsApp untuk mendapatkan bantuan terkait operasional platform."
    },
    {
      title: "7. Perubahan Syarat dan Ketentuan",
      content:
        "Warlok berhak mengubah syarat dan ketentuan mitra sewaktu-waktu. Mitra akan diberitahu melalui notifikasi atau email jika terdapat perubahan signifikan. Dengan melanjutkan penggunaan platform setelah perubahan berlaku, mitra dianggap menyetujui perubahan tersebut."
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Top App Bar */}
      <div className="bg-white border-b border-gray-200 px-4 py-3 flex items-center gap-3 sticky top-0 z-10">
        <button onClick={() => navigate(-1)} aria-label="Kembali" className="p-1">
          <ArrowLeft className="w-5 h-5 text-gray-700" />
        </button>
        <h1 className="font-medium text-gray-900">Syarat & Ketentuan Mitra</h1>
      </div>

      <div className="p-4">
        {/* Last Updated */}
        <div className="mb-4">
          <p className="text-xs text-gray-600">
            Terakhir diperbarui: 1 Januari 2024
          </p>
        </div>

        {/* Sections */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
          <div className="space-y-6">
            {sections.map((section, index) => (
              <div key={index}>
                <h2 className="font-medium text-gray-900 mb-2">{section.title}</h2>
                <p className="text-sm text-gray-700 leading-relaxed">
                  {section.content}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Footer Note */}
        <div className="mt-6 bg-green-50 border border-green-200 rounded-lg p-4">
          <p className="text-xs text-gray-700 leading-relaxed">
            Dengan mendaftar sebagai Mitra Warlok, Anda menyatakan telah membaca, memahami,
            dan menyetujui seluruh syarat dan ketentuan yang berlaku. Terima kasih telah
            mempercayai Warlok sebagai mitra digitalisasi usaha Anda.
          </p>
        </div>
      </div>
    </div>
  );
}
