import { ArrowLeft, Camera } from "lucide-react";
import { useNavigate } from "react-router";
import { useState } from "react";

export default function OnboardingStep3() {
  const navigate = useNavigate();
  const [story, setStory] = useState("");

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Top App Bar */}
      <div className="bg-white border-b border-gray-200 px-4 py-3 flex items-center gap-3">
        <button onClick={() => navigate(-1)} className="p-1">
          <ArrowLeft className="w-5 h-5 text-gray-700" />
        </button>
        <h1 className="font-medium text-gray-900">Daftar Mitra</h1>
      </div>

      {/* Progress Bar */}
      <div className="bg-white px-4 py-4">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm text-gray-600">Langkah 3 dari 4</span>
          <span className="text-sm font-medium text-[#1B5E20]">75%</span>
        </div>
        <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
          <div className="h-full bg-[#1B5E20] w-3/4 transition-all duration-300"></div>
        </div>
      </div>

      <div className="p-4">
        <h2 className="text-xl font-medium text-gray-900 mb-6">
          Kenalkan Warungmu
        </h2>

        {/* Photo Upload */}
        <div className="mb-6">
          <h3 className="font-medium text-gray-900 mb-3">Foto Warung</h3>
          <div className="bg-white border-2 border-dashed border-gray-300 rounded-lg p-8 text-center cursor-pointer hover:border-[#1B5E20] transition-colors">
            <Camera className="w-12 h-12 text-gray-400 mx-auto mb-3" />
            <p className="font-medium text-gray-900 mb-1">Upload Foto Warung</p>
            <p className="text-sm text-gray-600">
              Foto warung yang bagus meningkatkan kepercayaan customer
            </p>
          </div>
        </div>

        {/* Warung Name */}
        <div className="mb-6">
          <label className="font-medium text-gray-900 mb-2 block">Nama Warung</label>
          <input
            type="text"
            value="Kios Ayam Potong Pak Hendra"
            readOnly
            className="w-full px-4 py-3 border border-gray-300 rounded-lg bg-gray-50 text-gray-700"
          />
        </div>

        {/* Warung Story */}
        <div className="mb-6">
          <label className="font-medium text-gray-900 mb-2 block">
            Cerita Warung
          </label>
          <textarea
            value={story}
            onChange={(e) => setStory(e.target.value)}
            placeholder="Ceritakan warungmu kepada customer — sudah berapa lama berdiri, produk unggulan, atau hal unik lainnya..."
            rows={5}
            maxLength={200}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1B5E20] focus:border-transparent resize-none"
          />
          <div className="flex justify-end mt-1">
            <span className="text-xs text-gray-600">{story.length}/200</span>
          </div>
        </div>

        {/* Category (Read-only) */}
        <div className="mb-6">
          <label className="font-medium text-gray-900 mb-2 block">
            Kategori Usaha
          </label>
          <div className="flex items-center justify-between bg-gray-50 border border-gray-300 rounded-lg px-4 py-3">
            <span className="text-gray-700">Bahan Makanan Segar</span>
            <button className="text-sm text-[#1B5E20] font-medium">Edit</button>
          </div>
        </div>

        {/* Next Button */}
        <button
          onClick={() => navigate("/mitra/onboarding/step4")}
          className="w-full bg-[#1B5E20] text-white py-3 rounded-lg font-medium hover:bg-[#2E7D32] transition-colors"
        >
          Lanjut →
        </button>
      </div>
    </div>
  );
}
