import { ArrowLeft, Search, ChevronDown, ChevronUp, MessageCircle, Play } from "lucide-react";
import { useNavigate } from "react-router";
import { useState } from "react";

export default function BantuanMitra() {
  const navigate = useNavigate();
  const [expandedFaq, setExpandedFaq] = useState<number | null>(null);

  const faqs = [
    {
      id: 1,
      question: "Bagaimana cara menambah produk baru?",
      answer:
        "Buka menu Dashboard Mitra → Produk → Tambah Produk Baru. Lengkapi informasi produk seperti nama, harga, stok, kategori, dan foto produk. Pastikan foto produk jelas dan menarik untuk meningkatkan penjualan."
    },
    {
      id: 2,
      question: "Bagaimana cara mengaktifkan Flash Sale?",
      answer:
        "Flash Sale dapat diaktifkan melalui menu Promo → Buat Flash Sale. Pilih produk yang ingin di-flash sale, tentukan harga diskon, dan atur waktu mulai serta berakhir promo. Flash Sale akan otomatis tayang di halaman home customer."
    },
    {
      id: 3,
      question: "Kapan pendapatan saya dicairkan?",
      answer:
        "Pendapatan dari pesanan yang sudah selesai akan dicairkan setiap hari Senin untuk transaksi minggu sebelumnya. Pencairan dilakukan ke rekening yang Anda daftarkan. Pastikan data rekening sudah benar dan terverifikasi."
    },
    {
      id: 4,
      question: "Bagaimana cara update stok harian?",
      answer:
        "Update stok dapat dilakukan melalui menu Produk → pilih produk yang ingin diupdate → Edit Stok. Anda juga akan mendapat notifikasi pengingat setiap pagi pukul 07.00 untuk update stok harian."
    },
    {
      id: 5,
      question: "Apa yang terjadi jika saya tolak pesanan?",
      answer:
        "Jika pesanan ditolak, customer akan menerima notifikasi dan dana akan dikembalikan. Namun, terlalu sering menolak pesanan dapat mempengaruhi rating warung Anda. Pastikan stok produk selalu terupdate untuk menghindari penolakan pesanan."
    }
  ];

  const videoTutorials = [
    {
      id: 1,
      title: "Cara upload produk pertama",
      duration: "3:45",
      thumbnail: "https://images.unsplash.com/photo-1557804506-669a67965ba0?w=400&h=225&fit=crop"
    },
    {
      id: 2,
      title: "Cara proses pesanan masuk",
      duration: "2:30",
      thumbnail: "https://images.unsplash.com/photo-1553877522-43269d4ea984?w=400&h=225&fit=crop"
    },
    {
      id: 3,
      title: "Cara aktivasi Flash Sale",
      duration: "4:10",
      thumbnail: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=400&h=225&fit=crop"
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Top App Bar */}
      <div className="bg-white border-b border-gray-200 px-4 py-3 flex items-center gap-3 sticky top-0 z-10">
        <button onClick={() => navigate(-1)} aria-label="Kembali" className="p-1">
          <ArrowLeft className="w-5 h-5 text-gray-700" />
        </button>
        <h1 className="font-medium text-gray-900">Bantuan & Dukungan</h1>
      </div>

      <div className="p-4">
        {/* Search Bar */}
        <div className="mb-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Cari pertanyaan..."
              className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1B5E20] focus:border-transparent"
            />
          </div>
        </div>

        {/* FAQ Section */}
        <div className="mb-6">
          <h3 className="text-sm font-medium text-gray-600 mb-3">
            Pertanyaan yang Sering Diajukan
          </h3>
          <div className="space-y-2">
            {faqs.map((faq) => (
              <div
                key={faq.id}
                className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden"
              >
                <button
                  onClick={() =>
                    setExpandedFaq(expandedFaq === faq.id ? null : faq.id)
                  }
                  className="w-full px-4 py-4 flex items-center justify-between text-left hover:bg-gray-50 transition-colors"
                >
                  <span className="font-medium text-gray-900 pr-4">
                    {faq.question}
                  </span>
                  {expandedFaq === faq.id ? (
                    <ChevronUp className="w-5 h-5 text-gray-400 flex-shrink-0" />
                  ) : (
                    <ChevronDown className="w-5 h-5 text-gray-400 flex-shrink-0" />
                  )}
                </button>
                {expandedFaq === faq.id && (
                  <div className="px-4 pb-4 text-sm text-gray-700 leading-relaxed">
                    {faq.answer}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Video Tutorials */}
        <div className="mb-6">
          <h3 className="text-sm font-medium text-gray-600 mb-3">
            Video Tutorial
          </h3>
          <div className="space-y-3">
            {videoTutorials.map((video) => (
              <div
                key={video.id}
                className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden cursor-pointer hover:shadow-md transition-shadow"
              >
                <div className="flex gap-3 p-3">
                  <div className="relative w-32 h-20 flex-shrink-0 bg-gray-200 rounded-lg overflow-hidden">
                    <img
                      src={video.thumbnail}
                      alt={video.title}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-40">
                      <Play className="w-8 h-8 text-white fill-white" />
                    </div>
                    <div className="absolute bottom-1 right-1 bg-black bg-opacity-75 px-1.5 py-0.5 rounded text-xs text-white">
                      {video.duration}
                    </div>
                  </div>
                  <div className="flex-1">
                    <h4 className="font-medium text-gray-900 mb-1">
                      {video.title}
                    </h4>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Contact Support */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
          <h3 className="font-medium text-gray-900 mb-3">Masih butuh bantuan?</h3>
          <div className="space-y-2 mb-3">
            <button className="w-full bg-[#1B5E20] text-white py-3 rounded-lg font-medium flex items-center justify-center gap-2 hover:bg-[#2E7D32] transition-colors">
              <MessageCircle className="w-5 h-5" />
              Live Chat dengan Tim Warlok
            </button>
            <button className="w-full border-2 border-[#1B5E20] text-[#1B5E20] py-3 rounded-lg font-medium hover:bg-gray-50 transition-colors">
              WhatsApp Mitra Support
            </button>
          </div>
          <p className="text-xs text-gray-600 text-center">
            Khusus Mitra: 08.00-22.00 setiap hari
          </p>
        </div>
      </div>
    </div>
  );
}
