import { Check, MessageCircle } from "lucide-react";
import { useNavigate } from "react-router";

export default function KonfirmasiSedangDikirim() {
  const navigate = useNavigate();

  const orderData = {
    orderNumber: "WLK-0042",
    customer: "Rina Kusuma",
    address: "Jl. Melati No. 12",
    estimatedTime: "± 30 menit"
  };

  const handleComplete = () => {
    // Show toast notification
    alert("Pesanan Berhasil Diselesaikan!");
    navigate("/mitra/pesanan");
  };

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <div className="w-full">
        {/* Success Icon */}
        <div className="text-center mb-6">
          <div className="w-16 h-16 bg-[#1B5E20] rounded-full mx-auto mb-4 flex items-center justify-center">
            <Check className="w-8 h-8 text-white" />
          </div>
          <h2 className="text-xl font-medium text-gray-900 mb-2">
            Pesanan Ditandai Sedang Dikirim
          </h2>
          <p className="text-sm text-gray-600">Order #{orderData.orderNumber}</p>
        </div>

        {/* Info Card */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 mb-6">
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-sm text-gray-600">Customer</span>
              <span className="text-sm font-medium text-gray-900">
                {orderData.customer}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-gray-600">Alamat</span>
              <span className="text-sm font-medium text-gray-900 text-right">
                {orderData.address}
              </span>
            </div>
            <div className="flex justify-between items-center bg-green-50 -mx-4 -mb-4 mt-4 p-4 rounded-b-lg">
              <span className="text-sm text-gray-600">Estimasi tiba</span>
              <span className="text-sm font-medium text-[#1B5E20]">
                {orderData.estimatedTime}
              </span>
            </div>
          </div>
        </div>

        {/* Status Timeline */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 mb-6">
          <h3 className="font-medium text-gray-900 mb-4">Status Pesanan</h3>
          <div className="space-y-3">
            <div className="flex items-center gap-3">
              <div className="w-6 h-6 bg-[#1B5E20] rounded-full flex items-center justify-center flex-shrink-0">
                <Check className="w-4 h-4 text-white" />
              </div>
              <span className="text-sm text-gray-700">Pesanan Diterima</span>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-6 h-6 bg-[#1B5E20] rounded-full flex items-center justify-center flex-shrink-0">
                <Check className="w-4 h-4 text-white" />
              </div>
              <span className="text-sm text-gray-700">Sedang Disiapkan</span>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-6 h-6 bg-[#1B5E20] rounded-full flex items-center justify-center flex-shrink-0 ring-4 ring-green-100">
                <Check className="w-4 h-4 text-white" />
              </div>
              <span className="text-sm font-medium text-[#1B5E20]">
                Sedang Dikirim
              </span>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-6 h-6 bg-gray-200 rounded-full flex items-center justify-center flex-shrink-0">
                <span className="text-xs text-gray-500">4</span>
              </div>
              <span className="text-sm text-gray-400">Selesai</span>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="space-y-2">
          <button
            onClick={handleComplete}
            className="w-full bg-[#1B5E20] text-white py-3 rounded-lg font-medium hover:bg-[#2E7D32] transition-colors"
          >
            Tandai Pesanan Selesai
          </button>
          <button
            onClick={() => navigate("/mitra/chat/customer-123")}
            className="w-full border-2 border-[#1B5E20] text-[#1B5E20] py-3 rounded-lg font-medium flex items-center justify-center gap-2 hover:bg-gray-50 transition-colors"
          >
            <MessageCircle className="w-5 h-5" />
            Chat ke Customer
          </button>
        </div>
      </div>
    </div>
  );
}
