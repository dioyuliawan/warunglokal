import { ArrowLeft, Check } from "lucide-react";
import { useNavigate } from "react-router";
import { useState } from "react";

export default function OnboardingStep4() {
  const navigate = useNavigate();
  const [agreed, setAgreed] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  const warungData = {
    photo: "https://images.unsplash.com/photo-1604719312566-8912e9227c6a?w=400&h=400&fit=crop",
    name: "Kios Ayam Potong Pak Hendra",
    owner: "Bapak Hendra Wijaya",
    category: "Bahan Makanan Segar",
    address: "Jl. Tebet Barat Dalam No. 5",
    hours: "Setiap hari 07.00-17.00"
  };

  const handleSubmit = () => {
    if (agreed) {
      setShowSuccess(true);
      setTimeout(() => {
        navigate("/mitra/dashboard");
      }, 2000);
    }
  };

  if (showSuccess) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <div className="text-center">
          <div className="w-20 h-20 bg-[#1B5E20] rounded-full mx-auto mb-6 flex items-center justify-center animate-bounce">
            <Check className="w-10 h-10 text-white" />
          </div>
          <h2 className="text-2xl font-medium text-gray-900 mb-2">
            Pendaftaran Berhasil!
          </h2>
          <p className="text-gray-600 mb-6">
            Warungmu sedang dalam proses verifikasi. Kami akan memberitahu kamu dalam 1x24 jam.
          </p>
          <button
            onClick={() => navigate("/mitra/dashboard")}
            className="bg-[#1B5E20] text-white px-6 py-3 rounded-lg font-medium hover:bg-[#2E7D32] transition-colors"
          >
            Mengerti
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Top App Bar */}
      <div className="bg-white border-b border-gray-200 px-4 py-3 flex items-center gap-3">
        <button onClick={() => navigate(-1)} className="p-1">
          <ArrowLeft className="w-5 h-5 text-gray-700" />
        </button>
        <h1 className="font-medium text-gray-900">Daftar Mitra</h1>
      </div>

      {/* Progress Bar */}
      <div className="bg-white px-4 py-4">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm text-gray-600">Langkah 4 dari 4</span>
          <span className="text-sm font-medium text-[#1B5E20]">100%</span>
        </div>
        <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
          <div className="h-full bg-[#1B5E20] w-full transition-all duration-300"></div>
        </div>
      </div>

      <div className="p-4">
        <h2 className="text-xl font-medium text-gray-900 mb-6">
          Periksa Data Warungmu
        </h2>

        {/* Summary Card */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 mb-6">
          {/* Photo and Name */}
          <div className="flex flex-col items-center mb-6">
            <img
              src={warungData.photo}
              alt={warungData.name}
              className="w-24 h-24 rounded-full object-cover mb-3"
            />
            <h3 className="font-medium text-gray-900 text-lg mb-1">
              {warungData.name}
            </h3>
          </div>

          {/* Details */}
          <div className="space-y-4">
            <div className="flex justify-between items-start">
              <div className="flex-1">
                <p className="text-xs text-gray-600 mb-1">Pemilik</p>
                <p className="text-sm text-gray-900">{warungData.owner}</p>
              </div>
              <button className="text-sm text-[#1B5E20] font-medium">Edit</button>
            </div>

            <div className="flex justify-between items-start border-t border-gray-100 pt-4">
              <div className="flex-1">
                <p className="text-xs text-gray-600 mb-1">Kategori</p>
                <p className="text-sm text-gray-900">{warungData.category}</p>
              </div>
              <button className="text-sm text-[#1B5E20] font-medium">Edit</button>
            </div>

            <div className="flex justify-between items-start border-t border-gray-100 pt-4">
              <div className="flex-1">
                <p className="text-xs text-gray-600 mb-1">Alamat</p>
                <p className="text-sm text-gray-900">{warungData.address}</p>
              </div>
              <button className="text-sm text-[#1B5E20] font-medium">Edit</button>
            </div>

            <div className="flex justify-between items-start border-t border-gray-100 pt-4">
              <div className="flex-1">
                <p className="text-xs text-gray-600 mb-1">Jam Buka</p>
                <p className="text-sm text-gray-900">{warungData.hours}</p>
              </div>
              <button className="text-sm text-[#1B5E20] font-medium">Edit</button>
            </div>
          </div>
        </div>

        {/* Agreement Checkbox */}
        <div className="mb-6">
          <label className="flex items-start gap-3 cursor-pointer">
            <input
              type="checkbox"
              checked={agreed}
              onChange={(e) => setAgreed(e.target.checked)}
              className="mt-1 w-5 h-5 text-[#1B5E20] focus:ring-[#1B5E20] rounded border-gray-300"
            />
            <span className="text-sm text-gray-700">
              Saya menyetujui{" "}
              <button
                onClick={() => navigate("/mitra/syarat-ketentuan")}
                className="text-[#1B5E20] font-medium underline"
              >
                Syarat & Ketentuan Mitra Warlok
              </button>
            </span>
          </label>
        </div>

        {/* Submit Button */}
        <button
          onClick={handleSubmit}
          disabled={!agreed}
          className={`w-full py-3 rounded-lg font-medium transition-colors ${
            agreed
              ? "bg-[#1B5E20] text-white hover:bg-[#2E7D32]"
              : "bg-gray-300 text-gray-500 cursor-not-allowed"
          }`}
        >
          Daftarkan Warungku
        </button>
      </div>
    </div>
  );
}
