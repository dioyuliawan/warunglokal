/**
 * PRODUCT CARD COMPONENT
 * Reusable card component for displaying product information
 *
 * Usage:
 * <ProductCard
 *   product={productData}
 *   onClick={() => navigate(`/product/${id}`)}
 *   onAddToCart={(product) => handleAddToCart(product)}
 * />
 */

import { memo } from "react";
import { Plus } from "lucide-react";
import { ImageWithFallback } from "../figma/ImageWithFallback";
import { Product } from "../../data/types";

interface ProductCardProps {
  product: Product;
  onClick: () => void;
  onAddToCart?: (product: Product) => void;
  showAddButton?: boolean;
  variant?: "grid" | "list";
  className?: string;
}

export const ProductCard = memo(function ProductCard({
  product,
  onClick,
  onAddToCart,
  showAddButton = false,
  variant = "grid",
  className = "",
}: ProductCardProps) {
  const isOutOfStock = !product.active || product.stock === 0;

  const handleAddClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!isOutOfStock && onAddToCart) {
      onAddToCart(product);
    }
  };

  // Grid variant (default)
  if (variant === "grid") {
    return (
      <button
        onClick={() => !isOutOfStock && onClick()}
        disabled={isOutOfStock}
        className={`bg-white border border-gray-200 rounded-xl p-3 text-left hover:border-[#1B5E20] transition-colors relative ${
          isOutOfStock ? "opacity-60 cursor-not-allowed" : "cursor-pointer"
        } ${className}`}
      >
        {/* Product Image */}
        <div className="w-full h-24 rounded-lg overflow-hidden mb-2 relative">
          <ImageWithFallback
            src={product.image}
            alt={product.name}
            className="w-full h-full object-cover"
          />
          {isOutOfStock && (
            <div className="absolute inset-0 bg-gray-900/40 flex items-center justify-center">
              <span className="bg-gray-700 text-white text-xs px-2 py-1 rounded">
                Stok Habis
              </span>
            </div>
          )}
        </div>

        {/* Product Info */}
        <h3 className="text-sm text-[#1B1B1B] mb-1 line-clamp-2">{product.name}</h3>
        <div className="flex items-center justify-between">
          <p className={isOutOfStock ? "text-gray-400 text-sm" : "text-[#1B5E20] text-sm font-semibold"}>
            Rp {product.price.toLocaleString()}
            {product.unit && `/${product.unit}`}
          </p>
          {showAddButton && (
            <button
              onClick={handleAddClick}
              disabled={isOutOfStock}
              className={`p-1.5 rounded-full transition-colors ${
                isOutOfStock
                  ? "bg-gray-400 cursor-not-allowed"
                  : "bg-[#1B5E20] hover:bg-[#2E7D32]"
              }`}
            >
              <Plus className="w-3.5 h-3.5 text-white" />
            </button>
          )}
        </div>
        {!showAddButton && (
          <p className="text-xs text-gray-600 mt-1">Stok: {product.stock}</p>
        )}
      </button>
    );
  }

  // List variant (horizontal layout)
  return (
    <button
      onClick={() => !isOutOfStock && onClick()}
      disabled={isOutOfStock}
      className={`w-full bg-white border border-gray-200 rounded-xl p-3 text-left hover:border-[#1B5E20] transition-colors flex gap-3 relative ${
        isOutOfStock ? "opacity-60 cursor-not-allowed" : "cursor-pointer"
      } ${className}`}
    >
      {/* Product Image */}
      <div className="w-20 h-20 rounded-lg overflow-hidden flex-shrink-0 relative">
        <ImageWithFallback
          src={product.image}
          alt={product.name}
          className="w-full h-full object-cover"
        />
        {isOutOfStock && (
          <div className="absolute inset-0 bg-gray-900/40 flex items-center justify-center">
            <span className="bg-gray-700 text-white text-[10px] px-1.5 py-0.5 rounded">
              Habis
            </span>
          </div>
        )}
      </div>

      {/* Product Info */}
      <div className="flex-1 flex flex-col justify-between">
        <div>
          <h3 className="text-sm text-[#1B1B1B] mb-1 line-clamp-2">{product.name}</h3>
          <p className={isOutOfStock ? "text-gray-400 text-sm" : "text-[#1B5E20] text-sm font-semibold"}>
            Rp {product.price.toLocaleString()}
            {product.unit && `/${product.unit}`}
          </p>
        </div>
        <div className="flex items-center justify-between">
          <span className="text-xs text-gray-600">Stok: {product.stock}</span>
          {showAddButton && (
            <button
              onClick={handleAddClick}
              disabled={isOutOfStock}
              className={`p-1.5 rounded-full transition-colors ${
                isOutOfStock
                  ? "bg-gray-400 cursor-not-allowed"
                  : "bg-[#1B5E20] hover:bg-[#2E7D32]"
              }`}
            >
              <Plus className="w-3.5 h-3.5 text-white" />
            </button>
          )}
        </div>
      </div>
    </button>
  );
});
