/**
 * WARUNG CARD COMPONENT
 * Reusable card component for displaying warung information
 *
 * Usage:
 * <WarungCard warung={warungData} onClick={() => navigate(`/warung/${id}`)} />
 */

import { memo } from "react";
import { Star, Heart } from "lucide-react";
import { ImageWithFallback } from "../figma/ImageWithFallback";
import { WarungData } from "../../data/types";
import { COLORS } from "../../constants/colors";
import { useFavorites } from "../../context/FavoritesContext";

interface WarungCardProps {
  warung: WarungData;
  onClick: () => void;
  variant?: "default" | "compact" | "list";
  showDistance?: boolean;
  showRating?: boolean;
  showStatus?: boolean;
  showFavoriteButton?: boolean;
  className?: string;
}

export const WarungCard = memo(function WarungCard({
  warung,
  onClick,
  variant = "default",
  showDistance = true,
  showRating = true,
  showStatus = true,
  showFavoriteButton = false,
  className = "",
}: WarungCardProps) {
  const { isWarungFavorite, toggleWarungFavorite } = useFavorites();
  const isFavorite = isWarungFavorite(warung.id);

  const handleFavoriteClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    toggleWarungFavorite(warung.id);
  };
  // Render compact variant (horizontal layout)
  if (variant === "compact") {
    return (
      <button
        onClick={onClick}
        className={`w-full bg-white rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-shadow text-left flex gap-3 p-3 ${className}`}
      >
        <div className="w-20 h-20 rounded-lg overflow-hidden flex-shrink-0">
          <ImageWithFallback
            src={warung.image}
            alt={warung.name}
            className="w-full h-full object-cover"
          />
        </div>
        <div className="flex-1 min-w-0">
          <h3 className="font-bold text-[#1B1B1B] mb-1 truncate">{warung.name}</h3>
          <div className="flex flex-wrap gap-2 mb-1">
            <span className="px-2 py-0.5 bg-[#F1F8E9] text-[#1B5E20] text-xs font-semibold rounded-full">
              {warung.category}
            </span>
            {showDistance && (
              <span className="px-2 py-0.5 bg-gray-100 text-gray-600 text-xs font-semibold rounded-full">
                {warung.distance}
              </span>
            )}
          </div>
          {showRating && (
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-1">
                <Star size={14} className="text-[#FF6F00] fill-[#FF6F00]" />
                <span className="text-sm font-semibold text-gray-700">{warung.rating}</span>
              </div>
              {showStatus && (
                <span
                  className={`px-2 py-0.5 text-xs font-semibold rounded-full ${
                    warung.isOpen ? "bg-[#1B5E20] text-white" : "bg-red-500 text-white"
                  }`}
                >
                  {warung.isOpen ? "Buka" : "Tutup"}
                </span>
              )}
            </div>
          )}
        </div>
      </button>
    );
  }

  // Render list variant (large card with image on top)
  if (variant === "list") {
    return (
      <button
        onClick={onClick}
        className={`w-full bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition-shadow text-left relative ${className}`}
        style={{ boxShadow: "0 2px 12px rgba(0,0,0,0.08)" }}
      >
        {/* Favorite Button */}
        {showFavoriteButton && (
          <button
            onClick={handleFavoriteClick}
            aria-label={isFavorite ? "Hapus dari favorit" : "Tambah ke favorit"}
            className="absolute top-3 right-3 z-10 w-10 h-10 bg-white rounded-full shadow-md flex items-center justify-center hover:scale-110 active:scale-95 transition-transform"
          >
            <Heart
              size={20}
              className={`transition-colors ${
                isFavorite ? "text-red-500 fill-red-500" : "text-gray-400"
              }`}
            />
          </button>
        )}

        {/* Warung Image - full width */}
        <div className="w-full h-40 overflow-hidden">
          <ImageWithFallback
            src={warung.image}
            alt={warung.name}
            className="w-full h-full object-cover"
          />
        </div>

        {/* Warung Info */}
        <div className="p-4">
          <h3 className="font-bold text-[#1B1B1B] mb-2">{warung.name}</h3>
          <div className="flex flex-wrap gap-2 mb-3">
            <span className="px-2 py-0.5 bg-[#F1F8E9] text-[#1B5E20] text-xs font-semibold rounded-full">
              {warung.category}
            </span>
            {showDistance && (
              <span className="px-2 py-0.5 bg-gray-100 text-gray-600 text-xs font-semibold rounded-full">
                {warung.distance}
              </span>
            )}
          </div>
          <div className="flex items-center gap-3">
            {showRating && (
              <div className="flex items-center gap-1">
                <Star size={14} className="text-[#FF6F00] fill-[#FF6F00]" />
                <span className="text-sm font-semibold text-gray-700">{warung.rating}</span>
              </div>
            )}
            {showStatus && (
              <span
                className={`px-2 py-0.5 text-xs font-semibold rounded-full ${
                  warung.isOpen ? "bg-[#1B5E20] text-white" : "bg-red-500 text-white"
                }`}
              >
                {warung.isOpen ? "Buka" : "Tutup"}
              </span>
            )}
            <span className="text-xs text-gray-500">Antar ~30 mnt</span>
          </div>
        </div>
      </button>
    );
  }

  // Default variant
  return (
    <button
      onClick={onClick}
      className={`w-full bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition-shadow text-left ${className}`}
    >
      <div className="w-full h-32 overflow-hidden">
        <ImageWithFallback
          src={warung.image}
          alt={warung.name}
          className="w-full h-full object-cover"
        />
      </div>
      <div className="p-3">
        <h3 className="font-bold text-[#1B1B1B] mb-2">{warung.name}</h3>
        <div className="flex items-center justify-between">
          {showRating && (
            <div className="flex items-center gap-1">
              <Star size={14} className="text-[#FF6F00] fill-[#FF6F00]" />
              <span className="text-sm font-semibold">{warung.rating}</span>
            </div>
          )}
          {showDistance && <span className="text-sm text-gray-600">{warung.distance}</span>}
        </div>
      </div>
    </button>
  );
});
