/**
 * EMPTY STATE COMPONENT
 * Reusable empty state component with icon, message, and action button
 *
 * Usage:
 * <EmptyState
 *   icon={<ShoppingBag size={64} />}
 *   title="Keranjang masih kosong"
 *   message="Yuk, mulai belanja dari warung terdekatmu"
 *   actionLabel="Mulai Belanja"
 *   onAction={() => navigate("/home")}
 * />
 */

import { ReactNode } from "react";

interface EmptyStateProps {
  icon: ReactNode;
  title: string;
  message?: string;
  actionLabel?: string;
  onAction?: () => void;
  className?: string;
}

export function EmptyState({
  icon,
  title,
  message,
  actionLabel,
  onAction,
  className = "",
}: EmptyStateProps) {
  return (
    <div className={`flex flex-col items-center justify-center p-12 ${className}`}>
      {/* Icon Container with Animation */}
      <div
        className="w-32 h-32 bg-gradient-to-br from-[#F1F8E9] to-[#C5E1A5] rounded-full flex items-center justify-center mb-6 text-[#558B2F] animate-in fade-in zoom-in duration-500"
        style={{ animationDelay: '0ms' }}
      >
        {icon}
      </div>

      {/* Title with Stagger Animation */}
      <h2
        className="text-xl text-[#1B1B1B] font-semibold mb-2 animate-in fade-in slide-in-from-bottom-2 duration-500"
        style={{ animationDelay: '100ms' }}
      >
        {title}
      </h2>

      {/* Message with Stagger Animation */}
      {message && (
        <p
          className="text-gray-600 text-center mb-6 max-w-sm animate-in fade-in slide-in-from-bottom-2 duration-500"
          style={{ animationDelay: '200ms' }}
        >
          {message}
        </p>
      )}

      {/* Action Button with Stagger Animation */}
      {actionLabel && onAction && (
        <button
          onClick={onAction}
          className="px-8 py-3 bg-[#1B5E20] text-white rounded-full font-semibold hover:bg-[#2E7D32] hover:shadow-lg active:scale-95 transition-all duration-200 animate-in fade-in slide-in-from-bottom-2"
          style={{ animationDelay: '300ms' }}
        >
          {actionLabel}
        </button>
      )}
    </div>
  );
}
