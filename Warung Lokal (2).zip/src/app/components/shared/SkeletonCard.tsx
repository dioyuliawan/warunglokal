/**
 * SKELETON CARD COMPONENTS
 * Loading placeholders for better perceived performance
 */

export function WarungCardSkeleton() {
  return (
    <div className="bg-white rounded-2xl p-4 shadow-sm">
      <div className="flex gap-3">
        <div className="w-20 h-20 animate-shimmer rounded-xl flex-shrink-0" />
        <div className="flex-1 space-y-2">
          <div className="h-4 animate-shimmer rounded w-3/4" />
          <div className="flex gap-2">
            <div className="h-5 animate-shimmer rounded-full w-20" />
            <div className="h-5 animate-shimmer rounded-full w-16" />
          </div>
          <div className="h-4 animate-shimmer rounded w-1/2" />
        </div>
      </div>
    </div>
  );
}

export function ProductCardSkeleton() {
  return (
    <div className="bg-white rounded-2xl overflow-hidden shadow-sm">
      <div className="aspect-square animate-shimmer" />
      <div className="p-3 space-y-2">
        <div className="h-4 animate-shimmer rounded w-3/4" />
        <div className="h-5 animate-shimmer rounded w-1/2" />
        <div className="h-4 animate-shimmer rounded w-full" />
      </div>
    </div>
  );
}

export function OrderCardSkeleton() {
  return (
    <div className="bg-white rounded-2xl p-4 shadow-sm">
      <div className="flex justify-between items-start mb-3">
        <div className="space-y-2 flex-1">
          <div className="h-4 animate-shimmer rounded w-32" />
          <div className="h-3 animate-shimmer rounded w-24" />
        </div>
        <div className="h-6 animate-shimmer rounded-full w-20" />
      </div>
      <div className="space-y-2">
        <div className="h-3 animate-shimmer rounded w-full" />
        <div className="h-3 animate-shimmer rounded w-2/3" />
      </div>
    </div>
  );
}

interface SkeletonListProps {
  count?: number;
  type: 'warung' | 'product' | 'order';
}

export function SkeletonList({ count = 3, type }: SkeletonListProps) {
  const SkeletonComponent = {
    warung: WarungCardSkeleton,
    product: ProductCardSkeleton,
    order: OrderCardSkeleton,
  }[type];

  return (
    <div className="space-y-3">
      {Array.from({ length: count }).map((_, index) => (
        <SkeletonComponent key={index} />
      ))}
    </div>
  );
}
