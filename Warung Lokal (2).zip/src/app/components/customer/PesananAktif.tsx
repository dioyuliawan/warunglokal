import { ArrowLeft, MapPin, MessageCircle } from "lucide-react";
import { useNavigate } from "react-router";

export default function PesananAktif() {
  const navigate = useNavigate();

  // Mock active order data
  const hasActiveOrder = true;
  const activeOrder = {
    orderNumber: "WLK-2024-0042",
    status: "Sedang Dikirim",
    warung: {
      id: "warung-bu-tini",
      name: "Kios Ayam Pak Hendra"
    },
    items: [
      { name: "Ayam Utuh Segar", quantity: 1 },
      { name: "Hati & Ampela", quantity: 2 }
    ],
    total: "Rp 63.000",
    estimatedArrival: "Tiba ~11:15",
    progress: 3,
    totalSteps: 4
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Top App Bar */}
      <div className="bg-white border-b border-gray-200 px-4 py-3 flex items-center gap-3 sticky top-0 z-10">
        <button onClick={() => navigate(-1)} aria-label="Kembali" className="p-1">
          <ArrowLeft className="w-5 h-5 text-gray-700" />
        </button>
        <h1 className="font-medium text-gray-900">Pesanan Aktif</h1>
      </div>

      <div className="p-4">
        {hasActiveOrder ? (
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
            {/* Order Header */}
            <div className="mb-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-gray-600">Order #{activeOrder.orderNumber}</span>
                <div className="flex items-center gap-1.5 bg-blue-50 px-3 py-1 rounded-full">
                  <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse"></div>
                  <span className="text-sm font-medium text-blue-700">
                    {activeOrder.status}
                  </span>
                </div>
              </div>
            </div>

            {/* Warung Info */}
            <div className="mb-4">
              <h3 className="font-medium text-gray-900 mb-1">{activeOrder.warung.name}</h3>
            </div>

            {/* Items */}
            <div className="mb-4 pb-4 border-b border-gray-200">
              {activeOrder.items.map((item, index) => (
                <div key={index} className="flex justify-between text-sm mb-1">
                  <span className="text-gray-700">
                    {item.name} x{item.quantity}
                  </span>
                </div>
              ))}
              <div className="flex justify-between font-medium mt-2">
                <span className="text-gray-900">Total</span>
                <span className="text-[#1B5E20]">{activeOrder.total}</span>
              </div>
            </div>

            {/* Estimated Arrival */}
            <div className="mb-4 bg-green-50 rounded-lg p-3 flex items-center gap-2">
              <MapPin className="w-5 h-5 text-[#1B5E20]" />
              <span className="text-sm font-medium text-[#1B5E20]">
                {activeOrder.estimatedArrival}
              </span>
            </div>

            {/* Progress Bar */}
            <div className="mb-6">
              <div className="flex items-center justify-between mb-2">
                {[1, 2, 3, 4].map((step) => (
                  <div key={step} className="flex items-center">
                    <div
                      className={`w-8 h-8 rounded-full flex items-center justify-center ${
                        step <= activeOrder.progress
                          ? "bg-[#1B5E20] text-white"
                          : "bg-gray-200 text-gray-400"
                      }`}
                    >
                      {step <= activeOrder.progress ? "✓" : step}
                    </div>
                    {step < 4 && (
                      <div
                        className={`h-1 w-16 ${
                          step < activeOrder.progress ? "bg-[#1B5E20]" : "bg-gray-200"
                        }`}
                      />
                    )}
                  </div>
                ))}
              </div>
              <div className="flex justify-between text-xs text-gray-600 mt-2">
                <span>Diterima</span>
                <span>Disiapkan</span>
                <span>Dikirim</span>
                <span>Selesai</span>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="space-y-2">
              <button
                onClick={() => navigate("/tracking")}
                className="w-full bg-[#1B5E20] text-white py-3 rounded-lg font-medium hover:bg-[#2E7D32] transition-colors"
              >
                Lacak Pesanan
              </button>
              <button
                onClick={() => navigate(`/warung/${activeOrder.warung.id}/chat`)}
                className="w-full border-2 border-[#1B5E20] text-[#1B5E20] py-3 rounded-lg font-medium flex items-center justify-center gap-2 hover:bg-gray-50 transition-colors"
              >
                <MessageCircle className="w-5 h-5" />
                Chat ke Mitra
              </button>
            </div>
          </div>
        ) : (
          // Empty State
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8 text-center">
            <div className="mb-4">
              <div className="w-24 h-24 bg-gray-100 rounded-full mx-auto flex items-center justify-center">
                <MapPin className="w-12 h-12 text-gray-400" />
              </div>
            </div>
            <h3 className="font-medium text-gray-900 mb-2">
              Belum ada pesanan aktif
            </h3>
            <p className="text-sm text-gray-600 mb-6">
              Pesanan yang sedang diproses akan muncul di sini
            </p>
            <button
              onClick={() => navigate("/")}
              className="bg-[#1B5E20] text-white px-6 py-3 rounded-lg font-medium hover:bg-[#2E7D32] transition-colors"
            >
              Mulai Belanja
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
