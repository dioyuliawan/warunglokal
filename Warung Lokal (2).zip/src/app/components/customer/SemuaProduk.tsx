import { ArrowLeft, Search, SlidersHorizontal, Plus, MessageCircle } from "lucide-react";
import { useNavigate, useParams } from "react-router";
import { ALL_WARUNGS, getProductsByWarungId, getWarungById } from "../../data/products";
import { useState } from "react";
import { useCart } from "../../context/CartContext";

export default function SemuaProduk() {
  const navigate = useNavigate();
  const { warungId } = useParams();
  const [activeCategory, setActiveCategory] = useState("Semua");
  const { addItem } = useCart();

  const warung = getWarungById(warungId || "");

  if (!warung) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <div className="text-center">
          <p className="text-gray-600">Warung tidak ditemukan</p>
        </div>
      </div>
    );
  }

  // Get products for this warung
  const products = getProductsByWarungId(warungId || "");

  // Get unique categories from products
  const categories = ["Semua", ...new Set(products.map(p => p.category))];

  // Filter products by category
  const filteredProducts = activeCategory === "Semua"
    ? products
    : products.filter(p => p.category === activeCategory);

  return (
    <div className="min-h-screen bg-gray-50 pb-24">
      {/* Top App Bar */}
      <div className="bg-white border-b border-gray-200 px-4 py-3 flex items-center justify-between sticky top-0 z-10">
        <div className="flex items-center gap-3 flex-1">
          <button onClick={() => navigate(-1)} aria-label="Kembali" className="p-1">
            <ArrowLeft className="w-5 h-5 text-gray-700" />
          </button>
          <h1 className="font-medium text-gray-900">{warung.name}</h1>
        </div>
        <div className="flex items-center gap-2">
          <button aria-label="Cari" className="p-2 hover:bg-gray-100 rounded-full">
            <Search className="w-5 h-5 text-gray-700" />
          </button>
          <button aria-label="Filter" className="p-2 hover:bg-gray-100 rounded-full">
            <SlidersHorizontal className="w-5 h-5 text-gray-700" />
          </button>
        </div>
      </div>

      {/* Category Tab Bar */}
      <div className="bg-white border-b border-gray-200 px-4 py-3 overflow-x-auto sticky top-[57px] z-10">
        <div className="flex gap-2">
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setActiveCategory(category)}
              className={`flex-shrink-0 px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                activeCategory === category
                  ? "bg-[#1B5E20] text-white"
                  : "bg-gray-100 text-gray-700 hover:bg-gray-200"
              }`}
            >
              {category}
            </button>
          ))}
        </div>
      </div>

      {/* Product Grid */}
      <div className="p-4">
        <div className="grid grid-cols-2 gap-3">
          {filteredProducts.map((product) => {
            const isOutOfStock = !product.active || product.stock === 0;
            return (
              <div
                key={product.id}
                onClick={() => !isOutOfStock && navigate(`/product/${product.id}`)}
                className={`bg-white rounded-lg overflow-hidden shadow-sm border border-gray-200 cursor-pointer hover:shadow-md transition-shadow ${
                  isOutOfStock ? "opacity-60" : ""
                }`}
              >
                <div className="aspect-square bg-gray-100 relative">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover"
                    loading="lazy"
                  />
                  {isOutOfStock && (
                    <div className="absolute inset-0 bg-gray-900/40 flex items-center justify-center">
                      <span className="bg-gray-700 text-white text-xs px-2 py-1 rounded">
                        Stok Habis
                      </span>
                    </div>
                  )}
                </div>
                <div className="p-3">
                  <h3 className="font-medium text-sm text-gray-900 line-clamp-2 mb-1">
                    {product.name}
                  </h3>
                  <p className={`font-medium mb-2 ${isOutOfStock ? "text-gray-400" : "text-[#1B5E20]"}`}>
                    Rp {product.price.toLocaleString()}
                    {product.unit && `/${product.unit}`}
                  </p>
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-gray-600">
                      Stok: {product.stock}
                    </span>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        if (!isOutOfStock && warung) {
                          addItem(product, 1, undefined, warung.id, warung.name);
                        }
                      }}
                      disabled={isOutOfStock}
                      aria-label="Tambah ke keranjang"
                      className={`p-1.5 rounded-full transition-colors ${
                        isOutOfStock
                          ? "bg-gray-400 cursor-not-allowed"
                          : "bg-[#1B5E20] hover:bg-[#2E7D32]"
                      }`}
                    >
                      <Plus className="w-3.5 h-3.5 text-white" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Floating Chat Button */}
      <div className="fixed bottom-20 left-0 right-0 px-4">
        <button
          onClick={() => navigate(`/warung/${warungId}/chat`)}
          className="w-full bg-white border-2 border-[#1B5E20] text-[#1B5E20] py-3 rounded-full font-medium flex items-center justify-center gap-2 shadow-lg hover:bg-gray-50 transition-colors"
        >
          <MessageCircle className="w-5 h-5" />
          Chat ke Pemilik
        </button>
      </div>
    </div>
  );
}
