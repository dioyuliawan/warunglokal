import { ArrowLeft, Search, ChevronDown, ChevronUp, MessageCircle } from "lucide-react";
import { useNavigate } from "react-router";
import { useState } from "react";

export default function Bantuan() {
  const navigate = useNavigate();
  const [expandedFaq, setExpandedFaq] = useState<number | null>(null);

  const topics = ["Pesanan", "Pembayaran", "Pengiriman", "Akun"];

  const faqs = [
    {
      id: 1,
      question: "Bagaimana cara melacak pesanan saya?",
      answer:
        "Anda dapat melacak pesanan melalui menu 'Pesanan Aktif' di halaman profil. Klik pada pesanan yang sedang berjalan untuk melihat status real-time dan estimasi waktu tiba."
    },
    {
      id: 2,
      question: "Apa yang harus dilakukan jika pesanan tidak datang?",
      answer:
        "Pertama, hubungi mitra warung melalui fitur chat untuk konfirmasi. Jika tidak ada respons atau masalah tidak terselesaikan, hubungi tim support Warlok melalui Live Chat atau WhatsApp Support."
    },
    {
      id: 3,
      question: "Bagaimana cara membatalkan pesanan?",
      answer:
        "Pesanan dapat dibatalkan dalam waktu 5 menit setelah pemesanan. Buka detail pesanan di 'Pesanan Aktif', lalu pilih 'Batalkan Pesanan'. Setelah 5 menit, Anda perlu menghubungi mitra untuk pembatalan."
    },
    {
      id: 4,
      question: "Bagaimana cara menghubungi warung?",
      answer:
        "Gunakan fitur 'Chat ke Pemilik' yang tersedia di halaman profil warung atau detail produk. Anda dapat mengirim pesan teks atau foto untuk berkomunikasi langsung dengan pemilik warung."
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Top App Bar */}
      <div className="bg-white border-b border-gray-200 px-4 py-3 flex items-center gap-3 sticky top-0 z-10">
        <button onClick={() => navigate(-1)} aria-label="Kembali" className="p-1">
          <ArrowLeft className="w-5 h-5 text-gray-700" />
        </button>
        <h1 className="font-medium text-gray-900">Bantuan</h1>
      </div>

      <div className="p-4">
        {/* Search Bar */}
        <div className="mb-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Cari pertanyaan atau topik..."
              className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1B5E20] focus:border-transparent"
            />
          </div>
        </div>

        {/* Popular Topics */}
        <div className="mb-6">
          <h3 className="text-sm font-medium text-gray-600 mb-3">Topik Populer</h3>
          <div className="flex gap-2 flex-wrap">
            {topics.map((topic) => (
              <button
                key={topic}
                className="px-4 py-2 bg-white border border-gray-300 rounded-full text-sm text-gray-700 hover:border-[#1B5E20] hover:text-[#1B5E20] transition-colors"
              >
                {topic}
              </button>
            ))}
          </div>
        </div>

        {/* FAQ List */}
        <div className="mb-6">
          <h3 className="text-sm font-medium text-gray-600 mb-3">
            Pertanyaan yang Sering Diajukan
          </h3>
          <div className="space-y-2">
            {faqs.map((faq) => (
              <div
                key={faq.id}
                className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden"
              >
                <button
                  onClick={() =>
                    setExpandedFaq(expandedFaq === faq.id ? null : faq.id)
                  }
                  className="w-full px-4 py-4 flex items-center justify-between text-left hover:bg-gray-50 transition-colors"
                >
                  <span className="font-medium text-gray-900 pr-4">
                    {faq.question}
                  </span>
                  {expandedFaq === faq.id ? (
                    <ChevronUp className="w-5 h-5 text-gray-400 flex-shrink-0" />
                  ) : (
                    <ChevronDown className="w-5 h-5 text-gray-400 flex-shrink-0" />
                  )}
                </button>
                {expandedFaq === faq.id && (
                  <div className="px-4 pb-4 text-sm text-gray-700 leading-relaxed">
                    {faq.answer}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Contact Support */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
          <h3 className="font-medium text-gray-900 mb-3">Masih butuh bantuan?</h3>
          <div className="space-y-2 mb-3">
            <button className="w-full bg-[#1B5E20] text-white py-3 rounded-lg font-medium flex items-center justify-center gap-2 hover:bg-[#2E7D32] transition-colors">
              <MessageCircle className="w-5 h-5" />
              Live Chat
            </button>
            <button className="w-full border-2 border-[#1B5E20] text-[#1B5E20] py-3 rounded-lg font-medium hover:bg-gray-50 transition-colors">
              WhatsApp Support
            </button>
          </div>
          <p className="text-xs text-gray-600 text-center">
            Jam Operasional: Senin-Sabtu, 08.00-20.00
          </p>
        </div>
      </div>
    </div>
  );
}
