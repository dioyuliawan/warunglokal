import { ArrowLeft, Phone, Camera, Send } from "lucide-react";
import { useNavigate, useParams } from "react-router";
import { ALL_WARUNGS } from "../../data/products";

export default function ChatKeWarung() {
  const navigate = useNavigate();
  const { warungId } = useParams();

  const warung = ALL_WARUNGS.find(w => w.id === warungId);

  if (!warung) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <div className="text-center">
          <p className="text-gray-600">Warung tidak ditemukan</p>
        </div>
      </div>
    );
  }

  const messages = [
    {
      id: 1,
      sender: "customer",
      text: "Pak, ayam utuh masih ada stok?",
      time: "10:32"
    },
    {
      id: 2,
      sender: "mitra",
      text: "Masih ada pak/bu, hari ini 15 ekor",
      time: "10:32"
    },
    {
      id: 3,
      sender: "customer",
      text: "Oke pak, saya pesan 2 ekor ya",
      time: "10:33"
    },
    {
      id: 4,
      sender: "mitra",
      text: "Siap, langsung saya proses pesanannya",
      time: "10:33"
    }
  ];

  const quickReplies = [
    "Stok masih ada?",
    "Bisa request potongan?",
    "Berapa ongkirnya?",
    "Kapan buka?"
  ];

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Top App Bar */}
      <div className="bg-white border-b border-gray-200 px-4 py-3 flex items-center justify-between sticky top-0 z-10">
        <div className="flex items-center gap-3 flex-1">
          <button onClick={() => navigate(-1)} aria-label="Kembali" className="p-1">
            <ArrowLeft className="w-5 h-5 text-gray-700" />
          </button>
          <img
            src={warung.image}
            alt={warung.name}
            className="w-10 h-10 rounded-full object-cover"
          />
          <div className="flex-1">
            <h3 className="font-medium text-gray-900">{warung.name}</h3>
            <div className="flex items-center gap-1">
              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
              <span className="text-xs text-green-600">Buka Sekarang</span>
            </div>
          </div>
        </div>
        <button aria-label="Telepon" className="p-2 hover:bg-gray-100 rounded-full">
          <Phone className="w-5 h-5 text-[#1B5E20]" />
        </button>
      </div>

      {/* Chat Messages */}
      <div className="flex-1 overflow-y-auto px-4 py-6 space-y-4">
        {messages.map((message, index) => (
          <div key={message.id}>
            {index === 0 && (
              <div className="text-center mb-4">
                <span className="text-xs text-gray-500 bg-gray-200 px-3 py-1 rounded-full">
                  {message.time}
                </span>
              </div>
            )}
            <div
              className={`flex ${
                message.sender === "customer" ? "justify-end" : "justify-start"
              }`}
            >
              <div
                className={`max-w-[75%] rounded-lg px-4 py-2 ${
                  message.sender === "customer"
                    ? "bg-[#43A047] text-white"
                    : "bg-white border border-gray-200 text-gray-900"
                }`}
              >
                <p className="text-sm">{message.text}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Quick Reply Chips */}
      <div className="px-4 pb-2">
        <div className="flex gap-2 overflow-x-auto pb-2">
          {quickReplies.map((reply, index) => (
            <button
              key={index}
              className="flex-shrink-0 px-4 py-2 bg-white border border-gray-300 rounded-full text-sm text-gray-700 hover:border-[#1B5E20] hover:text-[#1B5E20] transition-colors"
            >
              {reply}
            </button>
          ))}
        </div>
      </div>

      {/* Message Input Bar */}
      <div className="bg-white border-t border-gray-200 px-4 py-3">
        <div className="flex items-center gap-2">
          <input
            type="text"
            placeholder="Tulis pesan..."
            className="flex-1 px-4 py-2 border border-gray-300 rounded-full focus:outline-none focus:ring-2 focus:ring-[#1B5E20] focus:border-transparent"
          />
          <button aria-label="Kirim foto" className="p-2 hover:bg-gray-100 rounded-full">
            <Camera className="w-5 h-5 text-gray-600" />
          </button>
          <button aria-label="Kirim pesan" className="p-3 bg-[#1B5E20] rounded-full hover:bg-[#2E7D32] transition-colors">
            <Send className="w-5 h-5 text-white" />
          </button>
        </div>
      </div>
    </div>
  );
}
