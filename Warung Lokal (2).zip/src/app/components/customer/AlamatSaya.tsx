import { ArrowLeft, Plus, MapPin } from "lucide-react";
import { useNavigate } from "react-router";

export default function AlamatSaya() {
  const navigate = useNavigate();

  const addresses = [
    {
      id: 1,
      label: "Rumah",
      isDefault: true,
      name: "Rina Kusuma",
      phone: "0812-3456-7890",
      fullAddress:
        "Jl. Melati No. 12, RT 03/RW 05, Kel. Tebet Barat, Kec. Tebet, Jakarta Selatan 12810"
    },
    {
      id: 2,
      label: "Kantor",
      isDefault: false,
      name: "Rina Kusuma",
      phone: "0812-3456-7890",
      fullAddress: "Jl. Sudirman No. 45, Lt. 8, Jakarta Pusat 10220"
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Top App Bar */}
      <div className="bg-white border-b border-gray-200 px-4 py-3 flex items-center gap-3 sticky top-0 z-10">
        <button onClick={() => navigate(-1)} aria-label="Kembali" className="p-1">
          <ArrowLeft className="w-5 h-5 text-gray-700" />
        </button>
        <h1 className="font-medium text-gray-900">Alamat Saya</h1>
      </div>

      <div className="p-4">
        {/* Saved Addresses */}
        <div className="space-y-3 mb-6">
          {addresses.map((address) => (
            <div
              key={address.id}
              className="bg-white rounded-lg shadow-sm border border-gray-200 p-4"
            >
              {/* Label and Badge */}
              <div className="flex items-center gap-2 mb-3">
                <MapPin className="w-4 h-4 text-gray-600" />
                <span className="font-medium text-gray-900">{address.label}</span>
                {address.isDefault && (
                  <span className="px-2 py-0.5 bg-green-50 text-green-700 text-xs rounded-full font-medium">
                    Utama
                  </span>
                )}
              </div>

              {/* Contact Info */}
              <div className="mb-2">
                <p className="font-medium text-gray-900">{address.name}</p>
                <p className="text-sm text-gray-600">{address.phone}</p>
              </div>

              {/* Full Address */}
              <p className="text-sm text-gray-700 mb-4">{address.fullAddress}</p>

              {/* Action Buttons */}
              <div className="flex gap-2">
                {!address.isDefault && (
                  <button className="flex-1 border border-gray-300 text-gray-700 py-2 rounded-lg text-sm font-medium hover:bg-gray-50 transition-colors">
                    Jadikan Utama
                  </button>
                )}
                <button className="flex-1 border border-gray-300 text-gray-700 py-2 rounded-lg text-sm font-medium hover:bg-gray-50 transition-colors">
                  Edit
                </button>
                <button className="flex-1 border border-red-300 text-red-600 py-2 rounded-lg text-sm font-medium hover:bg-red-50 transition-colors">
                  Hapus
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Add New Address Button */}
        <button className="w-full border-2 border-[#1B5E20] text-[#1B5E20] py-3 rounded-lg font-medium flex items-center justify-center gap-2 hover:bg-gray-50 transition-colors">
          <Plus className="w-5 h-5" />
          Tambah Alamat Baru
        </button>
      </div>
    </div>
  );
}
