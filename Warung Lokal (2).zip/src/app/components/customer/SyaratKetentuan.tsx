import { ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router";

export default function SyaratKetentuan() {
  const navigate = useNavigate();

  const sections = [
    {
      title: "1. Ketentuan Umum",
      content:
        "Dengan menggunakan aplikasi Warlok, pengguna menyetujui seluruh syarat dan ketentuan yang berlaku. Aplikasi ini menyediakan platform untuk menghubungkan customer dengan mitra warung lokal di sekitar mereka. Pengguna bertanggung jawab penuh atas aktivitas yang dilakukan menggunakan akun mereka."
    },
    {
      title: "2. Hak dan Kewajiban Pengguna",
      content:
        "Pengguna wajib memberikan informasi yang akurat dan bertanggung jawab atas aktivitas akun. Setiap pengguna dilarang melakukan tindakan yang merugikan pihak lain, termasuk namun tidak terbatas pada penipuan, penyalahgunaan platform, dan pelanggaran hukum yang berlaku."
    },
    {
      title: "3. Transaksi dan Pembayaran",
      content:
        "Warlok berfungsi sebagai fasilitator transaksi antara customer dan mitra warung. Semua transaksi yang dilakukan melalui platform ini bersifat final dan mengikat. Pengguna bertanggung jawab untuk memastikan kebenaran informasi pembayaran yang diberikan."
    },
    {
      title: "4. Kebijakan Pengiriman",
      content:
        "Metode dan biaya pengiriman ditentukan berdasarkan kesepakatan antara customer dan mitra warung. Warlok tidak bertanggung jawab atas keterlambatan pengiriman yang disebabkan oleh faktor di luar kendali platform, termasuk kondisi cuaca, lalu lintas, atau force majeure."
    },
    {
      title: "5. Penyelesaian Sengketa",
      content:
        "Apabila terjadi perselisihan antara customer dan mitra warung, para pihak diharapkan menyelesaikannya secara musyawarah. Warlok dapat memfasilitasi mediasi jika diperlukan. Untuk sengketa yang tidak dapat diselesaikan, akan ditangani sesuai dengan hukum yang berlaku di wilayah Republik Indonesia."
    },
    {
      title: "6. Perubahan Syarat dan Ketentuan",
      content:
        "Warlok berhak untuk mengubah syarat dan ketentuan ini sewaktu-waktu tanpa pemberitahuan terlebih dahulu. Pengguna disarankan untuk memeriksa halaman ini secara berkala untuk mengetahui perubahan yang terjadi."
    },
    {
      title: "7. Privasi dan Keamanan Data",
      content:
        "Warlok berkomitmen untuk melindungi privasi dan keamanan data pengguna sesuai dengan kebijakan privasi yang berlaku. Data pengguna tidak akan dibagikan kepada pihak ketiga tanpa persetujuan, kecuali diwajibkan oleh hukum."
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Top App Bar */}
      <div className="bg-white border-b border-gray-200 px-4 py-3 flex items-center gap-3 sticky top-0 z-10">
        <button onClick={() => navigate(-1)} aria-label="Kembali" className="p-1">
          <ArrowLeft className="w-5 h-5 text-gray-700" />
        </button>
        <h1 className="font-medium text-gray-900">Syarat & Ketentuan</h1>
      </div>

      <div className="p-4">
        {/* Last Updated */}
        <div className="mb-4">
          <p className="text-xs text-gray-600">
            Terakhir diperbarui: 1 Januari 2024
          </p>
        </div>

        {/* Sections */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
          <div className="space-y-6">
            {sections.map((section, index) => (
              <div key={index}>
                <h2 className="font-medium text-gray-900 mb-2">{section.title}</h2>
                <p className="text-sm text-gray-700 leading-relaxed">
                  {section.content}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Footer Note */}
        <div className="mt-6 bg-green-50 border border-green-200 rounded-lg p-4">
          <p className="text-xs text-gray-700 leading-relaxed">
            Dengan melanjutkan penggunaan aplikasi Warlok, Anda menyatakan telah membaca,
            memahami, dan menyetujui seluruh syarat dan ketentuan yang berlaku.
          </p>
        </div>
      </div>
    </div>
  );
}
