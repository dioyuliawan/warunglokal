import { ArrowLeft, Trash2, Plus } from "lucide-react";
import { useNavigate } from "react-router";
import { useState } from "react";

export default function MetodePembayaran() {
  const navigate = useNavigate();
  const [selectedPayment, setSelectedPayment] = useState("bca");
  const [showAddSheet, setShowAddSheet] = useState(false);

  const paymentMethods = [
    {
      id: "bca",
      type: "bank",
      name: "BCA Virtual Account",
      detail: "****1234",
      isDefault: true,
      icon: ""
    },
    {
      id: "gopay",
      type: "ewallet",
      name: "GoPay",
      detail: "Rina Kusuma",
      isLinked: true,
      icon: ""
    },
    {
      id: "ovo",
      type: "ewallet",
      name: "OVO",
      detail: "081234****",
      icon: ""
    }
  ];

  const addPaymentOptions = [
    {
      category: "Transfer Bank",
      options: ["BCA", "BNI", "BRI", "Mandiri"]
    },
    {
      category: "Dompet Digital",
      options: ["GoPay", "OVO", "Dana", "ShopeePay"]
    },
    {
      category: "Lainnya",
      options: ["COD (Bayar di Tempat)"]
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Top App Bar */}
      <div className="bg-white border-b border-gray-200 px-4 py-3 flex items-center gap-3 sticky top-0 z-10">
        <button onClick={() => navigate(-1)} aria-label="Kembali" className="p-1">
          <ArrowLeft className="w-5 h-5 text-gray-700" />
        </button>
        <h1 className="font-medium text-gray-900">Metode Pembayaran</h1>
      </div>

      <div className="p-4">
        {/* Saved Payment Methods */}
        <div className="space-y-3 mb-6">
          {paymentMethods.map((method) => (
            <div
              key={method.id}
              className="bg-white rounded-lg shadow-sm border border-gray-200 p-4"
            >
              <div className="flex items-start gap-3">
                <input
                  type="radio"
                  name="payment"
                  checked={selectedPayment === method.id}
                  onChange={() => setSelectedPayment(method.id)}
                  className="mt-1 w-4 h-4 text-[#1B5E20] focus:ring-[#1B5E20]"
                />
                <div className="flex-1">
                  <div className="flex items-start justify-between mb-1">
                    <div>
                      <h3 className="font-medium text-gray-900">{method.name}</h3>
                      <p className="text-sm text-gray-600">{method.detail}</p>
                    </div>
                    <button aria-label="Hapus" className="p-2 hover:bg-gray-100 rounded-full">
                      <Trash2 className="w-4 h-4 text-red-500" />
                    </button>
                  </div>
                  <div className="flex gap-2 mt-2">
                    {method.isDefault && (
                      <span className="px-2 py-0.5 bg-green-50 text-green-700 text-xs rounded-full font-medium">
                        Default
                      </span>
                    )}
                    {method.isLinked && (
                      <span className="px-2 py-0.5 bg-blue-50 text-blue-700 text-xs rounded-full font-medium">
                        Terhubung
                      </span>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Divider */}
        <div className="border-t border-gray-200 my-6"></div>

        {/* Add Payment Method Button */}
        <button
          onClick={() => setShowAddSheet(true)}
          className="w-full border-2 border-[#1B5E20] text-[#1B5E20] py-3 rounded-lg font-medium flex items-center justify-center gap-2 hover:bg-gray-50 transition-colors"
        >
          <Plus className="w-5 h-5" />
          Tambah Metode Pembayaran
        </button>

        {/* Save Button */}
        <button className="w-full bg-[#1B5E20] text-white py-3 rounded-lg font-medium hover:bg-[#2E7D32] transition-colors mt-4">
          Simpan
        </button>
      </div>

      {/* Add Payment Bottom Sheet */}
      {showAddSheet && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-end">
          <div className="bg-white rounded-t-3xl w-full max-h-[80vh] overflow-y-auto">
            <div className="p-4 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <h2 className="font-medium text-gray-900">Tambah Metode Pembayaran</h2>
                <button
                  onClick={() => setShowAddSheet(false)}
                  className="p-2 hover:bg-gray-100 rounded-full"
                >
                  ✕
                </button>
              </div>
            </div>
            <div className="p-4">
              {addPaymentOptions.map((section, index) => (
                <div key={index} className="mb-6">
                  <h3 className="text-sm font-medium text-gray-600 mb-3">
                    {section.category}
                  </h3>
                  <div className="space-y-2">
                    {section.options.map((option, optIndex) => (
                      <button
                        key={optIndex}
                        onClick={() => {
                          setShowAddSheet(false);
                        }}
                        className="w-full bg-white border border-gray-200 rounded-lg p-4 text-left hover:border-[#1B5E20] hover:bg-gray-50 transition-colors"
                      >
                        {option}
                      </button>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
