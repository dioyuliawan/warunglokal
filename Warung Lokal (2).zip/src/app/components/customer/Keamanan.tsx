import { ArrowLeft, ChevronRight } from "lucide-react";
import { useNavigate } from "react-router";
import { useState } from "react";

export default function Keamanan() {
  const navigate = useNavigate();
  const [twoFactorEnabled, setTwoFactorEnabled] = useState(false);

  const securityOptions = [
    {
      id: "phone",
      title: "Nomor HP Terdaftar",
      subtitle: "0812-3456-7890",
      hasChevron: true
    },
    {
      id: "pin",
      title: "Ubah PIN Aplikasi",
      subtitle: null,
      hasChevron: true
    },
    {
      id: "login-history",
      title: "Riwayat Login",
      subtitle: null,
      hasChevron: true
    }
  ];

  const loginHistory = [
    {
      date: "Hari ini, 08:30",
      location: "Jakarta",
      isCurrent: true
    },
    {
      date: "Kemarin, 19:22",
      location: "Jakarta",
      isCurrent: false
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Top App Bar */}
      <div className="bg-white border-b border-gray-200 px-4 py-3 flex items-center gap-3 sticky top-0 z-10">
        <button onClick={() => navigate(-1)} aria-label="Kembali" className="p-1">
          <ArrowLeft className="w-5 h-5 text-gray-700" />
        </button>
        <h1 className="font-medium text-gray-900">Keamanan</h1>
      </div>

      <div className="p-4">
        {/* Security Options */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden mb-4">
          {securityOptions.map((option, index) => (
            <button
              key={option.id}
              className={`w-full px-4 py-4 flex items-center justify-between hover:bg-gray-50 transition-colors ${
                index !== securityOptions.length - 1 ? "border-b border-gray-200" : ""
              }`}
            >
              <div className="flex-1 text-left">
                <p className="font-medium text-gray-900">{option.title}</p>
                {option.subtitle && (
                  <p className="text-sm text-gray-600 mt-0.5">{option.subtitle}</p>
                )}
              </div>
              {option.hasChevron && (
                <ChevronRight className="w-5 h-5 text-gray-400" />
              )}
            </button>
          ))}
        </div>

        {/* Two-Factor Authentication */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 mb-4">
          <div className="flex items-start justify-between mb-2">
            <div className="flex-1">
              <h3 className="font-medium text-gray-900 mb-1">
                Verifikasi Dua Langkah
              </h3>
              <p className="text-sm text-gray-600">
                Tambahan keamanan saat login dari perangkat baru
              </p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer ml-4">
              <input
                type="checkbox"
                checked={twoFactorEnabled}
                onChange={(e) => setTwoFactorEnabled(e.target.checked)}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-[#1B5E20] rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#1B5E20]"></div>
            </label>
          </div>
        </div>

        {/* Login History Section */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 mb-4">
          <h3 className="font-medium text-gray-900 mb-3">Riwayat Login Terakhir</h3>
          <div className="space-y-3">
            {loginHistory.map((login, index) => (
              <div
                key={index}
                className="flex items-start justify-between pb-3 border-b border-gray-100 last:border-0 last:pb-0"
              >
                <div>
                  <p className="text-sm text-gray-900">{login.date}</p>
                  <p className="text-xs text-gray-600">{login.location}</p>
                </div>
                {login.isCurrent && (
                  <span className="text-xs bg-green-50 text-green-700 px-2 py-1 rounded-full">
                    Perangkat ini
                  </span>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Logout from All Devices */}
        <button className="w-full bg-white border border-red-300 text-red-600 py-3 rounded-lg font-medium hover:bg-red-50 transition-colors">
          Keluar dari Semua Perangkat
        </button>
      </div>
    </div>
  );
}
