import { ArrowLeft, Package, Zap, Store, Gift } from "lucide-react";
import { useNavigate } from "react-router";
import { useState } from "react";

export default function NotifikasiCustomer() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("Semua");

  const tabs = ["Semua", "Pesanan", "Promo", "Warung Favorit"];

  const notifications = {
    today: [
      {
        id: 1,
        type: "Pesanan",
        icon: <Package className="w-5 h-5 text-blue-600" />,
        bgColor: "bg-blue-50",
        title: "Pesanan #WLK-0042 sedang dalam perjalanan",
        time: "10 menit lalu",
        isRead: false
      },
      {
        id: 2,
        type: "Promo",
        icon: <Zap className="w-5 h-5 text-amber-600" />,
        bgColor: "bg-amber-50",
        title: "Warung Bu Tini: Nasi Bungkus -20% Habis jam 14.00!",
        time: "32 menit lalu",
        isRead: false
      },
      {
        id: 3,
        type: "Warung Favorit",
        icon: <Store className="w-5 h-5 text-green-600" />,
        bgColor: "bg-green-50",
        title: "Kios Sayur Bu Sari baru restok: Mangga Harum Manis tersedia",
        time: "1 jam lalu",
        isRead: true
      }
    ],
    yesterday: [
      {
        id: 4,
        type: "Pesanan",
        icon: <Package className="w-5 h-5 text-blue-600" />,
        bgColor: "bg-blue-50",
        title: "Pesanan #WLK-0039 telah selesai. Beri ulasan untuk Warung Bu Tini",
        time: "Kemarin",
        isRead: true
      },
      {
        id: 5,
        type: "Promo",
        icon: <Gift className="w-5 h-5 text-purple-600" />,
        bgColor: "bg-purple-50",
        title: "Kode voucher WARLOK10 berlaku hari ini!",
        time: "Kemarin",
        isRead: true
      }
    ]
  };

  const filterNotifications = (notifs: any[]) => {
    if (activeTab === "Semua") return notifs;
    return notifs.filter((n) => n.type === activeTab);
  };

  const todayFiltered = filterNotifications(notifications.today);
  const yesterdayFiltered = filterNotifications(notifications.yesterday);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Top App Bar */}
      <div className="bg-white border-b border-gray-200 px-4 py-3 flex items-center gap-3 sticky top-0 z-10">
        <button onClick={() => navigate(-1)} aria-label="Kembali" className="p-1">
          <ArrowLeft className="w-5 h-5 text-gray-700" />
        </button>
        <h1 className="font-medium text-gray-900">Notifikasi</h1>
      </div>

      {/* Tab Bar */}
      <div className="bg-white border-b border-gray-200 px-4 py-3 overflow-x-auto sticky top-[57px] z-10">
        <div className="flex gap-2">
          {tabs.map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`flex-shrink-0 px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                activeTab === tab
                  ? "bg-[#1B5E20] text-white"
                  : "bg-gray-100 text-gray-700 hover:bg-gray-200"
              }`}
            >
              {tab}
            </button>
          ))}
        </div>
      </div>

      {/* Notifications List */}
      <div className="p-4">
        {todayFiltered.length > 0 && (
          <div className="mb-6">
            <h2 className="text-xs font-medium text-gray-500 mb-3 uppercase">
              Hari Ini
            </h2>
            <div className="space-y-2">
              {todayFiltered.map((notif) => (
                <div
                  key={notif.id}
                  className={`bg-white rounded-lg shadow-sm border border-gray-200 p-4 cursor-pointer hover:shadow-md transition-shadow ${
                    !notif.isRead ? "border-l-4 border-l-[#1B5E20]" : ""
                  }`}
                >
                  <div className="flex gap-3">
                    <div className={`${notif.bgColor} p-2 rounded-full h-fit`}>
                      {notif.icon}
                    </div>
                    <div className="flex-1">
                      <p className="text-sm text-gray-900 mb-1">{notif.title}</p>
                      <p className="text-xs text-gray-500">{notif.time}</p>
                    </div>
                    {!notif.isRead && (
                      <div className="w-2 h-2 bg-[#1B5E20] rounded-full mt-1"></div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {yesterdayFiltered.length > 0 && (
          <div>
            <h2 className="text-xs font-medium text-gray-500 mb-3 uppercase">
              Kemarin
            </h2>
            <div className="space-y-2">
              {yesterdayFiltered.map((notif) => (
                <div
                  key={notif.id}
                  className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 cursor-pointer hover:shadow-md transition-shadow"
                >
                  <div className="flex gap-3">
                    <div className={`${notif.bgColor} p-2 rounded-full h-fit`}>
                      {notif.icon}
                    </div>
                    <div className="flex-1">
                      <p className="text-sm text-gray-900 mb-1">{notif.title}</p>
                      <p className="text-xs text-gray-500">{notif.time}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {todayFiltered.length === 0 && yesterdayFiltered.length === 0 && (
          <div className="text-center py-12">
            <div className="w-16 h-16 bg-gray-100 rounded-full mx-auto flex items-center justify-center mb-4">
              <Package className="w-8 h-8 text-gray-400" />
            </div>
            <p className="text-gray-600">Belum ada notifikasi</p>
          </div>
        )}
      </div>
    </div>
  );
}
