/**
 * SKIP TO CONTENT COMPONENT
 * Provides an accessible skip link for keyboard navigation
 * Hidden by default, visible when focused via keyboard (Tab key)
 */

export function SkipToContent() {
  return (
    <a
      href="#main-content"
      className="sr-only focus:not-sr-only focus:absolute focus:top-4 focus:left-4 focus:z-50 focus:px-4 focus:py-2 focus:bg-[#1B5E20] focus:text-white focus:rounded-lg focus:shadow-lg"
    >
      Langsung ke konten utama
    </a>
  );
}
