import { useState, useEffect } from "react";
import { Download, X } from "lucide-react";
import { useInstallPrompt } from "../hooks/useInstallPrompt";

const DISMISSED_KEY = "warlok_install_prompt_dismissed";
const DISMISSED_COUNT_KEY = "warlok_install_prompt_count";
const MAX_DISMISSALS = 3;

/**
 * Install Prompt Component
 * Shows a prompt to install the PWA
 * Only shows if not dismissed more than 3 times
 */
export function InstallPrompt() {
  const { canInstall, promptInstall } = useInstallPrompt();
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    // Check if user has dismissed too many times
    const dismissCount = parseInt(
      localStorage.getItem(DISMISSED_COUNT_KEY) || "0"
    );
    const isDismissed = localStorage.getItem(DISMISSED_KEY) === "true";

    // Show if can install and not permanently dismissed
    if (canInstall && !isDismissed && dismissCount < MAX_DISMISSALS) {
      // Delay showing by 5 seconds to not overwhelm user
      const timer = setTimeout(() => {
        setIsVisible(true);
      }, 5000);

      return () => clearTimeout(timer);
    }
  }, [canInstall]);

  const handleInstall = async () => {
    const accepted = await promptInstall();
    if (accepted) {
      setIsVisible(false);
      // Clear dismissal count on successful install
      localStorage.removeItem(DISMISSED_COUNT_KEY);
      localStorage.removeItem(DISMISSED_KEY);
    }
  };

  const handleDismiss = () => {
    setIsVisible(false);
    const currentCount = parseInt(
      localStorage.getItem(DISMISSED_COUNT_KEY) || "0"
    );
    const newCount = currentCount + 1;

    localStorage.setItem(DISMISSED_COUNT_KEY, newCount.toString());

    if (newCount >= MAX_DISMISSALS) {
      // Permanently dismiss after 3 times
      localStorage.setItem(DISMISSED_KEY, "true");
    }
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className="fixed bottom-20 left-4 right-4 z-40 animate-in slide-in-from-bottom-8 duration-500">
      <div className="bg-white rounded-2xl shadow-2xl p-4 border-2 border-[#1B5E20]">
        <div className="flex items-start gap-3">
          {/* Icon */}
          <div className="w-12 h-12 bg-[#F1F8E9] rounded-full flex items-center justify-center flex-shrink-0">
            <Download size={24} className="text-[#1B5E20]" />
          </div>

          {/* Content */}
          <div className="flex-1">
            <h3 className="text-[#1B1B1B] font-bold mb-1">
              Install Warung Lokal
            </h3>
            <p className="text-sm text-gray-600 mb-3">
              Akses lebih cepat dan belanja offline dengan install aplikasi
            </p>

            {/* Actions */}
            <div className="flex gap-2">
              <button
                onClick={handleInstall}
                className="flex-1 py-2 px-4 bg-[#1B5E20] text-white rounded-full text-sm font-semibold hover:bg-[#2E7D32] active:scale-95 transition-all"
              >
                Install Sekarang
              </button>
              <button
                onClick={handleDismiss}
                className="flex-1 py-2 px-4 border-2 border-gray-300 text-gray-700 rounded-full text-sm font-semibold hover:bg-gray-50 active:scale-95 transition-all"
              >
                Nanti Saja
              </button>
            </div>
          </div>

          {/* Close Button */}
          <button
            onClick={handleDismiss}
            aria-label="Tutup"
            className="text-gray-400 hover:text-gray-600 transition-colors"
          >
            <X size={20} />
          </button>
        </div>
      </div>
    </div>
  );
}
