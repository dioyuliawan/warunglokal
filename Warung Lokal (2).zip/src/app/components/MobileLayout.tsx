import { ReactNode } from "react";
import { SkipToContent } from "./SkipToContent";

interface MobileLayoutProps {
  children: ReactNode;
  showBottomNav?: boolean;
  bottomNav?: ReactNode;
}

export function MobileLayout({ children, showBottomNav = false, bottomNav }: MobileLayoutProps) {
  return (
    <div className="min-h-screen bg-white relative">
      {/* Skip to Content Link for Keyboard Navigation */}
      <SkipToContent />

      <main id="main-content" className={showBottomNav ? "pb-16" : ""}>
        {children}
      </main>

      {showBottomNav && (
        <nav aria-label="Navigasi utama">
          {bottomNav}
        </nav>
      )}
    </div>
  );
}