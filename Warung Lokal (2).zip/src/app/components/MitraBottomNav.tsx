import { useNavigate, useLocation } from "react-router";
import { Home, Package, FileText, BarChart3, User } from "lucide-react";

export function MitraBottomNav() {
  const navigate = useNavigate();
  const location = useLocation();
  
  const navItems = [
    { icon: Home, label: "Dashboard", path: "/mitra/dashboard" },
    { icon: Package, label: "Produk", path: "/mitra/products" },
    { icon: FileText, label: "Pesanan", path: "/mitra/orders" },
    { icon: BarChart3, label: "Laporan", path: "/mitra/reports" },
    { icon: User, label: "Profil", path: "/mitra/profile" },
  ];
  
  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 safe-bottom">
      <div className="flex justify-around items-center h-16">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = location.pathname === item.path;
          
          return (
            <button
              key={item.path}
              onClick={() => navigate(item.path)}
              className="flex flex-col items-center justify-center flex-1 h-full"
            >
              <Icon 
                size={24} 
                className={isActive ? "text-[#1B5E20]" : "text-gray-500"} 
              />
              <span className={`text-xs mt-1 ${isActive ? "text-[#1B5E20]" : "text-gray-500"}`}>
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}