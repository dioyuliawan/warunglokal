import { useNavigate, useLocation } from "react-router";
import { Home, Search, Package, Heart, User, ShoppingCart } from "lucide-react";
import { useCart } from "../context/CartContext";

export function CustomerBottomNav() {
  const navigate = useNavigate();
  const location = useLocation();
  const { getItemCount } = useCart();
  const cartItemCount = getItemCount();

  const navItems = [
    { icon: Home, label: "Beranda", path: "/home" },
    { icon: Search, label: "Cari", path: "/search" },
    { icon: ShoppingCart, label: "Keranjang", path: "/cart", badge: cartItemCount },
    { icon: Package, label: "Pesanan", path: "/orders" },
    { icon: User, label: "Profil", path: "/profile" },
  ];
  
  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 safe-bottom">
      <div className="flex justify-around items-center h-16">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = location.pathname === item.path;
          
          return (
            <button
              key={item.path}
              onClick={() => navigate(item.path)}
              className="flex flex-col items-center justify-center flex-1 h-full relative"
            >
              <div className="relative">
                <Icon
                  size={24}
                  className={isActive ? "text-[#1B5E20]" : "text-gray-500"}
                />
                {item.badge && item.badge > 0 && (
                  <span className="absolute -top-2 -right-2 w-5 h-5 bg-red-500 text-white text-[10px] rounded-full flex items-center justify-center font-bold">
                    {item.badge > 9 ? "9+" : item.badge}
                  </span>
                )}
              </div>
              <span className={`text-xs mt-1 ${isActive ? "text-[#1B5E20]" : "text-gray-500"}`}>
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}