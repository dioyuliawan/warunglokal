import { createContext, useContext, useState, ReactNode, useEffect } from "react";
import { Product } from "../data/products";

export interface CartItem extends Product {
  quantity: number;
  note?: string;
}

interface CartContextType {
  items: CartItem[];
  warungId: string | null;
  warungName: string | null;
  addItem: (product: Product, quantity: number, note?: string, warungId?: string, warungName?: string) => void;
  removeItem: (productId: string) => void;
  updateQuantity: (productId: string, delta: number) => void;
  clearCart: () => void;
  getTotalPrice: () => number;
  getItemCount: () => number;
}

interface CartStorage {
  items: CartItem[];
  warungId: string | null;
  warungName: string | null;
  timestamp: number;
}

const CartContext = createContext<CartContextType | undefined>(undefined);
const CART_STORAGE_KEY = 'warlok_cart';
const CART_EXPIRY_HOURS = 24;

export function CartProvider({ children }: { children: ReactNode }) {
  // Load cart from localStorage on mount
  const [items, setItems] = useState<CartItem[]>(() => {
    try {
      const stored = localStorage.getItem(CART_STORAGE_KEY);
      if (stored) {
        const cartData: CartStorage = JSON.parse(stored);
        const now = Date.now();
        const expiryTime = CART_EXPIRY_HOURS * 60 * 60 * 1000;

        // Check if cart is expired
        if (now - cartData.timestamp < expiryTime) {
          return cartData.items;
        } else {
          // Clear expired cart
          localStorage.removeItem(CART_STORAGE_KEY);
        }
      }
    } catch (error) {
      console.error('Error loading cart from localStorage:', error);
    }
    return [];
  });

  const [warungId, setWarungId] = useState<string | null>(() => {
    try {
      const stored = localStorage.getItem(CART_STORAGE_KEY);
      if (stored) {
        const cartData: CartStorage = JSON.parse(stored);
        const now = Date.now();
        const expiryTime = CART_EXPIRY_HOURS * 60 * 60 * 1000;

        if (now - cartData.timestamp < expiryTime) {
          return cartData.warungId;
        }
      }
    } catch (error) {
      console.error('Error loading warungId from localStorage:', error);
    }
    return null;
  });

  const [warungName, setWarungName] = useState<string | null>(() => {
    try {
      const stored = localStorage.getItem(CART_STORAGE_KEY);
      if (stored) {
        const cartData: CartStorage = JSON.parse(stored);
        const now = Date.now();
        const expiryTime = CART_EXPIRY_HOURS * 60 * 60 * 1000;

        if (now - cartData.timestamp < expiryTime) {
          return cartData.warungName;
        }
      }
    } catch (error) {
      console.error('Error loading warungName from localStorage:', error);
    }
    return null;
  });

  // Save cart to localStorage whenever it changes
  useEffect(() => {
    try {
      const cartData: CartStorage = {
        items,
        warungId,
        warungName,
        timestamp: Date.now(),
      };
      localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(cartData));
    } catch (error) {
      console.error('Error saving cart to localStorage:', error);
    }
  }, [items, warungId, warungName]);

  const addItem = (product: Product, quantity: number, note?: string, newWarungId?: string, newWarungName?: string) => {
    // If adding from a different warung, clear cart first
    if (warungId && newWarungId && warungId !== newWarungId) {
      if (window.confirm(`Keranjang saat ini berisi produk dari ${warungName}. Ganti ke ${newWarungName}?`)) {
        setItems([]);
        setWarungId(newWarungId);
        setWarungName(newWarungName);
      } else {
        return;
      }
    }

    // Set warung context if first item
    if (!warungId && newWarungId) {
      setWarungId(newWarungId);
      setWarungName(newWarungName || null);
    }

    // Check if item already exists
    const existingItemIndex = items.findIndex(item => item.id === product.id);

    if (existingItemIndex >= 0) {
      // Update existing item
      const newItems = [...items];
      newItems[existingItemIndex].quantity += quantity;
      if (note) {
        newItems[existingItemIndex].note = note;
      }
      setItems(newItems);
    } else {
      // Add new item
      setItems([...items, { ...product, quantity, note }]);
    }
  };

  const removeItem = (productId: string) => {
    const newItems = items.filter(item => item.id !== productId);
    setItems(newItems);

    // Clear warung context if cart is empty
    if (newItems.length === 0) {
      setWarungId(null);
      setWarungName(null);
    }
  };

  const updateQuantity = (productId: string, delta: number) => {
    setItems(items.map(item => {
      if (item.id === productId) {
        const newQuantity = Math.max(1, item.quantity + delta);
        return { ...item, quantity: newQuantity };
      }
      return item;
    }));
  };

  const clearCart = () => {
    setItems([]);
    setWarungId(null);
    setWarungName(null);
  };

  const getTotalPrice = () => {
    return items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  };

  const getItemCount = () => {
    return items.reduce((sum, item) => sum + item.quantity, 0);
  };

  return (
    <CartContext.Provider
      value={{
        items,
        warungId,
        warungName,
        addItem,
        removeItem,
        updateQuantity,
        clearCart,
        getTotalPrice,
        getItemCount,
      }}
    >
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const context = useContext(CartContext);
  if (context === undefined) {
    throw new Error("useCart must be used within a CartProvider");
  }
  return context;
}
