import { createContext, useContext, useState, useEffect, ReactNode } from "react";

interface FavoritesContextType {
  favoriteWarungs: string[];
  favoriteProducts: string[];
  toggleWarungFavorite: (warungId: string) => void;
  toggleProductFavorite: (productId: string) => void;
  isWarungFavorite: (warungId: string) => boolean;
  isProductFavorite: (productId: string) => boolean;
}

const FavoritesContext = createContext<FavoritesContextType | undefined>(undefined);

const STORAGE_KEY_WARUNGS = "warlok_favorite_warungs";
const STORAGE_KEY_PRODUCTS = "warlok_favorite_products";

export function FavoritesProvider({ children }: { children: ReactNode }) {
  const [favoriteWarungs, setFavoriteWarungs] = useState<string[]>([]);
  const [favoriteProducts, setFavoriteProducts] = useState<string[]>([]);

  // Load favorites from localStorage on mount
  useEffect(() => {
    try {
      const savedWarungs = localStorage.getItem(STORAGE_KEY_WARUNGS);
      const savedProducts = localStorage.getItem(STORAGE_KEY_PRODUCTS);

      if (savedWarungs) {
        setFavoriteWarungs(JSON.parse(savedWarungs));
      }
      if (savedProducts) {
        setFavoriteProducts(JSON.parse(savedProducts));
      }
    } catch (error) {
      console.error("Error loading favorites:", error);
    }
  }, []);

  // Save warungs to localStorage whenever it changes
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_WARUNGS, JSON.stringify(favoriteWarungs));
    } catch (error) {
      console.error("Error saving favorite warungs:", error);
    }
  }, [favoriteWarungs]);

  // Save products to localStorage whenever it changes
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_PRODUCTS, JSON.stringify(favoriteProducts));
    } catch (error) {
      console.error("Error saving favorite products:", error);
    }
  }, [favoriteProducts]);

  const toggleWarungFavorite = (warungId: string) => {
    setFavoriteWarungs((prev) =>
      prev.includes(warungId)
        ? prev.filter((id) => id !== warungId)
        : [...prev, warungId]
    );
  };

  const toggleProductFavorite = (productId: string) => {
    setFavoriteProducts((prev) =>
      prev.includes(productId)
        ? prev.filter((id) => id !== productId)
        : [...prev, productId]
    );
  };

  const isWarungFavorite = (warungId: string) => {
    return favoriteWarungs.includes(warungId);
  };

  const isProductFavorite = (productId: string) => {
    return favoriteProducts.includes(productId);
  };

  return (
    <FavoritesContext.Provider
      value={{
        favoriteWarungs,
        favoriteProducts,
        toggleWarungFavorite,
        toggleProductFavorite,
        isWarungFavorite,
        isProductFavorite,
      }}
    >
      {children}
    </FavoritesContext.Provider>
  );
}

export function useFavorites() {
  const context = useContext(FavoritesContext);
  if (context === undefined) {
    throw new Error("useFavorites must be used within a FavoritesProvider");
  }
  return context;
}
