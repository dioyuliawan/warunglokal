import { RouterProvider } from "react-router";
import { router } from "./routes";
import { CartProvider } from "./context/CartContext";
import { ToastProvider } from "./context/ToastContext";
import { FavoritesProvider } from "./context/FavoritesContext";
import { ErrorBoundary } from "./components/ErrorBoundary";
import { OfflineIndicator } from "./components/OfflineIndicator";
import { InstallPrompt } from "./components/InstallPrompt";

export default function App() {
  return (
    <ErrorBoundary>
      <ToastProvider>
        <FavoritesProvider>
          <CartProvider>
            <OfflineIndicator />
            <InstallPrompt />
            <RouterProvider router={router} />
          </CartProvider>
        </FavoritesProvider>
      </ToastProvider>
    </ErrorBoundary>
  );
}
