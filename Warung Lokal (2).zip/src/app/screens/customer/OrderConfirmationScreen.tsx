import { useNavigate } from "react-router";
import { MobileLayout } from "../../components/MobileLayout";
import { CheckCircle } from "lucide-react";
import { useCart } from "../../context/CartContext";
import { useEffect } from "react";

export function OrderConfirmationScreen() {
  const navigate = useNavigate();
  const { items, warungName, getTotalPrice, clearCart } = useCart();
  const orderId = "WLK-" + new Date().getFullYear() + "-" + String(Math.floor(Math.random() * 10000)).padStart(4, "0");

  // Clear cart after order is confirmed
  useEffect(() => {
    const timer = setTimeout(() => {
      clearCart();
    }, 1000);
    return () => clearTimeout(timer);
  }, [clearCart]);

  return (
    <MobileLayout>
      <div className="min-h-screen bg-[#F1F8E9] flex flex-col items-center justify-center p-6">
        <div className="w-full">
          {/* Success Icon */}
          <div className="flex justify-center mb-6">
            <div className="w-24 h-24 bg-[#1B5E20] rounded-full flex items-center justify-center">
              <CheckCircle size={56} className="text-white" />
            </div>
          </div>

          {/* Success Message */}
          <h1 className="text-2xl text-center text-[#1B1B1B] mb-2">
            Pesanan Berhasil!
          </h1>
          <p className="text-center text-gray-600 mb-6">
            Pesanan kamu sudah diterima oleh warung
          </p>

          {/* Order Details */}
          <div className="bg-white rounded-2xl p-5 shadow-sm mb-6">
            <div className="text-center mb-4 pb-4 border-b border-gray-200">
              <p className="text-sm text-gray-600 mb-1">Nomor Pesanan</p>
              <p className="text-xl text-[#1B5E20]">#{orderId}</p>
            </div>

            <div className="space-y-3">
              <div>
                <p className="text-sm text-gray-600 mb-1">Warung</p>
                <p className="text-[#1B1B1B]">{warungName || "Warung"}</p>
              </div>

              <div>
                <p className="text-sm text-gray-600 mb-1">Item</p>
                <p className="text-[#1B1B1B]">
                  {items.map((item, index) => (
                    <span key={item.id}>
                      {item.name} x{item.quantity}
                      {index < items.length - 1 ? ", " : ""}
                    </span>
                  ))}
                </p>
              </div>

              <div>
                <p className="text-sm text-gray-600 mb-1">Total Pembayaran</p>
                <p className="text-xl text-[#1B5E20]">Rp {(getTotalPrice() + 5000).toLocaleString()}</p>
              </div>

              <div>
                <p className="text-sm text-gray-600 mb-1">Estimasi Tiba</p>
                <p className="text-[#1B1B1B]">± 45 menit</p>
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="space-y-3">
            <button
              onClick={() => navigate(`/tracking/${orderId}`)}
              className="w-full py-4 px-6 rounded-full bg-[#1B5E20] text-white"
            >
              Lacak Pesanan
            </button>
            <button
              onClick={() => navigate("/home")}
              className="w-full py-3 text-[#1B5E20]"
            >
              Kembali ke Beranda
            </button>
          </div>
        </div>
      </div>
    </MobileLayout>
  );
}
