import { useNavigate } from "react-router";
import { MobileLayout } from "../../components/MobileLayout";
import { CustomerBottomNav } from "../../components/CustomerBottomNav";
import { ArrowLeft, Heart } from "lucide-react";
import { useFavorites } from "../../context/FavoritesContext";
import { ALL_WARUNGS } from "../../data/products";
import { WarungCard } from "../../components/shared/WarungCard";
import { EmptyState } from "../../components/shared/EmptyState";

export function FavoritesScreen() {
  const navigate = useNavigate();
  const { favoriteWarungs: favoriteIds } = useFavorites();

  // Get actual warung data for favorite IDs
  const favoriteWarungs = ALL_WARUNGS.filter((warung) =>
    favoriteIds.includes(warung.id)
  );

  return (
    <MobileLayout showBottomNav bottomNav={<CustomerBottomNav />}>
      <div className="min-h-screen bg-[#F1F8E9]">
        {/* Header */}
        <div className="bg-white shadow-sm">
          <div className="p-4 flex items-center gap-3">
            <button onClick={() => navigate("/home")} aria-label="Kembali ke beranda">
              <ArrowLeft size={24} className="text-gray-700" />
            </button>
            <h1 className="text-lg font-bold text-[#1B1B1B]">Favorit Saya</h1>
          </div>
        </div>

        <div className="p-4">
          {favoriteWarungs.length > 0 ? (
            <div className="space-y-3">
              {favoriteWarungs.map((warung, index) => (
                <div
                  key={warung.id}
                  className="animate-in fade-in slide-in-from-bottom-4 duration-300"
                  style={{ animationDelay: `${index * 50}ms` }}
                >
                  <WarungCard
                    warung={warung}
                    onClick={() => navigate(`/warung/${warung.id}`)}
                    variant="list"
                    showFavoriteButton={true}
                  />
                </div>
              ))}
            </div>
          ) : (
            <EmptyState
              icon={<Heart size={64} />}
              title="Belum ada warung favorit"
              message="Tap ikon hati di warung untuk menambahkan ke favorit"
              actionLabel="Jelajahi Warung"
              onAction={() => navigate("/home")}
            />
          )}
        </div>
      </div>
    </MobileLayout>
  );
}
