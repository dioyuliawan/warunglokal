import { useEffect } from "react";
import { useNavigate } from "react-router";
import { MobileLayout } from "../../components/MobileLayout";
import logoImage from "../../../imports/image-0.png";

export function OnboardingScreen() {
  const navigate = useNavigate();

  useEffect(() => {
    // Auto redirect to Home after 2 seconds
    const timer = setTimeout(() => {
      navigate("/home");
    }, 2000);

    return () => clearTimeout(timer);
  }, [navigate]);

  return (
    <MobileLayout>
      <div className="flex flex-col items-center justify-center min-h-screen bg-[#1B5E20]">
        {/* Logo with circular background */}
        <div className="text-center">
          <div className="mb-8 flex justify-center">
            <div className="bg-white rounded-full p-8 shadow-2xl">
              <img
                src={logoImage}
                alt="Logo Warung Lokal - platform belanja dari warung terdekat"
                className="w-44 h-44 object-contain"
              />
            </div>
          </div>

          <h1 className="text-5xl font-bold text-white mb-4">
            Warung Lokal
          </h1>
          <p className="text-white text-lg opacity-90">
            Warungmu, Dekat di Genggaman
          </p>
        </div>
      </div>
    </MobileLayout>
  );
}