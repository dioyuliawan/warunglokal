import { useNavigate } from "react-router";
import { MobileLayout } from "../../components/MobileLayout";
import { ArrowLeft, Minus, Plus, Trash2, ShoppingBag } from "lucide-react";
import { ImageWithFallback } from "../../components/figma/ImageWithFallback";
import { useCart } from "../../context/CartContext";
import { getWarungById } from "../../data/products";
import { EmptyState } from "../../components/shared/EmptyState";

export function CartScreen() {
  const navigate = useNavigate();
  const { items, warungId, warungName, removeItem, updateQuantity, getTotalPrice } = useCart();

  // Get warung details
  const warung = warungId ? getWarungById(warungId) : null;

  const subtotal = getTotalPrice();

  // If cart is empty, show empty state
  if (items.length === 0) {
    return (
      <MobileLayout>
        <div className="min-h-screen bg-[#F1F8E9]">
          {/* Header */}
          <div className="bg-white p-4 shadow-sm">
            <div className="flex items-center gap-3">
              <button onClick={() => navigate("/home")} aria-label="Kembali ke beranda">
                <ArrowLeft size={24} className="text-gray-700" />
              </button>
              <h1 className="text-xl text-[#1B1B1B]">Keranjang</h1>
            </div>
          </div>

          {/* Empty State */}
          <EmptyState
            icon={<ShoppingBag size={64} />}
            title="Keranjang masih kosong"
            message="Yuk, mulai belanja dari warung terdekatmu"
            actionLabel="Mulai Belanja"
            onAction={() => navigate("/home")}
            className="min-h-[70vh]"
          />
        </div>
      </MobileLayout>
    );
  }

  return (
    <MobileLayout>
      <div className="min-h-screen bg-[#F1F8E9] pb-32">
        {/* Header */}
        <div className="bg-white p-4 shadow-sm">
          <div className="flex items-center gap-3">
            <button onClick={() => navigate(-1)} aria-label="Kembali">
              <ArrowLeft size={24} className="text-gray-700" />
            </button>
            <h1 className="text-xl text-[#1B1B1B]">Keranjang</h1>
          </div>
        </div>

        <div className="p-4">
          {/* Warung Header */}
          {warung && (
            <div className="bg-white rounded-2xl p-4 mb-3 shadow-sm">
              <h2 className="text-[#1B1B1B]">{warung.name}</h2>
              <p className="text-sm text-gray-600">{warung.distance} dari lokasimu</p>
            </div>
          )}

          {/* Cart Items */}
          <div className="space-y-3 mb-4">
            {items.map((item, index) => (
              <div
                key={item.id}
                className="bg-white rounded-2xl p-4 shadow-sm animate-in fade-in slide-in-from-bottom-4 duration-300"
                style={{ animationDelay: `${index * 50}ms` }}
              >
                <div className="flex gap-3 mb-3">
                  <div className="w-16 h-16 rounded-lg overflow-hidden flex-shrink-0">
                    <ImageWithFallback
                      src={item.image}
                      alt={item.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-[#1B1B1B] mb-1">{item.name}</h3>
                    <p className="text-[#1B5E20]">
                      Rp {item.price.toLocaleString()}
                    </p>
                  </div>
                  <button
                    onClick={() => removeItem(item.id)}
                    aria-label="Hapus"
                    className="text-red-500"
                  >
                    <Trash2 size={20} />
                  </button>
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => updateQuantity(item.id, -1)}
                      aria-label="Kurangi jumlah"
                      className="w-8 h-8 rounded-full border border-gray-300 flex items-center justify-center"
                    >
                      <Minus size={16} />
                    </button>
                    <span className="text-[#1B1B1B] w-8 text-center">
                      {item.quantity}
                    </span>
                    <button
                      onClick={() => updateQuantity(item.id, 1)}
                      aria-label="Tambah jumlah"
                      className="w-8 h-8 rounded-full bg-[#1B5E20] flex items-center justify-center text-white"
                    >
                      <Plus size={16} />
                    </button>
                  </div>
                  <p className="text-[#1B1B1B]">
                    Rp {(item.price * item.quantity).toLocaleString()}
                  </p>
                </div>
              </div>
            ))}
          </div>

          {/* Order Summary */}
          <div className="bg-white rounded-2xl p-4 shadow-sm">
            <h3 className="text-[#1B1B1B] mb-3">Ringkasan Belanja</h3>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Subtotal</span>
                <span className="text-[#1B1B1B]">Rp {subtotal.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Ongkir</span>
                <span className="text-[#1B5E20]">Pilih dulu</span>
              </div>
              <div className="h-px bg-gray-200 my-2"></div>
              <div className="flex justify-between">
                <span className="text-[#1B1B1B]">Total</span>
                <span className="text-xl text-[#1B5E20]">
                  Rp {subtotal.toLocaleString()}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Fixed Bottom CTA */}
        <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 p-4 shadow-lg">
          <button
            onClick={() => navigate("/checkout")}
            className="w-full py-4 px-6 rounded-full bg-[#1B5E20] text-white"
          >
            Pilih Pengiriman & Checkout
          </button>
        </div>
      </div>
    </MobileLayout>
  );
}