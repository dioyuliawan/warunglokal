import { useState } from "react";
import { useNavigate } from "react-router";
import { MobileLayout } from "../../components/MobileLayout";
import { CustomerBottomNav } from "../../components/CustomerBottomNav";
import { ArrowLeft, Clock, PackageX } from "lucide-react";
import { EmptyState } from "../../components/shared/EmptyState";

const pastOrders = [
  {
    id: "WLK-2024-0042",
    warung: "Kios Ayam Potong Pak Hendra",
    items: "Ayam Utuh x1, Hati & Ampela x2",
    total: 63000,
    date: "2 hari lalu",
  },
  {
    id: "WLK-2024-0038",
    warung: "Warung Bu Tini",
    items: "Nasi Bungkus x2, Es Teh x1",
    total: 40000,
    date: "5 hari lalu",
  },
  {
    id: "WLK-2024-0035",
    warung: "Toko Kelontong Maju",
    items: "Minyak Goreng, Gula",
    total: 52000,
    date: "1 minggu lalu",
  },
];

export function OrderHistoryScreen() {
  const [activeTab, setActiveTab] = useState<"aktif" | "selesai" | "dibatalkan">("selesai");
  const navigate = useNavigate();

  return (
    <MobileLayout showBottomNav bottomNav={<CustomerBottomNav />}>
      <div className="min-h-screen bg-[#F1F8E9]">
        {/* Header */}
        <div className="bg-white p-4 shadow-sm">
          <h1 className="text-xl text-[#1B1B1B]">Pesanan Saya</h1>
        </div>

        {/* Tabs */}
        <div className="bg-white border-b border-gray-200">
          <div className="flex">
            <button
              onClick={() => setActiveTab("aktif")}
              className={`flex-1 py-3 text-sm border-b-2 ${
                activeTab === "aktif"
                  ? "border-[#1B5E20] text-[#1B5E20]"
                  : "border-transparent text-gray-600"
              }`}
            >
              Aktif
            </button>
            <button
              onClick={() => setActiveTab("selesai")}
              className={`flex-1 py-3 text-sm border-b-2 ${
                activeTab === "selesai"
                  ? "border-[#1B5E20] text-[#1B5E20]"
                  : "border-transparent text-gray-600"
              }`}
            >
              Selesai
            </button>
            <button
              onClick={() => setActiveTab("dibatalkan")}
              className={`flex-1 py-3 text-sm border-b-2 ${
                activeTab === "dibatalkan"
                  ? "border-[#1B5E20] text-[#1B5E20]"
                  : "border-transparent text-gray-600"
              }`}
            >
              Dibatalkan
            </button>
          </div>
        </div>

        <div className="p-4">
          {activeTab === "selesai" && (
            <>
              {/* Past Orders */}
              <div className="space-y-3 mb-6">
                {pastOrders.map((order, index) => (
                  <div
                    key={order.id}
                    className="bg-white rounded-2xl p-4 shadow-sm animate-in fade-in slide-in-from-bottom-4 duration-300"
                    style={{ animationDelay: `${index * 50}ms` }}
                  >
                    <div className="mb-3">
                      <h3 className="text-[#1B1B1B] mb-1">{order.warung}</h3>
                      <p className="text-sm text-gray-600 mb-1">{order.items}</p>
                      <div className="flex items-center justify-between">
                        <span className="text-[#1B5E20]">
                          Rp {order.total.toLocaleString()}
                        </span>
                        <span className="text-xs text-gray-500">{order.date}</span>
                      </div>
                    </div>
                    <button
                      onClick={() => navigate("/cart")}
                      className="w-full py-2.5 px-4 rounded-full border-2 border-[#1B5E20] text-[#1B5E20] text-sm"
                    >
                      Pesan Lagi
                    </button>
                  </div>
                ))}
              </div>

              {/* Subscription Section */}
              <div className="bg-white rounded-2xl p-4 shadow-sm">
                <h3 className="text-[#1B1B1B] mb-3">Langganan Rutin</h3>
                <div className="p-3 bg-[#F1F8E9] rounded-xl mb-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-[#1B1B1B] mb-1">Ayam Potong Mingguan</p>
                      <p className="text-sm text-gray-600">Setiap Jumat pagi</p>
                    </div>
                    <button
                      onClick={() => alert("Edit langganan (Coming soon)")}
                      className="text-sm text-[#1B5E20] font-semibold"
                    >
                      Edit
                    </button>
                  </div>
                </div>
                <button
                  onClick={() => alert("Tambah langganan baru (Coming soon)")}
                  className="w-full py-2.5 px-4 rounded-full bg-[#1B5E20] text-white text-sm"
                >
                  + Tambah Langganan Baru
                </button>
              </div>
            </>
          )}

          {activeTab === "aktif" && (
            <EmptyState
              icon={<Clock size={64} />}
              title="Belum ada pesanan aktif"
              message="Pesanan yang sedang diproses akan muncul di sini"
              actionLabel="Mulai Belanja"
              onAction={() => navigate("/home")}
            />
          )}

          {activeTab === "dibatalkan" && (
            <EmptyState
              icon={<PackageX size={64} />}
              title="Tidak ada pesanan dibatalkan"
              message="Riwayat pesanan yang dibatalkan akan muncul di sini"
            />
          )}
        </div>
      </div>
    </MobileLayout>
  );
}
