import { useState } from "react";
import { useNavigate } from "react-router";
import { MobileLayout } from "../../components/MobileLayout";
import { CustomerBottomNav } from "../../components/CustomerBottomNav";
import { MapPin, CreditCard, Bell, Settings, Heart, ShoppingBag, Package, HelpCircle, Info, LogOut, User, Wallet, Gift, Award, Shield } from "lucide-react";

export function CustomerProfileScreen() {
  const navigate = useNavigate();
  const [isLoggedIn, setIsLoggedIn] = useState(true); // Toggle this to see guest state

  // Guest State - Not Logged In
  if (!isLoggedIn) {
    return (
      <MobileLayout showBottomNav bottomNav={<CustomerBottomNav />}>
        <div className="min-h-screen bg-[#F1F8E9]">
          {/* Header */}
          <div className="bg-gradient-to-r from-[#1B5E20] to-[#2E7D32] p-4 shadow-sm">
            <h1 className="text-xl font-bold text-white">Profil Saya</h1>
          </div>

          <div className="p-4">
            {/* Guest Profile Card */}
            <div className="bg-white rounded-2xl p-6 shadow-sm mb-4 text-center">
              <div className="w-20 h-20 bg-gray-200 rounded-full flex items-center justify-center text-gray-400 text-3xl mx-auto mb-4">
                <User size={40} />
              </div>
              <h2 className="text-xl font-bold text-[#1B1B1B] mb-2">
                Masuk atau Daftar
              </h2>
              <p className="text-sm text-gray-600 mb-6">
                Dapatkan pengalaman belanja yang lebih personal
              </p>
              
              <div className="space-y-3">
                <button
                  onClick={() => navigate("/login")}
                  className="w-full py-3 px-6 rounded-full bg-[#1B5E20] text-white font-semibold"
                >
                  Masuk
                </button>
                <button
                  onClick={() => navigate("/login")}
                  className="w-full py-3 px-6 rounded-full border-2 border-[#1B5E20] text-[#1B5E20] font-semibold"
                >
                  Daftar
                </button>
              </div>

              <div className="mt-6 pt-6 border-t border-gray-200">
                <button
                  onClick={() => navigate("/mitra/register")}
                  className="text-[#1B5E20] font-semibold text-sm"
                >
                  Daftar sebagai Mitra Warung →
                </button>
              </div>
            </div>

            {/* Grayed out menu items */}
            <div className="bg-white rounded-2xl shadow-sm opacity-50 pointer-events-none">
              <div className="p-4 flex items-center gap-3 border-b border-gray-100">
                <ShoppingBag size={20} className="text-gray-400" />
                <span className="flex-1 text-left text-gray-400">Riwayat Pesanan</span>
              </div>
              <div className="p-4 flex items-center gap-3 border-b border-gray-100">
                <Heart size={20} className="text-gray-400" />
                <span className="flex-1 text-left text-gray-400">Warung Favorit</span>
              </div>
              <div className="p-4 flex items-center gap-3 border-b border-gray-100">
                <Settings size={20} className="text-gray-400" />
                <span className="flex-1 text-left text-gray-400">Pengaturan</span>
              </div>
              <div className="p-4 flex items-center gap-3">
                <HelpCircle size={20} className="text-gray-400" />
                <span className="flex-1 text-left text-gray-400">Bantuan</span>
              </div>
            </div>
          </div>
        </div>
      </MobileLayout>
    );
  }

  // Logged In State
  return (
    <MobileLayout showBottomNav bottomNav={<CustomerBottomNav />}>
      <div className="min-h-screen bg-[#F1F8E9]">
        {/* Header */}
        <div className="bg-gradient-to-r from-[#1B5E20] to-[#2E7D32] p-4 shadow-sm">
          <h1 className="text-xl font-bold text-white">Profil Saya</h1>
        </div>

        <div className="p-4">
          {/* Profile Card */}
          <div className="bg-white rounded-2xl p-5 shadow-sm mb-4">
            <div className="flex items-center gap-4 mb-4">
              <div className="w-16 h-16 bg-[#1B5E20] rounded-full flex items-center justify-center text-white text-2xl font-bold">
                R
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <h2 className="text-lg font-bold text-[#1B1B1B]">Rina Kusuma</h2>
                  <div className="bg-blue-500 rounded-full p-0.5">
                    <Shield size={12} className="text-white" />
                  </div>
                </div>
                <p className="text-sm text-gray-600">0812-3456-7890</p>
              </div>
            </div>

            {/* SaldoKu / Voucher / Poin */}
            <div className="grid grid-cols-3 gap-2 bg-gradient-to-r from-[#1B5E20] to-[#2E7D32] rounded-xl p-4 text-white">
              <button
                onClick={() => alert("SaldoKu wallet (Coming soon)")}
                className="text-center"
              >
                <Wallet size={20} className="mx-auto mb-1" />
                <p className="text-xs font-semibold">SaldoKu</p>
                <p className="text-sm font-bold">Rp 50.000</p>
              </button>
              <button
                onClick={() => alert("Voucher saya (Coming soon)")}
                className="text-center border-l border-r border-white/30"
              >
                <Gift size={20} className="mx-auto mb-1" />
                <p className="text-xs font-semibold">Voucher</p>
                <p className="text-sm font-bold">3</p>
              </button>
              <button
                onClick={() => alert("Poin reward (Coming soon)")}
                className="text-center"
              >
                <Award size={20} className="mx-auto mb-1" />
                <p className="text-xs font-semibold">Poin</p>
                <p className="text-sm font-bold">1.250</p>
              </button>
            </div>
          </div>

          {/* Transaksi Section */}
          <div className="mb-2">
            <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2 px-1">
              Transaksi
            </p>
            <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
              <button
                onClick={() => navigate("/orders")}
                className="w-full p-4 flex items-center gap-3 border-b border-gray-100 hover:bg-gray-50"
              >
                <ShoppingBag size={20} className="text-[#1B5E20]" />
                <span className="flex-1 text-left text-[#1B1B1B]">Riwayat Pesanan</span>
              </button>
              <button
                onClick={() => alert("Pesanan aktif (Coming soon)")}
                className="w-full p-4 flex items-center gap-3 hover:bg-gray-50"
              >
                <Package size={20} className="text-[#1B5E20]" />
                <span className="flex-1 text-left text-[#1B1B1B]">Pesanan Aktif</span>
                <span className="bg-red-500 text-white text-xs font-bold px-2 py-0.5 rounded-full">2</span>
              </button>
            </div>
          </div>

          {/* Akun Section */}
          <div className="mb-2">
            <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2 px-1">
              Akun
            </p>
            <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
              <button
                onClick={() => alert("Alamat saya (Coming soon)")}
                className="w-full p-4 flex items-center gap-3 border-b border-gray-100 hover:bg-gray-50"
              >
                <MapPin size={20} className="text-[#1B5E20]" />
                <span className="flex-1 text-left text-[#1B1B1B]">Alamat Saya</span>
              </button>
              <button
                onClick={() => alert("Metode pembayaran (Coming soon)")}
                className="w-full p-4 flex items-center gap-3 border-b border-gray-100 hover:bg-gray-50"
              >
                <CreditCard size={20} className="text-[#1B5E20]" />
                <span className="flex-1 text-left text-[#1B1B1B]">
                  Metode Pembayaran
                </span>
              </button>
              <button
                onClick={() => alert("Notifikasi (Coming soon)")}
                className="w-full p-4 flex items-center gap-3 border-b border-gray-100 hover:bg-gray-50"
              >
                <Bell size={20} className="text-[#1B5E20]" />
                <span className="flex-1 text-left text-[#1B1B1B]">Notifikasi</span>
              </button>
              <button
                onClick={() => alert("Keamanan (Coming soon)")}
                className="w-full p-4 flex items-center gap-3 hover:bg-gray-50"
              >
                <Shield size={20} className="text-[#1B5E20]" />
                <span className="flex-1 text-left text-[#1B1B1B]">Keamanan</span>
              </button>
            </div>
          </div>

          {/* Lainnya Section */}
          <div className="mb-4">
            <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2 px-1">
              Lainnya
            </p>
            <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
              <button
                onClick={() => navigate("/mitra/register")}
                className="w-full p-4 flex items-center gap-3 border-b border-gray-100 hover:bg-gray-50"
              >
                <ShoppingBag size={20} className="text-[#1B5E20]" />
                <span className="flex-1 text-left text-[#1B1B1B]">Daftar Mitra Warung</span>
              </button>
              <button
                onClick={() => navigate("/bantuan")}
                className="w-full p-4 flex items-center gap-3 border-b border-gray-100 hover:bg-gray-50"
              >
                <HelpCircle size={20} className="text-[#1B5E20]" />
                <span className="flex-1 text-left text-[#1B1B1B]">Bantuan</span>
              </button>
              <button
                onClick={() => navigate("/tentang-warlok")}
                className="w-full p-4 flex items-center gap-3 hover:bg-gray-50"
              >
                <Info size={20} className="text-[#1B5E20]" />
                <span className="flex-1 text-left text-[#1B1B1B]">Tentang Warlok</span>
              </button>
            </div>
          </div>

          {/* Logout Button */}
          <button
            onClick={() => setIsLoggedIn(false)}
            className="w-full py-3 text-center text-red-600 font-semibold"
          >
            <div className="flex items-center justify-center gap-2">
              <LogOut size={18} />
              Keluar
            </div>
          </button>
        </div>
      </div>
    </MobileLayout>
  );
}