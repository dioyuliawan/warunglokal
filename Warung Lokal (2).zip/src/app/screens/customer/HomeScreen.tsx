import { useState } from "react";
import { useNavigate } from "react-router";
import { MobileLayout } from "../../components/MobileLayout";
import { CustomerBottomNav } from "../../components/CustomerBottomNav";
import { MapPin, Star, Search, Bell, List, Map as MapIcon, X, Navigation, Zap, ZoomIn, ZoomOut } from "lucide-react";
import { ImageWithFallback } from "../../components/figma/ImageWithFallback";
import { ALL_WARUNGS } from "../../data/products";
import { WarungCard } from "../../components/shared/WarungCard";

const categories = [
  { 
    id: "all", 
    name: "Semua", 
    image: "https://images.unsplash.com/photo-1710750483431-d8eb4312d971?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2YXJpZXR5JTIwc2hvcCUyMGdyb2Nlcmllc3xlbnwxfHx8fDE3NzUwMTAzNzV8MA&ixlib=rb-4.1.0&q=80&w=1080"
  },
  { 
    id: "food", 
    name: "Makanan & Minuman", 
    image: "https://images.unsplash.com/photo-1514773897744-c63156ebcd94?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmb29kJTIwYmV2ZXJhZ2UlMjBjYXRlZ29yeXxlbnwxfHx8fDE3NzUwMTAzNzR8MA&ixlib=rb-4.1.0&q=80&w=1080"
  },
  { 
    id: "fresh", 
    name: "Bahan Makanan Segar", 
    image: "https://images.unsplash.com/photo-1549248581-cf105cd081f8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmcmVzaCUyMHByb2R1Y2UlMjBtYXJrZXR8ZW58MXx8fHwxNzc0OTgyNzk3fDA&ixlib=rb-4.1.0&q=80&w=1080"
  },
  { 
    id: "grocery", 
    name: "Toko Kelontong", 
    image: "https://images.unsplash.com/photo-1753288589313-3030a6d3c1d7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRvbmVzaWFuJTIwZ3JvY2VyeSUyMHN0b3JlfGVufDF8fHx8MTc3NTAxMDM3NHww&ixlib=rb-4.1.0&q=80&w=1080"
  },
  { 
    id: "service", 
    name: "Usaha Jasa Lokal", 
    image: "https://images.unsplash.com/photo-1770529934201-a6488ad7e395?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsb2NhbCUyMGJ1c2luZXNzJTIwc2VydmljZXxlbnwxfHx8fDE3NzUwMTAzNzV8MA&ixlib=rb-4.1.0&q=80&w=1080"
  }
];

export function HomeScreen() {
  const navigate = useNavigate();
  const [viewMode, setViewMode] = useState<"map" | "list">("map");
  const [selectedWarung, setSelectedWarung] = useState<typeof ALL_WARUNGS[0] | null>(null);
  const [showGuestBanner, setShowGuestBanner] = useState(true);
  const [selectedRadius, setSelectedRadius] = useState("2 km");
  const [mapZoom, setMapZoom] = useState(15);

  const radiusOptions = ["500 m", "1 km", "2 km", "5 km", "10 km"];

  const getWarungCount = () => {
    // Filter based on selected radius (simplified logic)
    return ALL_WARUNGS.length;
  };

  const handleZoomIn = () => {
    setMapZoom(prev => Math.min(prev + 1, 20));
  };

  const handleZoomOut = () => {
    setMapZoom(prev => Math.max(prev - 1, 10));
  };

  const handleRecenterMap = () => {
    // Recenter map to current location
    setMapZoom(15);
  };

  return (
    <MobileLayout showBottomNav bottomNav={<CustomerBottomNav />}>
      <div className="min-h-screen bg-[#F1F8E9]">
        {/* Header Bar with Green Gradient */}
        <div className="bg-gradient-to-r from-[#1B5E20] to-[#2E7D32] pb-4 shadow-md">
          <div className="p-4 flex items-center justify-between">
            {/* Logo */}
            <h1 className="text-lg font-bold text-white">Warung Lokal</h1>
            
            {/* Location Chip */}
            <button className="flex items-center gap-1 px-3 py-1.5 bg-white/20 rounded-full backdrop-blur-sm">
              <MapPin size={14} className="text-white" />
              <span className="text-sm text-white font-semibold">Menteng, Jakarta Pusat</span>
            </button>

            {/* Notification Bell */}
            <button
              onClick={() => navigate("/notifikasi")}
              aria-label="Lihat notifikasi"
              className="p-2"
            >
              <Bell size={20} className="text-white" />
            </button>
          </div>

          {/* Search Bar embedded in green header */}
          <div className="px-4">
            <button
              onClick={() => navigate("/search")}
              aria-label="Cari warung atau produk"
              className="w-full px-4 py-3 bg-white rounded-full flex items-center gap-2 text-left shadow-md"
            >
              <Search size={18} className="text-gray-400" />
              <span className="text-gray-500">Cari warung atau produk di sekitarmu...</span>
            </button>
          </div>
        </div>

        {/* Guest Mode Banner */}
        {showGuestBanner && (
          <div className="bg-amber-50 border-b border-amber-200 px-4 py-2.5 flex items-center justify-between">
            <div className="flex-1 flex items-center gap-2">
              <span className="text-sm text-amber-800">
                Masuk untuk pengalaman belanja yang lebih personal
              </span>
              <button
                onClick={() => navigate("/login")}
                className="text-sm font-semibold text-amber-900 underline"
              >
                Masuk
              </button>
            </div>
            <button
              onClick={() => setShowGuestBanner(false)}
              aria-label="Tutup banner"
              className="p-1"
            >
              <X size={16} className="text-amber-600" />
            </button>
          </div>
        )}

        {/* Toggle View Buttons */}
        <div className="bg-white px-4 py-3 flex items-center justify-between border-b border-gray-200">
          <p className="text-sm text-gray-600">
            {ALL_WARUNGS.length} warung ditemukan
          </p>
          <div className="flex gap-1 bg-gray-100 rounded-lg p-1">
            <button
              onClick={() => setViewMode("map")}
              className={`p-2 rounded-md transition-colors ${
                viewMode === "map" ? "bg-white shadow-sm" : "bg-transparent"
              }`}
            >
              <MapIcon size={18} className={viewMode === "map" ? "text-[#1B5E20]" : "text-gray-500"} />
            </button>
            <button
              onClick={() => setViewMode("list")}
              className={`p-2 rounded-md transition-colors ${
                viewMode === "list" ? "bg-white shadow-sm" : "bg-transparent"
              }`}
            >
              <List size={18} className={viewMode === "list" ? "text-[#1B5E20]" : "text-gray-500"} />
            </button>
          </div>
        </div>

        {/* Category Carousel with Real Photography */}
        <div className="bg-white px-4 py-4 border-b border-gray-200">
          <div className="flex gap-4 overflow-x-auto">
            {categories.map((cat) => (
              <button
                key={cat.id}
                className="flex flex-col items-center gap-2 flex-shrink-0"
              >
                <div className="w-16 h-16 rounded-full overflow-hidden border-2 border-gray-200 hover:border-[#1B5E20] transition-colors">
                  <ImageWithFallback
                    src={cat.image}
                    alt={cat.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <span className="text-xs text-gray-700 text-center max-w-[80px] leading-tight">
                  {cat.name}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* MAP VIEW */}
        {viewMode === "map" && (
          <div>
            {/* Radius Filter */}
            <div className="bg-white px-4 py-3 border-b border-gray-200">
              <p className="text-xs text-gray-600 mb-2">Tampilkan dalam radius:</p>
              <div className="flex gap-2 overflow-x-auto pb-2">
                {radiusOptions.map((radius) => (
                  <button
                    key={radius}
                    onClick={() => setSelectedRadius(radius)}
                    className={`px-4 py-1.5 rounded-full text-sm font-semibold whitespace-nowrap border ${
                      selectedRadius === radius
                        ? "bg-[#1B5E20] text-white border-[#1B5E20]"
                        : "bg-white text-[#1B5E20] border-[#1B5E20]"
                    }`}
                  >
                    {radius}
                  </button>
                ))}
              </div>
              <p className="text-xs text-gray-600 text-right mt-1">
                {getWarungCount()} warung ditemukan
              </p>
            </div>

            {/* Map Container */}
            <div className="relative h-[45vh] bg-gray-200">
              {/* Real Map Background Image */}
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1612043743114-d19a560b70eb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaXR5JTIwc3RyZWV0JTIwbWFwJTIwcmVhbGlzdGljfGVufDF8fHx8MTc3NTAxMzg5Nnww&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Peta area Menteng Jakarta Pusat menampilkan lokasi warung-warung terdekat"
                className="w-full h-full object-cover"
              />

              {/* Warung Pins on Map */}
              {ALL_WARUNGS.map((warung) => (
                <button
                  key={warung.id}
                  onClick={() => setSelectedWarung(warung)}
                  aria-label={`Lihat ${warung.name}`}
                  className="absolute"
                  style={{ top: warung.position.top, left: warung.position.left }}
                >
                  <div
                    className={`w-6 h-6 rounded-full flex items-center justify-center shadow-lg ${
                      warung.statusColor === "green"
                        ? "bg-green-500"
                        : warung.statusColor === "red"
                        ? "bg-red-500"
                        : "bg-orange-500"
                    }`}
                  >
                    <MapPin size={14} className="text-white" />
                  </div>
                </button>
              ))}

              {/* Map Controls */}
              <div className="absolute bottom-4 right-4 flex flex-col gap-2">
                <button
                  onClick={handleZoomIn}
                  aria-label="Perbesar peta"
                  className="w-8 h-8 bg-white rounded-lg shadow flex items-center justify-center hover:bg-gray-100"
                >
                  <ZoomIn size={18} className="text-gray-700" />
                </button>
                <button
                  onClick={handleZoomOut}
                  aria-label="Perkecil peta"
                  className="w-8 h-8 bg-white rounded-lg shadow flex items-center justify-center hover:bg-gray-100"
                >
                  <ZoomOut size={18} className="text-gray-700" />
                </button>
                <button
                  onClick={handleRecenterMap}
                  aria-label="Pusatkan peta ke lokasi saya"
                  className="w-8 h-8 bg-white rounded-lg shadow flex items-center justify-center hover:bg-gray-100"
                >
                  <Navigation size={18} className="text-[#1B5E20]" />
                </button>
              </div>
            </div>

            {/* Bottom Sheet - Warung Info Card */}
            {selectedWarung && (
              <div className="fixed inset-0 z-50">
                <div
                  className="absolute inset-0 bg-black/50"
                  onClick={() => setSelectedWarung(null)}
                ></div>
                <div className="absolute bottom-0 left-0 right-0 bg-white rounded-t-3xl p-4 shadow-2xl">
                  <button
                    onClick={() => setSelectedWarung(null)}
                    aria-label="Tutup detail warung"
                    className="absolute top-4 right-4 w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center"
                  >
                    <X size={18} className="text-gray-700" />
                  </button>

                  <div className="w-12 h-1 bg-gray-300 rounded-full mx-auto mb-4"></div>

                  <div className="flex gap-3 mb-4">
                    <div className="w-20 h-20 rounded-xl overflow-hidden bg-gray-100">
                      <ImageWithFallback
                        src={selectedWarung.image}
                        alt={selectedWarung.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="flex-1">
                      <h3 className="text-[#1B1B1B] font-bold mb-1">
                        {selectedWarung.name}
                      </h3>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-xs bg-[#F1F8E9] text-[#1B5E20] px-2 py-0.5 rounded">
                          {selectedWarung.category}
                        </span>
                        <span className="text-xs text-gray-600">{selectedWarung.distance}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="flex items-center gap-1">
                          <Star size={14} className="text-[#FF6F00] fill-[#FF6F00]" />
                          <span className="text-xs font-semibold">{selectedWarung.rating}</span>
                        </div>
                        <span
                          className={`text-xs px-2 py-0.5 rounded font-semibold ${
                            selectedWarung.statusColor === "green"
                              ? "bg-green-100 text-green-700"
                              : selectedWarung.statusColor === "red"
                              ? "bg-red-100 text-red-700"
                              : "bg-orange-100 text-orange-700"
                          }`}
                        >
                          {selectedWarung.status}
                        </span>
                      </div>
                    </div>
                  </div>

                  <p className="text-sm text-gray-600 mb-4">{selectedWarung.address}</p>

                  <button
                    onClick={() => {
                      setSelectedWarung(null);
                      navigate(`/warung/${selectedWarung.id}`);
                    }}
                    className="w-full py-3 bg-[#1B5E20] text-white rounded-xl font-semibold"
                  >
                    Lihat Warung
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* LIST VIEW */}
        {viewMode === "list" && (
          <div>
            {/* Flash Sale Banner */}
            <div className="mx-4 mt-4 mb-3 p-4 bg-gradient-to-r from-[#FF6F00] to-[#FF8F00] rounded-2xl shadow-md">
              <div className="flex items-center justify-between">
                <div className="flex-1 flex items-center gap-2">
                  <Zap size={20} className="text-white fill-white" />
                  <div>
                    <h3 className="text-white font-bold mb-1">Flash Sale Lokal</h3>
                    <p className="text-white text-sm">
                      Warung Bu Tini: Nasi Bungkus -20%
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-white text-xs">Berakhir dalam</p>
                  <p className="text-white font-bold text-lg">2:45:30</p>
                </div>
              </div>
            </div>

            {/* Warung List */}
            <div className="px-4 pb-4 space-y-3">
              {ALL_WARUNGS.map((warung, index) => (
                <div
                  key={warung.id}
                  className="animate-in fade-in slide-in-from-bottom-4 duration-300"
                  style={{ animationDelay: `${index * 50}ms` }}
                >
                  <WarungCard
                    warung={warung}
                    onClick={() => navigate(`/warung/${warung.id}`)}
                    variant="list"
                    showFavoriteButton={true}
                  />
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </MobileLayout>
  );
}