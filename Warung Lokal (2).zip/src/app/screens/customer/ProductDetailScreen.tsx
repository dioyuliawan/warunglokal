import { useState } from "react";
import { useNavigate, useParams } from "react-router";
import { MobileLayout } from "../../components/MobileLayout";
import { ArrowLeft, Minus, Plus, CheckCircle } from "lucide-react";
import { ImageWithFallback } from "../../components/figma/ImageWithFallback";
import { getProductById, getWarungById } from "../../data/products";
import { useCart } from "../../context/CartContext";

export function ProductDetailScreen() {
  const [quantity, setQuantity] = useState(1);
  const [note, setNote] = useState("");
  const navigate = useNavigate();
  const { id } = useParams();
  const { addItem } = useCart();

  // Get product by ID
  const product = getProductById(id || "");

  // Get warung data for this product
  const warung = product ? getWarungById(product.warungId) : null;

  // If product not found, show error
  if (!product || !warung) {
    return (
      <MobileLayout>
        <div className="min-h-screen bg-white flex items-center justify-center">
          <div className="text-center p-8">
            <h2 className="text-xl text-[#1B1B1B] mb-2">Produk tidak ditemukan</h2>
            <p className="text-gray-600 mb-4">Produk yang Anda cari tidak tersedia.</p>
            <button
              onClick={() => navigate("/home")}
              className="px-6 py-2 bg-[#1B5E20] text-white rounded-full"
            >
              Kembali ke Home
            </button>
          </div>
        </div>
      </MobileLayout>
    );
  }

  // Check if product is out of stock
  const isOutOfStock = !product.active || product.stock === 0;

  const handleAddToCart = () => {
    if (isOutOfStock) return;

    addItem(product, quantity, note, warung.id, warung.name);
    navigate("/cart");
  };

  return (
    <MobileLayout>
      <div className="min-h-screen bg-white pb-24">
        {/* Product Image */}
        <div className="relative">
          <div className="w-full h-80 overflow-hidden">
            <ImageWithFallback
              src={product.image}
              alt={product.name}
              className="w-full h-full object-cover"
            />
          </div>
          <button
            onClick={() => navigate(-1)}
            aria-label="Kembali"
            className="absolute top-4 left-4 w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-md"
          >
            <ArrowLeft size={20} className="text-gray-700" />
          </button>
        </div>

        <div className="px-5 py-4">
          {/* Product Info */}
          <h1 className="text-2xl text-[#1B1B1B] mb-2">{product.name}</h1>
          <p className="text-2xl text-[#1B5E20] mb-3">
            Rp {product.price.toLocaleString()} <span className="text-lg text-gray-600">/ {product.unit}</span>
          </p>

          <button
            onClick={() => navigate(`/warung/${warung.id}`)}
            className="text-sm text-[#1B5E20] mb-4 flex items-center gap-1"
          >
            dari {warung.name} →
          </button>

          {/* Stock Info */}
          <div className="flex items-center gap-2 mb-4 p-3 bg-[#F1F8E9] rounded-xl">
            <CheckCircle size={18} className="text-[#1B5E20]" />
            <span className="text-sm text-[#1B1B1B]">
              Stok tersedia — {product.stock} {product.unit} hari ini
            </span>
          </div>

          {/* Description */}
          <div className="mb-6">
            <h3 className="text-[#1B1B1B] mb-2">Deskripsi</h3>
            <p className="text-sm text-gray-600 leading-relaxed">
              {product.description}
            </p>
          </div>

          {/* Quantity Selector */}
          <div className="mb-4">
            <h3 className="text-[#1B1B1B] mb-3">Jumlah</h3>
            <div className="flex items-center gap-4">
              <button
                onClick={() => setQuantity(Math.max(1, quantity - 1))}
                aria-label="Kurangi jumlah"
                className="w-10 h-10 rounded-full border-2 border-[#1B5E20] flex items-center justify-center text-[#1B5E20]"
              >
                <Minus size={20} />
              </button>
              <span className="text-2xl text-[#1B1B1B] w-12 text-center">
                {quantity}
              </span>
              <button
                onClick={() => setQuantity(quantity + 1)}
                aria-label="Tambah jumlah"
                className="w-10 h-10 rounded-full bg-[#1B5E20] flex items-center justify-center text-white"
              >
                <Plus size={20} />
              </button>
            </div>
          </div>

          {/* Note */}
          <div>
            <h3 className="text-[#1B1B1B] mb-2">Catatan (opsional)</h3>
            <textarea
              placeholder="Contoh: minta potongan 8 ya Pak..."
              value={note}
              onChange={(e) => setNote(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:border-[#1B5E20] resize-none"
              rows={3}
            />
          </div>
        </div>

        {/* Fixed Bottom CTA */}
        <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 p-4 shadow-lg">
          <button
            onClick={handleAddToCart}
            disabled={isOutOfStock}
            className={`w-full py-4 px-6 rounded-full flex items-center justify-center gap-2 ${
              isOutOfStock
                ? "bg-gray-400 text-white cursor-not-allowed"
                : "bg-[#1B5E20] text-white"
            }`}
          >
            {isOutOfStock ? "Stok Habis" : `Tambah ke Keranjang — Rp ${(product.price * quantity).toLocaleString()}`}
          </button>
        </div>
      </div>
    </MobileLayout>
  );
}