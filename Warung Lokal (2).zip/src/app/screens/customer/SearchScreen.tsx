import { useState, useMemo } from "react";
import { useNavigate } from "react-router";
import { MobileLayout } from "../../components/MobileLayout";
import { CustomerBottomNav } from "../../components/CustomerBottomNav";
import { ArrowLeft, Search, Star } from "lucide-react";
import { ImageWithFallback } from "../../components/figma/ImageWithFallback";
import { searchWarungsAndProducts } from "../../data/warungs";
import { EmptyState } from "../../components/shared/EmptyState";
import { useDebounce } from "../../hooks/useDebounce";

export function SearchScreen() {
  const [searchQuery, setSearchQuery] = useState("");
  const [recentSearches, setRecentSearches] = useState<string[]>(() => {
    try {
      const stored = localStorage.getItem('warlok_recent_searches');
      return stored ? JSON.parse(stored) : ["Ayam potong", "Warung nasi", "Sayur segar"];
    } catch {
      return ["Ayam potong", "Warung nasi", "Sayur segar"];
    }
  });
  const [selectedDistance, setSelectedDistance] = useState<string | null>(null);
  const [filterOpenNow, setFilterOpenNow] = useState(false);
  const navigate = useNavigate();

  // Debounce search query untuk performa
  const debouncedQuery = useDebounce(searchQuery, 300);

  // Perform search dengan useMemo untuk caching
  const searchResults = useMemo(() => {
    if (!debouncedQuery.trim()) {
      return { warungs: [], products: [] };
    }
    return searchWarungsAndProducts(debouncedQuery);
  }, [debouncedQuery]);

  // Save search to history
  const handleSearch = (query: string) => {
    setSearchQuery(query);
    if (query.trim() && !recentSearches.includes(query)) {
      const newSearches = [query, ...recentSearches].slice(0, 5);
      setRecentSearches(newSearches);
      try {
        localStorage.setItem('warlok_recent_searches', JSON.stringify(newSearches));
      } catch (error) {
        console.error('Error saving search history:', error);
      }
    }
  };

  return (
    <MobileLayout showBottomNav={true} bottomNav={<CustomerBottomNav />}>
      <div className="min-h-screen bg-[#F1F8E9]">
        {/* Header */}
        <div className="bg-white p-4 shadow-sm">
          <div className="flex items-center gap-3">
            <button onClick={() => navigate("/home")} aria-label="Kembali ke beranda">
              <ArrowLeft size={24} className="text-gray-700" />
            </button>
            <div className="flex-1 flex items-center gap-2 px-4 py-3 bg-gray-100 rounded-xl">
              <Search size={20} className="text-gray-400" />
              <input
                type="text"
                placeholder="Cari warung atau produk..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="flex-1 bg-transparent outline-none text-[#1B1B1B]"
                autoFocus
              />
            </div>
          </div>
        </div>

        {/* Filters */}
        <div className="bg-white px-4 py-3 border-b border-gray-100">
          <div className="flex gap-2 overflow-x-auto">
            <button
              onClick={() => alert("Filter kategori (Coming soon)")}
              className="px-3 py-1.5 rounded-full bg-gray-100 text-sm whitespace-nowrap hover:bg-gray-200"
            >
              Kategori
            </button>
            <button
              onClick={() => setSelectedDistance(selectedDistance === "500m" ? null : "500m")}
              className={`px-3 py-1.5 rounded-full text-sm whitespace-nowrap ${
                selectedDistance === "500m" ? "bg-[#1B5E20] text-white" : "bg-gray-100 hover:bg-gray-200"
              }`}
            >
              500m
            </button>
            <button
              onClick={() => setSelectedDistance(selectedDistance === "1km" ? null : "1km")}
              className={`px-3 py-1.5 rounded-full text-sm whitespace-nowrap ${
                selectedDistance === "1km" ? "bg-[#1B5E20] text-white" : "bg-gray-100 hover:bg-gray-200"
              }`}
            >
              1km
            </button>
            <button
              onClick={() => setSelectedDistance(selectedDistance === "2km" ? null : "2km")}
              className={`px-3 py-1.5 rounded-full text-sm whitespace-nowrap ${
                selectedDistance === "2km" ? "bg-[#1B5E20] text-white" : "bg-gray-100 hover:bg-gray-200"
              }`}
            >
              2km
            </button>
            <button
              onClick={() => alert("Filter rating (Coming soon)")}
              className="px-3 py-1.5 rounded-full bg-gray-100 text-sm whitespace-nowrap hover:bg-gray-200"
            >
              Rating
            </button>
            <button
              onClick={() => setFilterOpenNow(!filterOpenNow)}
              className={`px-3 py-1.5 rounded-full text-sm whitespace-nowrap ${
                filterOpenNow ? "bg-[#1B5E20] text-white" : "bg-gray-100 hover:bg-gray-200"
              }`}
            >
              Buka Sekarang
            </button>
          </div>
        </div>

        <div className="p-4 pb-20">
          {/* Recent Searches */}
          <div className="mb-6">
            <h3 className="text-[#1B1B1B] mb-3">Pencarian Terakhir</h3>
            <div className="flex flex-wrap gap-2">
              {recentSearches.map((search) => (
                <button
                  key={search}
                  onClick={() => handleSearch(search)}
                  className="px-4 py-2 bg-white rounded-full text-sm text-gray-700 border border-gray-200"
                >
                  {search}
                </button>
              ))}
            </div>
          </div>

          {/* Search Results */}
          <div>
            {searchQuery.trim() && (
              <h3 className="text-[#1B1B1B] mb-3">
                Hasil untuk "{debouncedQuery}"
              </h3>
            )}

            {/* Show results jika ada search query */}
            {debouncedQuery.trim() ? (
              <div className="space-y-4">
                {/* Warung Results */}
                {searchResults.warungs.length > 0 && (
                  <div>
                    <h4 className="text-sm font-medium text-gray-600 mb-2">
                      Warung ({searchResults.warungs.length})
                    </h4>
                    <div className="space-y-3">
                      {searchResults.warungs.map((warung) => (
                        <button
                          key={warung.id}
                          onClick={() => navigate(`/warung/${warung.id}`)}
                          className="w-full bg-white rounded-2xl p-4 shadow-sm hover:shadow-md transition-shadow text-left"
                        >
                          <div className="flex gap-3">
                            <div className="w-20 h-20 rounded-xl overflow-hidden flex-shrink-0">
                              <ImageWithFallback
                                src={warung.image}
                                alt={warung.name}
                                className="w-full h-full object-cover"
                              />
                            </div>
                            <div className="flex-1">
                              <h3 className="text-[#1B1B1B] mb-1">{warung.name}</h3>
                              <div className="flex flex-wrap gap-2 mb-2">
                                <span className="px-2 py-0.5 bg-[#F1F8E9] text-[#1B5E20] text-xs rounded-full">
                                  {warung.category}
                                </span>
                                <span className="px-2 py-0.5 bg-gray-100 text-gray-600 text-xs rounded-full">
                                  {warung.distance}
                                </span>
                              </div>
                              <div className="flex items-center gap-3">
                                <div className="flex items-center gap-1">
                                  <Star size={14} className="text-[#FF6F00] fill-[#FF6F00]" />
                                  <span className="text-sm text-gray-700">{warung.rating}</span>
                                </div>
                                <span className={`px-2 py-0.5 text-xs rounded-full ${
                                  warung.isOpen ? 'bg-[#1B5E20] text-white' : 'bg-gray-300 text-gray-700'
                                }`}>
                                  {warung.isOpen ? 'Buka' : 'Tutup'}
                                </span>
                              </div>
                            </div>
                          </div>
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Product Results */}
                {searchResults.products.length > 0 && (
                  <div>
                    <h4 className="text-sm font-medium text-gray-600 mb-2">
                      Produk ({searchResults.products.length})
                    </h4>
                    <div className="grid grid-cols-2 gap-3">
                      {searchResults.products.map((product) => (
                        <button
                          key={product.id}
                          onClick={() => navigate(`/product/${product.id}`)}
                          className="bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition-shadow text-left"
                        >
                          <div className="aspect-square">
                            <ImageWithFallback
                              src={product.image}
                              alt={product.name}
                              className="w-full h-full object-cover"
                            />
                          </div>
                          <div className="p-3">
                            <h4 className="text-sm font-medium text-gray-900 mb-1 line-clamp-2">
                              {product.name}
                            </h4>
                            <p className="text-[#1B5E20] font-semibold mb-1">
                              Rp {product.price.toLocaleString()}
                            </p>
                            <p className="text-xs text-gray-500">
                              Stok: {product.stock}
                            </p>
                          </div>
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Empty State */}
                {searchResults.warungs.length === 0 && searchResults.products.length === 0 && (
                  <EmptyState
                    icon={<Search size={64} />}
                    title="Tidak ada hasil"
                    message={`Tidak ditemukan warung atau produk untuk "${debouncedQuery}"`}
                  />
                )}
              </div>
            ) : (
              /* Show default state saat belum search */
              <div className="text-center text-gray-500 py-12">
                <Search size={48} className="mx-auto mb-3 text-gray-300" />
                <p>Cari warung atau produk favoritmu</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </MobileLayout>
  );
}