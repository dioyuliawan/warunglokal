import { useState } from "react";
import { useNavigate } from "react-router";
import { MobileLayout } from "../../components/MobileLayout";
import { ArrowLeft, Mail } from "lucide-react";

export function LoginScreen() {
  const [phone, setPhone] = useState("");
  const [isLoginMode, setIsLoginMode] = useState(true);
  const navigate = useNavigate();

  const handleSendOTP = () => {
    navigate("/home");
  };

  const handleGoogleLogin = () => {
    // Mock Google login
    navigate("/home");
  };

  return (
    <MobileLayout>
      <div className="min-h-screen p-6 bg-white">
        {/* Back button - returns to Profile page */}
        <button
          onClick={() => navigate("/profile")}
          aria-label="Kembali ke profil"
          className="mb-8 mt-4"
        >
          <ArrowLeft size={24} className="text-gray-700" />
        </button>

        <div>
          <h1 className="text-3xl font-bold mb-2 text-[#1B5E20]">
            {isLoginMode ? "Masuk" : "Daftar"}
          </h1>
          <p className="text-gray-600 mb-8">
            {isLoginMode
              ? "Masuk untuk melanjutkan belanja"
              : "Daftar untuk pengalaman belanja yang lebih baik"}
          </p>

          <div className="space-y-4">
            <div>
              <label className="block mb-2 text-[#1B1B1B]">Nomor Handphone</label>
              <input
                type="tel"
                placeholder="08xx xxxx xxxx"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:border-[#1B5E20]"
              />
            </div>

            <button
              onClick={handleSendOTP}
              className="w-full py-4 px-6 rounded-full bg-[#1B5E20] text-white font-semibold"
            >
              {isLoginMode ? "Kirim OTP" : "Daftar dengan OTP"}
            </button>

            {/* Divider */}
            <div className="flex items-center gap-3 my-6">
              <div className="flex-1 h-px bg-gray-300"></div>
              <span className="text-gray-500 text-sm">atau</span>
              <div className="flex-1 h-px bg-gray-300"></div>
            </div>

            {/* Google Login */}
            <button
              onClick={handleGoogleLogin}
              className="w-full py-3 px-6 rounded-full border-2 border-gray-300 text-gray-700 font-semibold flex items-center justify-center gap-2"
            >
              <Mail size={20} />
              Masuk dengan Google
            </button>
          </div>

          {/* Toggle Login/Register */}
          <div className="mt-8 text-center">
            <p className="text-gray-600">
              {isLoginMode ? "Belum punya akun? " : "Sudah punya akun? "}
              <button
                onClick={() => setIsLoginMode(!isLoginMode)}
                className="text-[#1B5E20] font-semibold"
              >
                {isLoginMode ? "Daftar sekarang" : "Masuk"}
              </button>
            </p>
          </div>

          {/* Daftar Mitra */}
          <div className="mt-8 pt-8 border-t border-gray-200">
            <p className="text-gray-600 mb-3 text-center">Punya usaha warung atau kios?</p>
            <button
              onClick={() => navigate("/mitra/register")}
              className="w-full py-3 px-6 rounded-full border-2 border-[#1B5E20] text-[#1B5E20] font-semibold"
            >
              Daftar sebagai Mitra Warung
            </button>
          </div>
        </div>
      </div>
    </MobileLayout>
  );
}