import { useNavigate, useParams } from "react-router";
import { MobileLayout } from "../../components/MobileLayout";
import { ArrowLeft, MessageCircle, CheckCircle, Package, Truck } from "lucide-react";

export function TrackingScreen() {
  const navigate = useNavigate();
  const { orderId } = useParams();

  const statusSteps = [
    {
      label: "Pesanan Diterima",
      time: "10:30",
      completed: true,
      icon: CheckCircle,
    },
    {
      label: "Sedang Disiapkan",
      time: "10:35",
      completed: true,
      icon: Package,
    },
    {
      label: "Sedang Dikirim",
      time: "",
      completed: false,
      active: true,
      icon: Truck,
    },
    {
      label: "Selesai",
      time: "",
      completed: false,
      icon: CheckCircle,
    },
  ];

  return (
    <MobileLayout>
      <div className="min-h-screen bg-[#F1F8E9]">
        {/* Header */}
        <div className="bg-white p-4 shadow-sm">
          <div className="flex items-center gap-3 mb-3">
            <button onClick={() => navigate("/orders")} aria-label="Kembali ke daftar pesanan">
              <ArrowLeft size={24} className="text-gray-700" />
            </button>
            <div>
              <h1 className="text-xl text-[#1B1B1B]">Lacak Pesanan</h1>
            </div>
          </div>
        </div>

        <div className="p-4">
          {/* Order Info */}
          <div className="bg-white rounded-2xl p-4 shadow-sm mb-4">
            <p className="text-sm text-gray-600 mb-1">Nomor Pesanan</p>
            <p className="text-lg text-[#1B5E20] mb-3">#{orderId}</p>
            <p className="text-[#1B1B1B]">Kios Ayam Potong Pak Hendra</p>
          </div>

          {/* Tracking Timeline */}
          <div className="bg-white rounded-2xl p-5 shadow-sm mb-4">
            <h3 className="text-[#1B1B1B] mb-4">Status Pesanan</h3>

            <div className="space-y-4">
              {statusSteps.map((step, index) => {
                const Icon = step.icon;
                return (
                  <div key={index} className="flex gap-4">
                    <div className="flex flex-col items-center">
                      <div
                        className={`w-10 h-10 rounded-full flex items-center justify-center ${
                          step.completed
                            ? "bg-[#1B5E20]"
                            : step.active
                            ? "bg-[#43A047] animate-pulse"
                            : "bg-gray-200"
                        }`}
                      >
                        <Icon
                          size={20}
                          className={step.completed || step.active ? "text-white" : "text-gray-400"}
                        />
                      </div>
                      {index < statusSteps.length - 1 && (
                        <div
                          className={`w-0.5 h-12 ${
                            step.completed ? "bg-[#1B5E20]" : "bg-gray-200"
                          }`}
                        />
                      )}
                    </div>
                    <div className="flex-1 pb-4">
                      <p
                        className={`${
                          step.completed || step.active
                            ? "text-[#1B1B1B]"
                            : "text-gray-400"
                        }`}
                      >
                        {step.label}
                      </p>
                      {step.time && (
                        <p className="text-sm text-gray-500">{step.time}</p>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="mt-4 p-3 bg-[#F1F8E9] rounded-xl">
              <p className="text-sm text-center text-[#1B1B1B]">
                Estimasi tiba: <span className="text-[#1B5E20]">11:15</span>
              </p>
            </div>
          </div>

          {/* Order Items */}
          <div className="bg-white rounded-2xl p-4 shadow-sm mb-4">
            <h3 className="text-[#1B1B1B] mb-3">Pesanan</h3>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Ayam Utuh Segar x1</span>
                <span className="text-[#1B1B1B]">Rp 38.000</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Hati & Ampela x2</span>
                <span className="text-[#1B1B1B]">Rp 20.000</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Ongkir</span>
                <span className="text-[#1B1B1B]">Rp 5.000</span>
              </div>
              <div className="h-px bg-gray-200 my-2"></div>
              <div className="flex justify-between">
                <span className="text-[#1B1B1B]">Total</span>
                <span className="text-lg text-[#1B5E20]">Rp 63.000</span>
              </div>
            </div>
          </div>

          {/* Chat Button */}
          <button
            onClick={() => alert("Chat dengan mitra (Coming soon)")}
            className="w-full py-3 px-6 rounded-full border-2 border-[#1B5E20] text-[#1B5E20] flex items-center justify-center gap-2"
          >
            <MessageCircle size={20} />
            Chat ke Mitra
          </button>
        </div>
      </div>
    </MobileLayout>
  );
}
