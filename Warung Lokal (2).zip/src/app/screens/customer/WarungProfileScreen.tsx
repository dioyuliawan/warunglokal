import { useState } from "react";
import { useNavigate, useParams } from "react-router";
import { MobileLayout } from "../../components/MobileLayout";
import { ArrowLeft, MapPin, Star, MessageCircle, CheckCircle, Share2, Heart } from "lucide-react";
import { ImageWithFallback } from "../../components/figma/ImageWithFallback";
import { getWarungById, getProductsByWarungId } from "../../data/products";
import { shareWarung } from "../../utils/share";
import { useFavorites } from "../../context/FavoritesContext";
import { useToast } from "../../context/ToastContext";

export function WarungProfileScreen() {
  const navigate = useNavigate();
  const { id } = useParams();
  const [selectedCategory, setSelectedCategory] = useState("Semua");
  const { isWarungFavorite, toggleWarungFavorite } = useFavorites();
  const { showToast } = useToast();

  // Get warung data by ID
  const warung = getWarungById(id || "");
  const isFavorite = warung ? isWarungFavorite(warung.id) : false;

  const handleShare = async () => {
    if (!warung) return;
    const success = await shareWarung(warung.id, warung.name);
    if (success) {
      showToast("Link berhasil dibagikan!", "success");
    }
  };

  const handleFavorite = () => {
    if (!warung) return;
    toggleWarungFavorite(warung.id);
    showToast(
      isFavorite ? "Dihapus dari favorit" : "Ditambahkan ke favorit",
      "success"
    );
  };

  // Get products for this specific warung (only active products)
  const allProducts = getProductsByWarungId(id || "");

  // Filter products by selected category
  const products = selectedCategory === "Semua"
    ? allProducts
    : allProducts.filter(p => p.category === selectedCategory);

  // If warung not found, show error state
  if (!warung) {
    return (
      <MobileLayout>
        <div className="min-h-screen bg-[#F1F8E9] flex items-center justify-center">
          <div className="text-center p-8">
            <h2 className="text-xl text-[#1B1B1B] mb-2">Warung tidak ditemukan</h2>
            <p className="text-gray-600 mb-4">Warung yang Anda cari tidak tersedia.</p>
            <button
              onClick={() => navigate("/home")}
              className="px-6 py-2 bg-[#1B5E20] text-white rounded-full"
            >
              Kembali ke Home
            </button>
          </div>
        </div>
      </MobileLayout>
    );
  }

  // Get unique categories from all products
  const categories = ["Semua", ...new Set(allProducts.map(p => p.category))];

  return (
    <MobileLayout>
      <div className="min-h-screen bg-[#F1F8E9] pb-32">
        {/* Hero Image */}
        <div className="relative">
          <div className="w-full h-48 overflow-hidden">
            <ImageWithFallback
              src={warung.heroImage}
              alt={warung.name}
              className="w-full h-full object-cover"
            />
          </div>
          <button
            onClick={() => navigate("/home")}
            aria-label="Kembali ke beranda"
            className="absolute top-4 left-4 w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-md"
          >
            <ArrowLeft size={20} className="text-gray-700" />
          </button>
          <div className="absolute top-4 right-4 flex gap-2">
            <button
              onClick={handleFavorite}
              aria-label={isFavorite ? "Hapus dari favorit" : "Tambah ke favorit"}
              className="w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-md hover:scale-110 active:scale-95 transition-transform"
            >
              <Heart
                size={20}
                className={`transition-colors ${
                  isFavorite ? "text-red-500 fill-red-500" : "text-gray-700"
                }`}
              />
            </button>
            <button
              onClick={handleShare}
              aria-label="Bagikan warung"
              className="w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-md hover:scale-110 active:scale-95 transition-transform"
            >
              <Share2 size={20} className="text-gray-700" />
            </button>
          </div>
        </div>

        <div className="px-4 pb-6">
          {/* Warung Info */}
          <div className="bg-white rounded-2xl p-5 -mt-6 relative z-10 shadow-md mb-4">
            <h1 className="text-xl text-[#1B1B1B] mb-1">
              {warung.name}
            </h1>
            <p className="text-sm text-gray-600 mb-1">
              Pemilik: {warung.ownerName}
            </p>
            <p className="text-sm text-gray-600 mb-3">Berdiri sejak {warung.establishedYear}</p>

            {warung.verified && (
              <div className="flex items-center gap-2 mb-3">
                <CheckCircle size={18} className="text-[#1B5E20]" />
                <span className="text-sm text-[#1B5E20]">
                  Warung Terverifikasi Warga
                </span>
              </div>
            )}

            <div className="space-y-2 mb-4">
              <div className="flex items-center gap-2">
                <div className={`w-2 h-2 rounded-full ${
                  warung.statusColor === "green" ? "bg-[#1B5E20]" : 
                  warung.statusColor === "red" ? "bg-red-500" : "bg-orange-500"
                }`}></div>
                <span className="text-sm">
                  <span className={
                    warung.statusColor === "green" ? "text-[#1B5E20]" : 
                    warung.statusColor === "red" ? "text-red-500" : "text-orange-500"
                  }>
                    {warung.status.split(" — ")[0]}
                  </span>
                  {" — "}
                  {warung.status.split(" — ")[1]}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <MapPin size={16} className="text-gray-600" />
                <span className="text-sm text-gray-600">{warung.distance} dari lokasimu</span>
              </div>
              <div className="flex items-center gap-2">
                <Star size={16} className="text-[#FF6F00] fill-[#FF6F00]" />
                <span className="text-sm">
                  <span>{warung.rating}</span> <span className="text-gray-600">({warung.reviewCount} ulasan)</span>
                </span>
              </div>
            </div>

            {/* Owner Story */}
            <div className="p-4 bg-[#F1F8E9] rounded-xl">
              <p className="text-sm text-[#1B1B1B]">
                "{warung.ownerStory}"
              </p>
            </div>
          </div>

          {/* Product Tabs */}
          <div className="bg-white rounded-t-2xl overflow-hidden">
            <div className="flex border-b border-gray-100 overflow-x-auto">
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`flex-shrink-0 py-3 px-4 text-sm ${
                    selectedCategory === cat
                      ? "border-b-2 border-[#1B5E20] text-[#1B5E20]"
                      : "text-gray-600"
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            {/* Products Grid */}
            {products.length > 0 ? (
              <div className="p-4 grid grid-cols-2 gap-3">
                {products.map((product) => {
                  const isOutOfStock = !product.active || product.stock === 0;
                  return (
                    <button
                      key={product.id}
                      onClick={() => !isOutOfStock && navigate(`/product/${product.id}`)}
                      className={`bg-white border border-gray-200 rounded-xl p-3 text-left hover:border-[#1B5E20] transition-colors relative ${
                        isOutOfStock ? "opacity-60" : ""
                      }`}
                      disabled={isOutOfStock}
                    >
                      <div className="w-full h-24 rounded-lg overflow-hidden mb-2 relative">
                        <ImageWithFallback
                          src={product.image}
                          alt={product.name}
                          className="w-full h-full object-cover"
                        />
                        {isOutOfStock && (
                          <div className="absolute inset-0 bg-gray-900/40 flex items-center justify-center">
                            <span className="bg-gray-700 text-white text-xs px-2 py-1 rounded">
                              Stok Habis
                            </span>
                          </div>
                        )}
                      </div>
                      <h3 className="text-sm text-[#1B1B1B] mb-1">{product.name}</h3>
                      <p className={isOutOfStock ? "text-gray-400" : "text-[#1B5E20]"}>
                        Rp {product.price.toLocaleString()}
                        {product.unit && `/${product.unit}`}
                      </p>
                    </button>
                  );
                })}
              </div>
            ) : (
              <div className="p-8 text-center">
                <p className="text-gray-600">Belum ada produk tersedia saat ini.</p>
              </div>
            )}
          </div>
        </div>

        {/* Floating Bottom Bar */}
        <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 p-4 shadow-lg">
          {!warung.isOpen && warung.statusColor === "red" ? (
            <div className="space-y-2">
              <button
                disabled
                className="w-full py-3 px-4 rounded-full bg-gray-400 text-white cursor-not-allowed"
              >
                Warung Sedang Tutup
              </button>
              <button
                onClick={() => alert("Kami akan mengirimkan notifikasi saat warung buka!")}
                className="w-full py-3 px-4 rounded-full border-2 border-[#1B5E20] text-[#1B5E20]"
              >
                Ingatkan Saya Saat Buka
              </button>
            </div>
          ) : (
            <div className="flex gap-3">
              <button
                onClick={() => alert("Chat dengan pemilik warung (Coming soon)")}
                className="flex-1 py-3 px-4 rounded-full border-2 border-[#1B5E20] text-[#1B5E20] flex items-center justify-center gap-2"
              >
                <MessageCircle size={20} />
                Chat ke Pemilik
              </button>
              <button
                onClick={() => alert("Lihat semua produk (Already on this page)")}
                className="flex-1 py-3 px-4 rounded-full bg-[#1B5E20] text-white"
                disabled={allProducts.length === 0}
              >
                Lihat Semua Produk
              </button>
            </div>
          )}
        </div>
      </div>
    </MobileLayout>
  );
}