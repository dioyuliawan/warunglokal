import { useState } from "react";
import { useNavigate } from "react-router";
import { MobileLayout } from "../../components/MobileLayout";
import { ArrowLeft, MapPin } from "lucide-react";
import { useCart } from "../../context/CartContext";

export function CheckoutScreen() {
  const navigate = useNavigate();
  const { items, getTotalPrice, warungName } = useCart();
  const [deliveryMethod, setDeliveryMethod] = useState<string>("antar");
  const [paymentMethod, setPaymentMethod] = useState<string>("transfer");
  const [notes, setNotes] = useState("");

  const subtotal = getTotalPrice();
  const deliveryCost = deliveryMethod === "antar" ? 5000 : deliveryMethod === "ojek" ? 12000 : 0;
  const total = subtotal + deliveryCost;

  // If cart is empty, redirect to home
  if (items.length === 0) {
    navigate("/home");
    return null;
  }

  return (
    <MobileLayout>
      <div className="min-h-screen bg-[#F1F8E9] pb-32">
        {/* Header */}
        <div className="bg-white p-4 shadow-sm">
          <div className="flex items-center gap-3">
            <button onClick={() => navigate(-1)} aria-label="Kembali">
              <ArrowLeft size={24} className="text-gray-700" />
            </button>
            <h1 className="text-xl text-[#1B1B1B]">Checkout</h1>
          </div>
        </div>

        <div className="p-4 space-y-4">
          {/* Delivery Address */}
          <div className="bg-white rounded-2xl p-4 shadow-sm">
            <div className="flex items-start gap-2 mb-2">
              <MapPin size={20} className="text-[#1B5E20] mt-0.5" />
              <div className="flex-1">
                <h3 className="text-[#1B1B1B] mb-1">Alamat Pengiriman</h3>
                <p className="text-sm text-gray-600">
                  Jl. Melati No. 12, RT 03/RW 05
                </p>
              </div>
              <button className="text-sm text-[#1B5E20]">Ubah</button>
            </div>
          </div>

          {/* Delivery Method */}
          <div className="bg-white rounded-2xl p-4 shadow-sm">
            <h3 className="text-[#1B1B1B] mb-3">Metode Pengiriman</h3>
            <div className="space-y-2">
              <button
                onClick={() => setDeliveryMethod("antar")}
                className={`w-full p-4 rounded-xl border-2 text-left transition-colors ${
                  deliveryMethod === "antar"
                    ? "border-[#1B5E20] bg-[#F1F8E9]"
                    : "border-gray-200"
                }`}
              >
                <div className="flex items-center gap-3 mb-1">
                  <div className="flex-1">
                    <h4 className="text-[#1B1B1B]">Antar Sendiri</h4>
                    <p className="text-xs text-gray-600">
                      Diantar langsung oleh mitra warung
                    </p>
                    <p className="text-xs text-gray-500 mt-1">
                      Ongkir ditentukan oleh mitra
                    </p>
                  </div>
                  <div className="text-right">
                    <span className="text-[#1B5E20]">Estimasi</span>
                    <p className="text-sm text-gray-600">Rp 6.000</p>
                    <p className="text-xs text-gray-500">(1.2 km)</p>
                  </div>
                </div>
                <div className="mt-2 p-2 bg-amber-50 border border-amber-200 rounded-lg">
                  <p className="text-xs text-amber-900">
                    Harga final dikonfirmasi setelah mitra terima pesanan
                  </p>
                </div>
              </button>

              <button
                onClick={() => setDeliveryMethod("ojek")}
                className={`w-full p-4 rounded-xl border-2 text-left transition-colors ${
                  deliveryMethod === "ojek"
                    ? "border-[#1B5E20] bg-[#F1F8E9]"
                    : "border-gray-200"
                }`}
              >
                <div className="flex items-center gap-3 mb-1">
                  <div className="flex-1">
                    <h4 className="text-[#1B1B1B]">Ojek Online</h4>
                    <p className="text-xs text-gray-600">Estimasi 30-60 menit</p>
                  </div>
                  <span className="text-[#1B5E20]">Rp 12.000</span>
                </div>
              </button>

              <button
                onClick={() => setDeliveryMethod("ambil")}
                className={`w-full p-4 rounded-xl border-2 text-left transition-colors ${
                  deliveryMethod === "ambil"
                    ? "border-[#1B5E20] bg-[#F1F8E9]"
                    : "border-gray-200"
                }`}
              >
                <div className="flex items-center gap-3 mb-1">
                  <div className="flex-1">
                    <h4 className="text-[#1B1B1B]">Ambil Sendiri</h4>
                    <p className="text-xs text-gray-600">
                      Datang langsung ke warung
                    </p>
                  </div>
                  <span className="text-[#1B5E20]">Gratis</span>
                </div>
              </button>
            </div>
          </div>

          {/* Payment Method */}
          <div className="bg-white rounded-2xl p-4 shadow-sm">
            <h3 className="text-[#1B1B1B] mb-3">Metode Pembayaran</h3>
            <div className="space-y-2">
              <button
                onClick={() => setPaymentMethod("transfer")}
                className={`w-full px-4 py-3 rounded-xl border-2 text-left ${
                  paymentMethod === "transfer"
                    ? "border-[#1B5E20] bg-[#F1F8E9]"
                    : "border-gray-200"
                }`}
              >
                Transfer Bank
              </button>
              <button
                onClick={() => setPaymentMethod("cod")}
                className={`w-full px-4 py-3 rounded-xl border-2 text-left ${
                  paymentMethod === "cod"
                    ? "border-[#1B5E20] bg-[#F1F8E9]"
                    : "border-gray-200"
                }`}
              >
                COD (Bayar di Tempat)
              </button>
              <button
                onClick={() => setPaymentMethod("dompet")}
                className={`w-full px-4 py-3 rounded-xl border-2 text-left ${
                  paymentMethod === "dompet"
                    ? "border-[#1B5E20] bg-[#F1F8E9]"
                    : "border-gray-200"
                }`}
              >
                Dompet Digital
              </button>
            </div>
          </div>

          {/* Notes */}
          <div className="bg-white rounded-2xl p-4 shadow-sm">
            <h3 className="text-[#1B1B1B] mb-2">Catatan untuk Warung</h3>
            <textarea
              placeholder="Contoh: tolong kemas dengan rapi..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-xl focus:outline-none focus:border-[#1B5E20] resize-none"
              rows={3}
            />
          </div>

          {/* Price Breakdown */}
          <div className="bg-white rounded-2xl p-4 shadow-sm">
            <h3 className="text-[#1B1B1B] mb-3">Rincian Pembayaran</h3>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Subtotal</span>
                <span className="text-[#1B1B1B]">Rp {subtotal.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Ongkir</span>
                <span className="text-[#1B1B1B]">Rp {deliveryCost.toLocaleString()}</span>
              </div>
              <div className="h-px bg-gray-200 my-2"></div>
              <div className="flex justify-between">
                <span className="text-[#1B1B1B]">Total</span>
                <span className="text-xl text-[#1B5E20]">
                  Rp {total.toLocaleString()}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Fixed Bottom CTA */}
        <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 p-4 shadow-lg">
          <button
            onClick={() => navigate("/order-confirmation")}
            className="w-full py-4 px-6 rounded-full bg-[#1B5E20] text-white"
          >
            Konfirmasi Pesanan — Rp {total.toLocaleString()}
          </button>
        </div>
      </div>
    </MobileLayout>
  );
}