import { useState } from "react";
import { useNavigate } from "react-router";
import { MobileLayout } from "../../components/MobileLayout";
import { ArrowLeft, CheckCircle } from "lucide-react";

const pendingMitras = [
  {
    id: "1",
    name: "Kios Ayam Pak Budi",
    category: "Bahan Makanan Segar",
    time: "Daftar: 1 jam lalu",
    documentsUploaded: true,
    verified: false,
  },
  {
    id: "2",
    name: "Warung Nasi Ibu Dewi",
    category: "Makanan & Minuman",
    time: "Daftar: 3 jam lalu",
    documentsUploaded: true,
    verified: false,
  },
  {
    id: "3",
    name: "Laundry Kiloan Bersih",
    category: "Usaha Jasa Lokal",
    time: "Daftar: 5 jam lalu",
    documentsUploaded: true,
    verified: false,
  },
];

export function AdminVerificationScreen() {
  const navigate = useNavigate();
  const [mitras, setMitras] = useState(pendingMitras);

  const handleApprove = (id: string) => {
    setMitras(mitras.map((m) => (m.id === id ? { ...m, verified: true } : m)));
  };

  const handleReject = (id: string) => {
    setMitras(mitras.filter((m) => m.id !== id));
  };

  return (
    <MobileLayout>
      <div className="min-h-screen bg-[#F1F8E9]">
        {/* Header */}
        <div className="bg-white p-4 shadow-sm">
          <div className="flex items-center gap-3 mb-2">
            <button onClick={() => navigate("/admin/dashboard")} aria-label="Kembali ke dashboard">
              <ArrowLeft size={24} className="text-gray-700" />
            </button>
            <h1 className="text-xl text-[#1B1B1B]">Verifikasi Mitra</h1>
          </div>
          <p className="text-sm text-gray-600 pl-9">
            Mitra Pending Verifikasi ({mitras.length})
          </p>
        </div>

        <div className="p-4 space-y-3">
          {mitras.map((mitra) => (
            <div
              key={mitra.id}
              className={`bg-white rounded-2xl p-4 shadow-sm ${
                mitra.verified ? "border-2 border-[#1B5E20]" : ""
              }`}
            >
              <div className="mb-3">
                <div className="flex items-start justify-between mb-2">
                  <div className="flex-1">
                    <h3 className="text-[#1B1B1B] mb-1">{mitra.name}</h3>
                    <p className="text-sm text-gray-600 mb-1">{mitra.category}</p>
                    <p className="text-xs text-gray-500">{mitra.time}</p>
                  </div>
                  {mitra.verified && (
                    <div className="flex items-center gap-1 px-3 py-1 bg-[#1B5E20] text-white text-xs rounded-full">
                      <CheckCircle size={14} />
                      Terverifikasi
                    </div>
                  )}
                </div>

                {mitra.documentsUploaded && (
                  <div className="flex items-center gap-1 text-sm text-[#1B5E20]">
                    <CheckCircle size={16} />
                    Dokumen sudah diupload
                  </div>
                )}
              </div>

              {!mitra.verified && (
                <div className="flex gap-2 pt-3 border-t border-gray-100">
                  <button
                    onClick={() => handleReject(mitra.id)}
                    className="flex-1 py-2.5 px-4 rounded-full border-2 border-red-500 text-red-500 text-sm"
                  >
                    ❌ Tolak
                  </button>
                  <button
                    onClick={() => handleApprove(mitra.id)}
                    className="flex-1 py-2.5 px-4 rounded-full bg-[#1B5E20] text-white text-sm"
                  >
                    ✅ Approve
                  </button>
                </div>
              )}
            </div>
          ))}

          {mitras.length === 0 && (
            <div className="text-center py-12">
              <CheckCircle size={48} className="text-[#1B5E20] mx-auto mb-3" />
              <p className="text-gray-600">Semua mitra sudah diverifikasi</p>
            </div>
          )}
        </div>
      </div>
    </MobileLayout>
  );
}
