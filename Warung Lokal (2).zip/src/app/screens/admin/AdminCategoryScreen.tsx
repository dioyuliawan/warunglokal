import { useState } from "react";
import { useNavigate } from "react-router";
import { MobileLayout } from "../../components/MobileLayout";
import { ArrowLeft, Plus } from "lucide-react";
import { ImageWithFallback } from "../../components/figma/ImageWithFallback";

const categories = [
  {
    id: "1",
    image: "https://images.unsplash.com/photo-1514773897744-c63156ebcd94?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmb29kJTIwYmV2ZXJhZ2UlMjBjYXRlZ29yeXxlbnwxfHx8fDE3NzUwMTAzNzR8MA&ixlib=rb-4.1.0&q=80&w=1080",
    name: "Makanan & Minuman",
    mitraCount: 58,
    active: true,
  },
  {
    id: "2",
    image: "https://images.unsplash.com/photo-1549248581-cf105cd081f8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmcmVzaCUyMHByb2R1Y2UlMjBtYXJrZXR8ZW58MXx8fHwxNzc0OTgyNzk3fDA&ixlib=rb-4.1.0&q=80&w=1080",
    name: "Bahan Makanan Segar",
    mitraCount: 41,
    active: true,
  },
  {
    id: "3",
    image: "https://images.unsplash.com/photo-1753288589313-3030a6d3c1d7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRvbmVzaWFuJTIwZ3JvY2VyeSUyMHN0b3JlfGVufDF8fHx8MTc3NTAxMDM3NHww&ixlib=rb-4.1.0&q=80&w=1080",
    name: "Toko Kelontong",
    mitraCount: 29,
    active: true,
  },
  {
    id: "4",
    image: "https://images.unsplash.com/photo-1770529934201-a6488ad7e395?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsb2NhbCUyMGJ1c2luZXNzJTIwc2VydmljZXxlbnwxfHx8fDE3NzUwMTAzNzV8MA&ixlib=rb-4.1.0&q=80&w=1080",
    name: "Usaha Jasa Lokal",
    mitraCount: 14,
    active: true,
  },
];

export function AdminCategoryScreen() {
  const navigate = useNavigate();
  const [categoryList, setCategoryList] = useState(categories);

  const toggleActive = (id: string) => {
    setCategoryList(
      categoryList.map((c) => (c.id === id ? { ...c, active: !c.active } : c))
    );
  };

  return (
    <MobileLayout>
      <div className="min-h-screen bg-[#F1F8E9] pb-24">
        {/* Header */}
        <div className="bg-white p-4 shadow-sm">
          <div className="flex items-center gap-3">
            <button onClick={() => navigate("/admin/dashboard")} aria-label="Kembali ke dashboard">
              <ArrowLeft size={24} className="text-gray-700" />
            </button>
            <h1 className="text-xl text-[#1B1B1B]">Kelola Kategori</h1>
          </div>
        </div>

        <div className="p-4">
          <div className="bg-white rounded-2xl p-4 shadow-sm mb-4">
            <h3 className="text-[#1B1B1B] mb-3">Kategori UMKM</h3>
            <div className="space-y-3">
              {categoryList.map((category) => (
                <div
                  key={category.id}
                  className="flex items-center gap-3 p-4 bg-[#F1F8E9] rounded-xl"
                >
                  <div className="w-12 h-12 rounded-full overflow-hidden flex-shrink-0 border-2 border-gray-200">
                    <ImageWithFallback
                      src={category.image}
                      alt={category.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="flex-1">
                    <h4 className="text-[#1B1B1B] mb-0.5">{category.name}</h4>
                    <p className="text-sm text-gray-600">
                      {category.mitraCount} mitra
                    </p>
                  </div>
                  <button
                    onClick={() => toggleActive(category.id)}
                    className={`w-14 h-7 rounded-full p-0.5 transition-colors ${
                      category.active ? "bg-[#1B5E20]" : "bg-gray-300"
                    }`}
                  >
                    <div
                      className={`w-6 h-6 rounded-full bg-white transition-transform ${
                        category.active ? "translate-x-7" : "translate-x-0"
                      }`}
                    ></div>
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Add New Category */}
          <button
            onClick={() => alert("Tambah kategori baru (Coming soon)")}
            className="w-full p-4 bg-white rounded-2xl shadow-sm flex items-center justify-center gap-2 text-[#1B5E20] hover:bg-[#F1F8E9] transition-colors"
          >
            <Plus size={24} />
            <span>Tambah Kategori Baru</span>
          </button>
        </div>
      </div>
    </MobileLayout>
  );
}