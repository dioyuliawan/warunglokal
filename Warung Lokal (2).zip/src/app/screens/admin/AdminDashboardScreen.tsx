import { useNavigate } from "react-router";
import { MobileLayout } from "../../components/MobileLayout";
import { Users, ShoppingCart, CheckCircle, ChevronRight } from "lucide-react";

const activities = [
  {
    time: "5 mnt lalu",
    text: "Kios Ayam Pak Budi mendaftar sebagai mitra baru",
  },
  {
    time: "1 jam lalu",
    text: "Warung Sate Mang Ujang diverifikasi",
  },
  {
    time: "2 jam lalu",
    text: "3 produk baru ditambahkan oleh Toko Kelontong Maju",
  },
];

export function AdminDashboardScreen() {
  const navigate = useNavigate();

  return (
    <MobileLayout>
      <div className="min-h-screen bg-[#F1F8E9]">
        {/* Header */}
        <div className="bg-gradient-to-r from-[#1B5E20] to-[#43A047] p-6">
          <h1 className="text-2xl text-white mb-1">Warung Lokal</h1>
          <p className="text-white/90">Admin Panel</p>
        </div>

        <div className="p-4">
          {/* Stats Cards */}
          <div className="grid grid-cols-3 gap-3 mb-4 -mt-8">
            <div className="bg-white rounded-2xl p-4 shadow-md">
              <Users size={28} className="text-[#1B5E20] mb-2" />
              <p className="text-2xl text-[#1B1B1B] mb-1">142</p>
              <p className="text-xs text-gray-600">Mitra Aktif</p>
            </div>
            <div className="bg-white rounded-2xl p-4 shadow-md">
              <ShoppingCart size={28} className="text-[#1B5E20] mb-2" />
              <p className="text-2xl text-[#1B1B1B] mb-1">89</p>
              <p className="text-xs text-gray-600">Transaksi Hari Ini</p>
            </div>
            <div className="bg-white rounded-2xl p-4 shadow-md">
              <CheckCircle size={28} className="text-[#FF6F00] mb-2" />
              <p className="text-2xl text-[#1B1B1B] mb-1">7</p>
              <p className="text-xs text-gray-600">Pending Verifikasi</p>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="bg-white rounded-2xl p-4 shadow-sm mb-4">
            <h3 className="text-[#1B1B1B] mb-3">Aksi Cepat</h3>
            <div className="space-y-2">
              <button
                onClick={() => navigate("/admin/verification")}
                className="w-full p-4 bg-[#F1F8E9] rounded-xl text-left hover:bg-[#e8f5e1] transition-colors flex items-center justify-between"
              >
                <div className="flex items-center gap-3">
                  <CheckCircle size={24} className="text-[#1B5E20]" />
                  <div>
                    <p className="text-[#1B1B1B]">Verifikasi Mitra</p>
                    <p className="text-xs text-gray-600">7 mitra menunggu</p>
                  </div>
                </div>
                <ChevronRight size={20} className="text-gray-400" />
              </button>

              <button
                onClick={() => navigate("/admin/categories")}
                className="w-full p-4 bg-[#F1F8E9] rounded-xl text-left hover:bg-[#e8f5e1] transition-colors flex items-center justify-between"
              >
                <div className="flex items-center gap-3">
                  <div>
                    <p className="text-[#1B1B1B]">Kelola Kategori</p>
                    <p className="text-xs text-gray-600">4 kategori aktif</p>
                  </div>
                </div>
                <ChevronRight size={20} className="text-gray-400" />
              </button>
            </div>
          </div>

          {/* Recent Activity */}
          <div className="bg-white rounded-2xl p-4 shadow-sm">
            <h3 className="text-[#1B1B1B] mb-3">Aktivitas Terbaru</h3>
            <div className="space-y-3">
              {activities.map((activity, index) => (
                <div key={index} className="flex gap-3 pb-3 border-b border-gray-100 last:border-0">
                  <div className="w-2 h-2 rounded-full bg-[#1B5E20] mt-2 flex-shrink-0"></div>
                  <div className="flex-1">
                    <p className="text-sm text-[#1B1B1B] mb-1">{activity.text}</p>
                    <p className="text-xs text-gray-500">{activity.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </MobileLayout>
  );
}
