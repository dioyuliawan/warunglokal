import { useState } from "react";
import { useNavigate } from "react-router";
import { MobileLayout } from "../../components/MobileLayout";
import { ArrowLeft, Minus, Plus, Zap, Package, Bell } from "lucide-react";
import { ImageWithFallback } from "../../components/figma/ImageWithFallback";
import { MASTER_PRODUCTS } from "../../data/products";

export function MitraStockFlashSaleScreen() {
  const navigate = useNavigate();
  const [productStock, setProductStock] = useState(MASTER_PRODUCTS.filter(p => p.active));
  const [flashSaleEnabled, setFlashSaleEnabled] = useState(false);
  const [flashSaleData, setFlashSaleData] = useState({
    product: "",
    discount: "20",
    endTime: "17:00",
  });

  const updateStock = (id: string, delta: number) => {
    setProductStock(
      productStock.map((p) =>
        p.id === id ? { ...p, stock: Math.max(0, p.stock + delta) } : p
      )
    );
  };

  return (
    <MobileLayout>
      <div className="min-h-screen bg-[#F1F8E9] pb-24">
        {/* Top App Bar */}
        <div className="bg-white shadow-sm">
          <div className="p-4 flex items-center gap-3">
            <button onClick={() => navigate("/mitra/dashboard")} aria-label="Kembali ke dashboard">
              <ArrowLeft size={24} className="text-gray-700" />
            </button>
            <h1 className="text-lg font-bold text-[#1B1B1B]">Stok & Flash Sale</h1>
          </div>
        </div>

        <div className="p-4 space-y-4">
          {/* Stock Management */}
          <div className="bg-white rounded-2xl p-4 shadow-sm">
            <h3 className="text-[#1B1B1B] font-bold mb-4">Update Stok Hari Ini</h3>
            <div className="space-y-3">
              {productStock.map((product) => (
                <div key={product.id} className="flex items-center gap-3 p-3 bg-[#F1F8E9] rounded-xl">
                  <div className="w-10 h-10 rounded-full overflow-hidden flex-shrink-0">
                    <ImageWithFallback
                      src={product.image}
                      alt={product.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold text-[#1B1B1B]">{product.name}</p>
                    <p className="text-xs text-gray-600">Stok saat ini: {product.stock}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => updateStock(product.id, -1)}
                      aria-label="Kurangi stok"
                      className="w-8 h-8 rounded-full border-2 border-gray-300 flex items-center justify-center hover:bg-gray-100"
                    >
                      <Minus size={16} className="text-gray-600" />
                    </button>
                    <span className="text-[#1B1B1B] font-bold w-8 text-center">
                      {product.stock}
                    </span>
                    <button
                      onClick={() => updateStock(product.id, 1)}
                      aria-label="Tambah stok"
                      className="w-8 h-8 rounded-full bg-[#1B5E20] flex items-center justify-center text-white hover:bg-[#145018]"
                    >
                      <Plus size={16} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
            <button
              onClick={() => alert("Stok berhasil disimpan!")}
              className="w-full mt-4 py-3 px-6 rounded-full bg-[#1B5E20] text-white font-semibold hover:bg-[#145018] transition-colors"
            >
              Simpan Stok
            </button>
          </div>

          {/* Flash Sale */}
          <div className="bg-gradient-to-br from-[#FF6F00] to-[#f57c00] rounded-2xl p-5 shadow-sm text-white">
            <div className="flex items-center gap-2 mb-4">
              <Zap size={24} className="text-white" />
              <h3 className="text-lg font-bold">Flash Sale Lokal</h3>
            </div>

            <div className="space-y-4">
              {/* Toggle */}
              <div className="flex items-center justify-between p-3 bg-white/20 rounded-xl backdrop-blur-sm">
                <span className="font-semibold">Aktifkan Flash Sale</span>
                <button
                  onClick={() => setFlashSaleEnabled(!flashSaleEnabled)}
                  className={`w-14 h-7 rounded-full p-0.5 transition-colors ${
                    flashSaleEnabled ? "bg-white" : "bg-white/30"
                  }`}
                >
                  <div
                    className={`w-6 h-6 rounded-full transition-transform ${
                      flashSaleEnabled
                        ? "translate-x-7 bg-[#FF6F00]"
                        : "translate-x-0 bg-white"
                    }`}
                  ></div>
                </button>
              </div>

              {flashSaleEnabled && (
                <>
                  {/* Product Selector */}
                  <div>
                    <label className="block mb-2 text-sm font-semibold">Pilih Produk</label>
                    <select
                      value={flashSaleData.product}
                      onChange={(e) =>
                        setFlashSaleData({ ...flashSaleData, product: e.target.value })
                      }
                      className="w-full px-4 py-3 rounded-xl bg-white text-[#1B1B1B] font-semibold focus:outline-none"
                    >
                      <option value="">Pilih produk...</option>
                      {productStock.map((p) => (
                        <option key={p.id} value={p.id}>
                          {p.name}
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Discount & Time */}
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block mb-2 text-sm font-semibold">Diskon (%)</label>
                      <input
                        type="number"
                        value={flashSaleData.discount}
                        onChange={(e) =>
                          setFlashSaleData({
                            ...flashSaleData,
                            discount: e.target.value,
                          })
                        }
                        className="w-full px-4 py-3 rounded-xl bg-white text-[#1B1B1B] font-semibold focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block mb-2 text-sm font-semibold">Habis pukul</label>
                      <input
                        type="time"
                        value={flashSaleData.endTime}
                        onChange={(e) =>
                          setFlashSaleData({
                            ...flashSaleData,
                            endTime: e.target.value,
                          })
                        }
                        className="w-full px-4 py-3 rounded-xl bg-white text-[#1B1B1B] font-semibold focus:outline-none"
                      />
                    </div>
                  </div>

                  {/* Preview Notification */}
                  <div className="p-3 bg-amber-100 border border-amber-300 rounded-xl">
                    <div className="flex items-start gap-2">
                      <Bell size={16} className="text-amber-900 mt-0.5" />
                      <div>
                        <p className="text-xs font-semibold text-amber-900 mb-1">
                          Notifikasi akan dikirim ke customer dalam radius 2 km dari warungmu
                        </p>
                        <p className="text-xs text-amber-900">
                          Estimasi: ± 47 customer
                        </p>
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() => alert("Flash Sale akan aktif dalam 5 menit!")}
                    className="w-full py-3 px-6 rounded-full bg-white text-[#FF6F00] font-bold hover:bg-gray-100 transition-colors"
                  >
                    Aktifkan Flash Sale Sekarang
                  </button>
                </>
              )}
            </div>
          </div>
        </div>
      </div>
    </MobileLayout>
  );
}