import { useState } from "react";
import { useNavigate, useSearchParams } from "react-router";
import { MobileLayout } from "../../components/MobileLayout";
import { ArrowLeft, Camera } from "lucide-react";
import { MASTER_PRODUCTS } from "../../data/products";
import { ImageWithFallback } from "../../components/figma/ImageWithFallback";

const units = ["per ekor", "per kg", "per gram", "per ikat", "per buah", "per porsi", "per 250gr", "per potong", "per pack (isi 3)"];

export function MitraAddProductScreen() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const productId = searchParams.get("id");

  // Get product data if editing
  const editingProduct = productId ? MASTER_PRODUCTS.find(p => p.id === productId) : null;

  const [formData, setFormData] = useState({
    nama: editingProduct?.name || "Ayam Utuh Segar",
    kategori: editingProduct?.category || "Ayam Utuh",
    harga: editingProduct?.price.toString() || "38000",
    satuan: editingProduct?.unit || "per ekor",
    stok: editingProduct?.stock.toString() || "15",
    deskripsi: editingProduct?.description || "Ayam kampung segar dipotong hari ini. Langsung dari peternak lokal. Bisa request potongan sesuai kebutuhan.",
    active: editingProduct?.active ?? true,
    image: editingProduct?.image || MASTER_PRODUCTS[0].image,
  });

  const handleSave = () => {
    navigate("/mitra/products");
  };

  return (
    <MobileLayout>
      <div className="min-h-screen bg-[#F1F8E9] pb-24">
        {/* Top App Bar */}
        <div className="bg-white shadow-sm">
          <div className="p-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <button onClick={() => navigate(-1)} aria-label="Kembali">
                <ArrowLeft size={24} className="text-gray-700" />
              </button>
              <h1 className="text-lg font-bold text-[#1B1B1B]">Tambah Produk</h1>
            </div>
            <button
              onClick={handleSave}
              className="text-[#1B5E20] font-semibold"
            >
              Simpan
            </button>
          </div>
        </div>

        <div className="p-4">
          <div className="bg-white rounded-2xl p-5 shadow-sm space-y-4">
            {/* Photo Upload */}
            <div>
              <label className="block text-[#1B1B1B] font-semibold mb-2">Foto Produk</label>
              <div className="w-full h-48 border-2 border-dashed border-gray-300 bg-gray-50 rounded-xl flex flex-col items-center justify-center cursor-pointer hover:bg-gray-100 transition-colors">
                <Camera size={40} className="text-gray-400 mb-2" />
                <p className="text-sm font-semibold text-gray-700">Tambah Foto Produk</p>
                <p className="text-xs text-gray-500 mt-1">Tap untuk pilih foto dari galeri atau kamera</p>
              </div>
            </div>

            {/* Product Name */}
            <div>
              <label className="block text-[#1B1B1B] font-semibold mb-2">
                Nama Produk
              </label>
              <input
                type="text"
                value={formData.nama}
                onChange={(e) =>
                  setFormData({ ...formData, nama: e.target.value })
                }
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:border-[#1B5E20]"
              />
            </div>

            {/* Category */}
            <div>
              <label className="block text-[#1B1B1B] font-semibold mb-2">
                Kategori
              </label>
              <select
                value={formData.kategori}
                onChange={(e) =>
                  setFormData({ ...formData, kategori: e.target.value })
                }
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:border-[#1B5E20] bg-white"
              >
                <option value="Bahan Makanan Segar">Bahan Makanan Segar</option>
                <option value="Makanan & Minuman">Makanan & Minuman</option>
                <option value="Toko Kelontong">Toko Kelontong</option>
                <option value="Usaha Jasa Lokal">Usaha Jasa Lokal</option>
              </select>
            </div>

            {/* Price */}
            <div>
              <label className="block text-[#1B1B1B] font-semibold mb-2">
                Harga Jual
              </label>
              <div className="flex items-center gap-2 px-4 py-3 border border-gray-300 rounded-xl">
                <span className="text-gray-600 font-semibold">Rp</span>
                <input
                  type="number"
                  value={formData.harga}
                  onChange={(e) =>
                    setFormData({ ...formData, harga: e.target.value })
                  }
                  className="flex-1 outline-none"
                />
              </div>
            </div>

            {/* Unit */}
            <div>
              <label className="block text-[#1B1B1B] font-semibold mb-2">
                Satuan
              </label>
              <select
                value={formData.satuan}
                onChange={(e) =>
                  setFormData({ ...formData, satuan: e.target.value })
                }
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:border-[#1B5E20] bg-white"
              >
                {units.map((unit) => (
                  <option key={unit} value={unit}>
                    {unit}
                  </option>
                ))}
              </select>
            </div>

            {/* Stock */}
            <div>
              <label className="block text-[#1B1B1B] font-semibold mb-2">
                Jumlah Stok
              </label>
              <input
                type="number"
                value={formData.stok}
                onChange={(e) =>
                  setFormData({ ...formData, stok: e.target.value })
                }
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:border-[#1B5E20]"
              />
            </div>

            {/* Description */}
            <div>
              <label className="block text-[#1B1B1B] font-semibold mb-2">Deskripsi Produk</label>
              <textarea
                value={formData.deskripsi}
                onChange={(e) =>
                  setFormData({ ...formData, deskripsi: e.target.value })
                }
                placeholder="Ceritakan tentang produk Anda..."
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:border-[#1B5E20] resize-none"
                rows={4}
              />
            </div>

            {/* Active Toggle */}
            <div className="flex items-center justify-between p-4 bg-[#F1F8E9] rounded-xl">
              <span className="text-[#1B1B1B] font-semibold">Tampilkan produk di Warung Lokal</span>
              <button
                onClick={() =>
                  setFormData({ ...formData, active: !formData.active })
                }
                className={`w-14 h-7 rounded-full p-0.5 transition-colors ${
                  formData.active ? "bg-[#1B5E20]" : "bg-gray-300"
                }`}
              >
                <div
                  className={`w-6 h-6 rounded-full bg-white transition-transform ${
                    formData.active ? "translate-x-7" : "translate-x-0"
                  }`}
                ></div>
              </button>
            </div>
          </div>
        </div>
      </div>
    </MobileLayout>
  );
}