import { useState } from "react";
import { useNavigate } from "react-router";
import { MobileLayout } from "../../components/MobileLayout";
import { MitraBottomNav } from "../../components/MitraBottomNav";
import { Menu, Filter, X, Check, Truck, User } from "lucide-react";

const orders = {
  baru: [
    {
      id: "WLK-0042",
      customer: "Rina Kusuma",
      items: "Ayam Utuh x1, Hati & Ampela x2",
      total: 63000,
      delivery: "Antar Sendiri",
      time: "5 menit lalu",
    },
    {
      id: "WLK-0041",
      customer: "Budi Santoso",
      items: "Dada Fillet x2",
      total: 50000,
      delivery: "Ojek Online",
      time: "12 menit lalu",
    },
    {
      id: "WLK-0040",
      customer: "Siti Aminah",
      items: "Ayam 1/2 x2, Ceker x1",
      total: 48000,
      delivery: "Ambil Sendiri",
      time: "20 menit lalu",
    },
    {
      id: "WLK-0039",
      customer: "Rudi Hartono",
      items: "Ayam Utuh x2",
      total: 76000,
      delivery: "Antar Sendiri",
      time: "35 menit lalu",
    },
  ],
};

const getDeliveryIcon = (delivery: string) => {
  if (delivery === "Antar Sendiri") return <Truck size={14} />;
  if (delivery === "Ojek Online") return <Truck size={14} />;
  return <User size={14} />;
};

export function MitraOrdersScreen() {
  const [activeTab, setActiveTab] = useState<"baru" | "diproses" | "selesai">("baru");
  const navigate = useNavigate();

  return (
    <MobileLayout showBottomNav bottomNav={<MitraBottomNav />}>
      <div className="min-h-screen bg-[#F1F8E9]">
        {/* Top App Bar */}
        <div className="bg-white shadow-sm">
          <div className="p-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <button onClick={() => navigate("/mitra/dashboard")} aria-label="Buka menu">
                <Menu size={24} className="text-gray-700" />
              </button>
              <h1 className="text-lg font-bold text-[#1B1B1B]">Pesanan Masuk</h1>
            </div>
            <button onClick={() => alert("Filter pesanan (Coming soon)")} aria-label="Filter">
              <Filter size={20} className="text-gray-700" />
            </button>
          </div>
        </div>

        {/* Tabs */}
        <div className="bg-white border-b border-gray-200">
          <div className="flex">
            <button
              onClick={() => setActiveTab("baru")}
              className={`flex-1 py-3 text-sm font-semibold border-b-2 ${
                activeTab === "baru"
                  ? "border-[#1B5E20] text-[#1B5E20]"
                  : "border-transparent text-gray-600"
              }`}
            >
              <span className="flex items-center justify-center gap-2">
                Baru
                <span className="w-5 h-5 rounded-full bg-red-500 text-white text-xs flex items-center justify-center">
                  4
                </span>
              </span>
            </button>
            <button
              onClick={() => setActiveTab("diproses")}
              className={`flex-1 py-3 text-sm font-semibold border-b-2 ${
                activeTab === "diproses"
                  ? "border-[#1B5E20] text-[#1B5E20]"
                  : "border-transparent text-gray-600"
              }`}
            >
              Diproses
            </button>
            <button
              onClick={() => setActiveTab("selesai")}
              className={`flex-1 py-3 text-sm font-semibold border-b-2 ${
                activeTab === "selesai"
                  ? "border-[#1B5E20] text-[#1B5E20]"
                  : "border-transparent text-gray-600"
              }`}
            >
              Selesai
            </button>
          </div>
        </div>

        <div className="p-4">
          {activeTab === "baru" && (
            <div className="space-y-3">
              {orders.baru.map((order) => (
                <div key={order.id} className="bg-white rounded-2xl p-4 shadow-sm">
                  <div
                    onClick={() => navigate(`/mitra/order/${order.id}`)}
                    className="cursor-pointer mb-3"
                  >
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <div className="w-10 h-10 rounded-full bg-[#1B5E20] text-white flex items-center justify-center font-bold">
                          {order.customer.charAt(0)}
                        </div>
                        <div>
                          <p className="text-sm font-bold text-[#1B1B1B]">{order.customer}</p>
                          <p className="text-xs text-gray-600">#{order.id}</p>
                        </div>
                      </div>
                      <p className="text-xs text-gray-500">{order.time}</p>
                    </div>
                    <p className="text-sm text-[#1B1B1B] mb-2">{order.items}</p>
                    <div className="flex items-center justify-between">
                      <span className="text-xs px-3 py-1.5 bg-[#F1F8E9] text-[#1B5E20] rounded-full font-semibold flex items-center gap-1">
                        {getDeliveryIcon(order.delivery)}
                        {order.delivery}
                      </span>
                      <span className="text-lg font-bold text-[#1B5E20]">
                        Rp {order.total.toLocaleString()}
                      </span>
                    </div>
                  </div>

                  <div className="flex gap-2 pt-3 border-t border-gray-100">
                    <button
                      onClick={() => {
                        if (confirm(`Tolak pesanan ${order.id}?`)) {
                          alert("Pesanan ditolak");
                        }
                      }}
                      className="flex-1 py-2.5 px-4 rounded-full border-2 border-red-500 text-red-500 text-sm font-semibold hover:bg-red-50 transition-colors flex items-center justify-center gap-1"
                    >
                      <X size={16} />
                      Tolak
                    </button>
                    <button
                      onClick={() => navigate(`/mitra/order/${order.id}`)}
                      className="flex-1 py-2.5 px-4 rounded-full bg-[#1B5E20] text-white text-sm font-semibold hover:bg-[#145018] transition-colors flex items-center justify-center gap-1"
                    >
                      <Check size={16} />
                      Konfirmasi
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}

          {activeTab === "diproses" && (
            <div className="text-center py-12">
              <p className="text-gray-500">Belum ada pesanan diproses</p>
            </div>
          )}

          {activeTab === "selesai" && (
            <div className="text-center py-12">
              <p className="text-gray-500">Belum ada pesanan selesai hari ini</p>
            </div>
          )}
        </div>
      </div>
    </MobileLayout>
  );
}