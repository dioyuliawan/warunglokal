import { useState } from "react";
import { useNavigate } from "react-router";
import { MobileLayout } from "../../components/MobileLayout";
import { ArrowLeft } from "lucide-react";

const categories = [
  "Makanan & Minuman",
  "Bahan Makanan Segar",
  "Toko Kelontong",
  "Usaha Jasa Lokal",
];

export function MitraRegisterScreen() {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    namaWarung: "",
    namaPemilik: "",
    nomorHP: "",
    kategori: "",
  });
  const navigate = useNavigate();

  const handleSubmit = () => {
    navigate("/mitra/onboarding/step2");
  };

  return (
    <MobileLayout>
      <div className="min-h-screen bg-[#F1F8E9]">
        {/* Top App Bar */}
        <div className="bg-white shadow-sm">
          <div className="p-4 flex items-center">
            <button onClick={() => navigate("/profile")} aria-label="Kembali ke profil" className="mr-3">
              <ArrowLeft size={24} className="text-gray-700" />
            </button>
            <h1 className="text-lg font-bold text-[#1B1B1B]">Daftar Mitra Warung</h1>
          </div>

          {/* Progress Bar */}
          <div className="px-4 pb-3">
            <div className="flex items-center gap-2 mb-2">
              <div className="flex-1 h-1.5 bg-[#1B5E20] rounded-full"></div>
              <div className="flex-1 h-1.5 bg-gray-200 rounded-full"></div>
              <div className="flex-1 h-1.5 bg-gray-200 rounded-full"></div>
              <div className="flex-1 h-1.5 bg-gray-200 rounded-full"></div>
            </div>
            <p className="text-xs text-gray-600">Step 1 of 4</p>
          </div>
        </div>

        <div className="p-6">
          <div className="bg-white rounded-2xl p-6 shadow-sm">
            <h2 className="text-xl font-bold text-[#1B1B1B] mb-2">
              Selamat datang!
            </h2>
            <p className="text-sm text-gray-600 mb-6">
              Mari daftarkan warungmu dalam beberapa langkah mudah.
            </p>

            {/* Step 1 - Info Warung */}
            <div className="space-y-4">
              <div>
                <label className="block text-[#1B1B1B] mb-2 font-semibold">
                  Nama Warung
                </label>
                <input
                  type="text"
                  placeholder="Contoh: Warung Bu Tini"
                  value={formData.namaWarung}
                  onChange={(e) =>
                    setFormData({ ...formData, namaWarung: e.target.value })
                  }
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:border-[#1B5E20]"
                />
              </div>

              <div>
                <label className="block text-[#1B1B1B] mb-2 font-semibold">
                  Nama Pemilik
                </label>
                <input
                  type="text"
                  placeholder="Nama lengkap pemilik"
                  value={formData.namaPemilik}
                  onChange={(e) =>
                    setFormData({ ...formData, namaPemilik: e.target.value })
                  }
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:border-[#1B5E20]"
                />
              </div>

              <div>
                <label className="block text-[#1B1B1B] mb-2 font-semibold">
                  Nomor HP
                </label>
                <input
                  type="tel"
                  placeholder="08xx xxxx xxxx"
                  value={formData.nomorHP}
                  onChange={(e) =>
                    setFormData({ ...formData, nomorHP: e.target.value })
                  }
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:border-[#1B5E20]"
                />
              </div>

              <div>
                <label className="block text-[#1B1B1B] mb-2 font-semibold">
                  Kategori Usaha
                </label>
                <select
                  value={formData.kategori}
                  onChange={(e) =>
                    setFormData({ ...formData, kategori: e.target.value })
                  }
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:border-[#1B5E20] bg-white"
                >
                  <option value="">Pilih kategori...</option>
                  {categories.map((cat) => (
                    <option key={cat} value={cat}>
                      {cat}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <button
              onClick={handleSubmit}
              className="w-full mt-6 py-4 px-6 rounded-full bg-[#1B5E20] text-white font-semibold"
            >
              Lanjut
            </button>

            <div className="mt-6 text-center">
              <button onClick={() => navigate("/login")} className="text-sm text-gray-600">
                Sudah punya akun? <span className="text-[#1B5E20] font-semibold">Masuk</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </MobileLayout>
  );
}