import { useState } from "react";
import { useNavigate } from "react-router";
import { MobileLayout } from "../../components/MobileLayout";
import { MitraBottomNav } from "../../components/MitraBottomNav";
import { Plus, Package, Zap, Menu, Bell, LogOut, Settings, BarChart3, HelpCircle } from "lucide-react";
import { ImageWithFallback } from "../../components/figma/ImageWithFallback";

export function MitraDashboardScreen() {
  const [isOpen, setIsOpen] = useState(true);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [deliveryRates, setDeliveryRates] = useState({
    under1km: "3000",
    km1to2: "6000",
    km2to3: "9000",
    above3km: "12000",
  });
  const navigate = useNavigate();

  const recentOrders = [
    {
      id: "WLK-0042",
      customer: "Rina Kusuma",
      items: "Ayam Utuh x1, Hati & Ampela x2",
      total: 63000,
      time: "5 menit lalu",
    },
    {
      id: "WLK-0041",
      customer: "Budi Santoso",
      items: "Dada Fillet x2",
      total: 50000,
      time: "12 menit lalu",
    },
  ];

  return (
    <MobileLayout showBottomNav bottomNav={<MitraBottomNav />}>
      <div className="min-h-screen bg-[#F1F8E9]">
        {/* Top App Bar */}
        <div className="bg-white shadow-sm">
          <div className="p-4 flex items-center justify-between">
            <button onClick={() => setDrawerOpen(true)} aria-label="Buka menu">
              <Menu size={24} className="text-gray-700" />
            </button>
            <h1 className="text-lg font-bold text-[#1B5E20]">Warung Lokal</h1>
            <div className="flex items-center gap-2">
              <button aria-label="Lihat notifikasi" className="relative">
                <Bell size={20} className="text-gray-700" />
                <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full text-white text-xs flex items-center justify-center">
                  4
                </span>
              </button>
              <button className="w-8 h-8 bg-[#1B5E20] rounded-full flex items-center justify-center text-white font-bold">
                H
              </button>
            </div>
          </div>
        </div>

        {/* Side Drawer */}
        {drawerOpen && (
          <>
            <div
              className="fixed inset-0 bg-black/50 z-40"
              onClick={() => setDrawerOpen(false)}
            ></div>
            <div className="fixed left-0 top-0 bottom-0 w-80 bg-white z-50 shadow-2xl">
              <div className="p-6 bg-gradient-to-r from-[#1B5E20] to-[#2E7D32]">
                <div className="flex items-center gap-3">
                  <div className="w-16 h-16 bg-white rounded-full overflow-hidden">
                    <ImageWithFallback
                      src="https://images.unsplash.com/photo-1758346973307-f43d89b39800?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmcmVzaCUyMGNoaWNrZW4lMjBtZWF0JTIwbWFya2V0fGVufDF8fHx8MTc3NTAwNzAwNHww&ixlib=rb-4.1.0&q=80&w=1080"
                      alt="Warung"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div>
                    <h3 className="text-white font-bold">Kios Ayam Pak Hendra</h3>
                    <p className="text-white text-sm opacity-90">Pak Hendra</p>
                  </div>
                </div>
              </div>

              <div className="py-2">
                <button
                  onClick={() => {
                    setDrawerOpen(false);
                    navigate("/mitra/dashboard");
                  }}
                  className="w-full px-6 py-3 flex items-center gap-3 hover:bg-gray-100"
                >
                  <BarChart3 size={20} className="text-[#1B5E20]" />
                  <span className="text-[#1B1B1B]">Dashboard</span>
                </button>
                <button
                  onClick={() => {
                    setDrawerOpen(false);
                    navigate("/mitra/products");
                  }}
                  className="w-full px-6 py-3 flex items-center gap-3 hover:bg-gray-100"
                >
                  <Package size={20} className="text-[#1B5E20]" />
                  <span className="text-[#1B1B1B]">Produk</span>
                </button>
                <button
                  onClick={() => {
                    setDrawerOpen(false);
                    navigate("/mitra/orders");
                  }}
                  className="w-full px-6 py-3 flex items-center gap-3 hover:bg-gray-100"
                >
                  <Package size={20} className="text-[#1B5E20]" />
                  <span className="text-[#1B1B1B]">Pesanan</span>
                </button>
                <button
                  onClick={() => {
                    setDrawerOpen(false);
                    navigate("/mitra/reports");
                  }}
                  className="w-full px-6 py-3 flex items-center gap-3 hover:bg-gray-100"
                >
                  <BarChart3 size={20} className="text-[#1B5E20]" />
                  <span className="text-[#1B1B1B]">Laporan</span>
                </button>
                <button
                  onClick={() => {
                    setDrawerOpen(false);
                    alert("Pengaturan warung (Coming soon)");
                  }}
                  className="w-full px-6 py-3 flex items-center gap-3 hover:bg-gray-100"
                >
                  <Settings size={20} className="text-[#1B5E20]" />
                  <span className="text-[#1B1B1B]">Pengaturan Warung</span>
                </button>
                <button
                  onClick={() => {
                    setDrawerOpen(false);
                    alert("Bantuan & support (Coming soon)");
                  }}
                  className="w-full px-6 py-3 flex items-center gap-3 hover:bg-gray-100"
                >
                  <HelpCircle size={20} className="text-[#1B5E20]" />
                  <span className="text-[#1B1B1B]">Bantuan</span>
                </button>
              </div>

              <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-gray-200">
                <button
                  onClick={() => navigate("/home")}
                  className="w-full px-6 py-3 flex items-center justify-center gap-2 text-red-600 hover:bg-red-50 rounded-lg"
                >
                  <LogOut size={20} />
                  <span className="font-semibold">Keluar dari Akun Mitra</span>
                </button>
              </div>
            </div>
          </>
        )}

        <div className="p-4">
          {/* Greeting */}
          <h2 className="text-lg text-[#1B1B1B] mb-4">
            Selamat pagi, Pak Hendra!
          </h2>

          {/* Status Toggle */}
          <div className="p-4 bg-gradient-to-r from-[#1B5E20] to-[#43A047] rounded-2xl mb-4 shadow-sm">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-3 h-3 rounded-full bg-white animate-pulse"></div>
                <span className="text-white text-lg font-bold">
                  {isOpen ? "BUKA" : "TUTUP"}
                </span>
              </div>
              <button
                onClick={() => setIsOpen(!isOpen)}
                className={`w-16 h-8 rounded-full p-1 transition-colors ${
                  isOpen ? "bg-white" : "bg-gray-400"
                }`}
              >
                <div
                  className={`w-6 h-6 rounded-full transition-transform ${
                    isOpen
                      ? "translate-x-8 bg-[#1B5E20]"
                      : "translate-x-0 bg-white"
                  }`}
                ></div>
              </button>
            </div>
            <p className="text-white text-sm mt-2">
              {isOpen
                ? "Warung terbuka untuk menerima pesanan"
                : "Tap untuk buka warung"}
            </p>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-3 gap-3 mb-4">
            <div className="bg-white rounded-xl p-4 shadow-sm">
              <p className="text-2xl font-bold text-[#1B5E20] mb-1">4</p>
              <p className="text-xs text-gray-600">Pesanan Masuk</p>
            </div>
            <div className="bg-white rounded-xl p-4 shadow-sm">
              <p className="text-2xl font-bold text-[#1B5E20] mb-1">Rp 247k</p>
              <p className="text-xs text-gray-600">Pendapatan Hari Ini</p>
            </div>
            <div className="bg-white rounded-xl p-4 shadow-sm">
              <p className="text-2xl font-bold text-[#1B5E20] mb-1">8</p>
              <p className="text-xs text-gray-600">Produk Aktif</p>
            </div>
          </div>

          {/* Recent Orders */}
          <div className="bg-white rounded-2xl p-4 shadow-sm mb-4">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-[#1B1B1B] font-bold">Pesanan Terbaru</h3>
              <button
                onClick={() => navigate("/mitra/orders")}
                className="text-sm text-[#1B5E20] font-semibold"
              >
                Lihat Semua
              </button>
            </div>
            <div className="space-y-2">
              {recentOrders.map((order) => (
                <button
                  key={order.id}
                  onClick={() => navigate(`/mitra/order/${order.id}`)}
                  className="w-full p-3 bg-[#F1F8E9] rounded-xl text-left hover:bg-[#e8f5e1] transition-colors"
                >
                  <div className="flex justify-between items-start mb-1">
                    <p className="text-sm font-semibold text-[#1B1B1B]">#{order.id}</p>
                    <p className="text-xs text-gray-600">{order.time}</p>
                  </div>
                  <p className="text-xs text-gray-600 mb-1">{order.customer}</p>
                  <p className="text-sm text-[#1B1B1B] mb-2">{order.items}</p>
                  <p className="text-sm font-bold text-[#1B5E20]">
                    Rp {order.total.toLocaleString()}
                  </p>
                </button>
              ))}
            </div>
          </div>

          {/* Quick Actions */}
          <div className="bg-white rounded-2xl p-4 shadow-sm mb-4">
            <h3 className="text-[#1B1B1B] font-bold mb-3">Aksi Cepat</h3>
            <div className="grid grid-cols-3 gap-3">
              <button
                onClick={() => navigate("/mitra/add-product")}
                className="p-4 bg-[#F1F8E9] rounded-xl hover:bg-[#e8f5e1] transition-colors"
              >
                <Plus size={24} className="text-[#1B5E20] mb-2 mx-auto" />
                <p className="text-xs text-[#1B1B1B]">Tambah Produk</p>
              </button>
              <button
                onClick={() => navigate("/mitra/stock-flashsale")}
                className="p-4 bg-[#F1F8E9] rounded-xl hover:bg-[#e8f5e1] transition-colors"
              >
                <Package size={24} className="text-[#1B5E20] mb-2 mx-auto" />
                <p className="text-xs text-[#1B1B1B]">Update Stok</p>
              </button>
              <button
                onClick={() => navigate("/mitra/stock-flashsale")}
                className="p-4 bg-[#F1F8E9] rounded-xl hover:bg-[#e8f5e1] transition-colors"
              >
                <Zap size={24} className="text-[#FF6F00] mb-2 mx-auto" />
                <p className="text-xs text-[#1B1B1B]">Flash Sale</p>
              </button>
            </div>
          </div>

          {/* Delivery Tariff Settings */}
          <div className="bg-white rounded-2xl p-4 shadow-sm mb-20">
            <h3 className="text-[#1B1B1B] font-bold mb-1">Tarif Ongkos Kirim Default</h3>
            <p className="text-xs text-gray-600 mb-3">Atur tarif default untuk pengiriman oleh kamu</p>

            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-700">Di bawah 1 km</span>
                <div className="flex items-center gap-1">
                  <span className="text-sm text-gray-600">Rp</span>
                  <input
                    type="number"
                    value={deliveryRates.under1km}
                    onChange={(e) => setDeliveryRates({ ...deliveryRates, under1km: e.target.value })}
                    className="w-20 px-2 py-1 border border-gray-300 rounded text-sm text-right"
                  />
                </div>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-700">1 km – 2 km</span>
                <div className="flex items-center gap-1">
                  <span className="text-sm text-gray-600">Rp</span>
                  <input
                    type="number"
                    value={deliveryRates.km1to2}
                    onChange={(e) => setDeliveryRates({ ...deliveryRates, km1to2: e.target.value })}
                    className="w-20 px-2 py-1 border border-gray-300 rounded text-sm text-right"
                  />
                </div>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-700">2 km – 3 km</span>
                <div className="flex items-center gap-1">
                  <span className="text-sm text-gray-600">Rp</span>
                  <input
                    type="number"
                    value={deliveryRates.km2to3}
                    onChange={(e) => setDeliveryRates({ ...deliveryRates, km2to3: e.target.value })}
                    className="w-20 px-2 py-1 border border-gray-300 rounded text-sm text-right"
                  />
                </div>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-700">Di atas 3 km</span>
                <div className="flex items-center gap-1">
                  <span className="text-sm text-gray-600">Rp</span>
                  <input
                    type="number"
                    value={deliveryRates.above3km}
                    onChange={(e) => setDeliveryRates({ ...deliveryRates, above3km: e.target.value })}
                    className="w-20 px-2 py-1 border border-gray-300 rounded text-sm text-right"
                  />
                </div>
              </div>
            </div>

            <button
              onClick={() => alert("Tarif pengiriman berhasil disimpan!")}
              className="w-full mt-4 py-2.5 bg-[#1B5E20] text-white rounded-xl font-semibold"
            >
              Simpan Tarif
            </button>

            <p className="text-xs text-gray-500 mt-2 text-center">
              Tarif ini bisa kamu ubah per pesanan di halaman Detail Pesanan
            </p>
          </div>
        </div>
      </div>
    </MobileLayout>
  );
}