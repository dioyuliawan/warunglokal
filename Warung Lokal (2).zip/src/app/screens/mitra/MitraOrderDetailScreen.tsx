import { useState } from "react";
import { useNavigate, useParams } from "react-router";
import { MobileLayout } from "../../components/MobileLayout";
import { ArrowLeft, MessageCircle, MapPin, Truck } from "lucide-react";

export function MitraOrderDetailScreen() {
  const navigate = useNavigate();
  const { orderId } = useParams();
  const [ongkir, setOngkir] = useState("6000");
  const [selectedDistance, setSelectedDistance] = useState("1-2 km");

  const distancePricing = [
    { range: "< 1 km", price: "3000" },
    { range: "1-2 km", price: "6000" },
    { range: "2-3 km", price: "9000" },
    { range: "> 3 km", price: "12000" },
  ];

  return (
    <MobileLayout>
      <div className="min-h-screen bg-[#F1F8E9] pb-40">
        {/* Top App Bar */}
        <div className="bg-white shadow-sm">
          <div className="p-4 flex items-center gap-3">
            <button onClick={() => navigate("/mitra/orders")} aria-label="Kembali ke daftar pesanan">
              <ArrowLeft size={24} className="text-gray-700" />
            </button>
            <div>
              <h1 className="text-lg font-bold text-[#1B1B1B]">Detail Pesanan</h1>
              <p className="text-sm text-gray-600">#{orderId}</p>
            </div>
          </div>
        </div>

        <div className="p-4 space-y-4">
          {/* Customer Info */}
          <div className="bg-white rounded-2xl p-4 shadow-sm">
            <h3 className="text-[#1B1B1B] font-bold mb-3">Informasi Pelanggan</h3>
            <div className="flex items-center gap-3 mb-3">
              <div className="w-12 h-12 rounded-full bg-[#1B5E20] text-white flex items-center justify-center font-bold text-lg">
                R
              </div>
              <div>
                <p className="text-[#1B1B1B] font-semibold">Rina Kusuma</p>
                <p className="text-sm text-gray-600">0812-xxxx-xxxx</p>
              </div>
            </div>
            <div className="flex items-start gap-2 p-3 bg-[#F1F8E9] rounded-xl">
              <MapPin size={18} className="text-[#1B5E20] mt-0.5 flex-shrink-0" />
              <div className="flex-1">
                <p className="text-sm text-gray-600 mb-1">Alamat Pengiriman</p>
                <p className="text-sm text-[#1B1B1B]">
                  Jl. Melati No. 12, RT 03/RW 05, Menteng, Jakarta Pusat
                </p>
              </div>
            </div>
          </div>

          {/* Delivery Method & Ongkir */}
          <div className="bg-white rounded-2xl p-4 shadow-sm">
            <h3 className="text-[#1B1B1B] font-bold mb-3">Metode Pengiriman</h3>
            <div className="flex items-center gap-2 p-3 bg-[#F1F8E9] rounded-xl mb-4">
              <Truck size={18} className="text-[#1B5E20]" />
              <span className="text-sm font-semibold text-[#1B5E20]">Antar Sendiri oleh Mitra</span>
            </div>

            {/* Ongkos Kirim Section */}
            <div className="border-t border-gray-200 pt-4">
              <div className="mb-2">
                <label className="block text-sm font-semibold text-[#1B1B1B] mb-1">
                  Ongkos Kirim
                </label>
                <p className="text-xs text-gray-600 mb-2">
                  Jarak ke customer: 1.2 km
                </p>
              </div>

              <div className="flex items-center gap-2 px-4 py-3 border-2 border-[#1B5E20] rounded-xl mb-2">
                <span className="text-gray-700 font-semibold">Rp</span>
                <input
                  type="number"
                  value={ongkir}
                  onChange={(e) => setOngkir(e.target.value)}
                  className="flex-1 outline-none font-semibold text-[#1B5E20]"
                />
              </div>

              <p className="text-xs text-gray-600 mb-3">
                Kamu bisa sesuaikan ongkos kirim berdasarkan jarak
              </p>

              {/* Distance-based suggestion chips */}
              <div className="grid grid-cols-2 gap-2 mb-3">
                {distancePricing.map((item) => (
                  <button
                    key={item.range}
                    onClick={() => {
                      setSelectedDistance(item.range);
                      setOngkir(item.price);
                    }}
                    className={`p-2 rounded-lg border-2 text-xs font-semibold transition-colors ${
                      selectedDistance === item.range
                        ? "border-[#1B5E20] bg-[#F1F8E9] text-[#1B5E20]"
                        : "border-gray-200 bg-white text-gray-600"
                    }`}
                  >
                    <div>{item.range}</div>
                    <div>Rp {parseInt(item.price).toLocaleString()}</div>
                  </button>
                ))}
              </div>

              <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl">
                <p className="text-xs text-amber-900">
                  Ongkos kirim yang kamu tentukan akan dikonfirmasi customer sebelum pesanan diproses
                </p>
              </div>
            </div>
          </div>

          {/* Order Items */}
          <div className="bg-white rounded-2xl p-4 shadow-sm">
            <h3 className="text-[#1B1B1B] font-bold mb-3">Pesanan</h3>
            <div className="space-y-2 mb-3">
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Ayam Utuh Segar x1</span>
                <span className="text-[#1B1B1B] font-semibold">Rp 38.000</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Hati & Ampela x2</span>
                <span className="text-[#1B1B1B] font-semibold">Rp 20.000</span>
              </div>
            </div>

            {/* Notes */}
            <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-xl mb-3">
              <p className="text-xs text-gray-600 mb-1 font-semibold">Catatan dari customer:</p>
              <p className="text-sm text-[#1B1B1B]">
                "Ayamnya minta dibersihkan ya Pak"
              </p>
            </div>

            {/* Total */}
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Subtotal</span>
                <span className="text-[#1B1B1B]">Rp 58.000</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Ongkos Kirim</span>
                <span className="text-[#1B1B1B]">Rp {parseInt(ongkir).toLocaleString()}</span>
              </div>
              <div className="h-px bg-gray-200"></div>
              <div className="flex justify-between">
                <span className="text-[#1B1B1B] font-bold">Total</span>
                <span className="text-xl font-bold text-[#1B5E20]">
                  Rp {(58000 + parseInt(ongkir)).toLocaleString()}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Fixed Bottom Actions */}
        <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 p-4 shadow-lg">
          <div className="space-y-2">
            <button
              onClick={() => navigate("/mitra/konfirmasi-sedang-dikirim")}
              className="w-full py-4 px-6 rounded-full bg-[#1B5E20] text-white font-semibold hover:bg-[#145018] transition-colors"
            >
              Tandai Sedang Dikirim
            </button>
            <button
              onClick={() => navigate("/mitra/chat/customer-123")}
              className="w-full py-3 px-6 rounded-full border-2 border-[#1B5E20] text-[#1B5E20] font-semibold hover:bg-[#F1F8E9] transition-colors flex items-center justify-center gap-2"
            >
              <MessageCircle size={20} />
              Chat ke Customer
            </button>
          </div>
        </div>
      </div>
    </MobileLayout>
  );
}