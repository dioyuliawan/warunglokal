import { useState } from "react";
import { useNavigate } from "react-router";
import { MobileLayout } from "../../components/MobileLayout";
import { MitraBottomNav } from "../../components/MitraBottomNav";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, ResponsiveContainer } from "recharts";
import { ArrowLeft, Download, TrendingUp, ShoppingCart, DollarSign } from "lucide-react";
import { ImageWithFallback } from "../../components/figma/ImageWithFallback";
import { MASTER_PRODUCTS } from "../../data/products";

const chartData = [
  { day: "Sen", amount: 150000 },
  { day: "Sel", amount: 180000 },
  { day: "Rab", amount: 220000 },
  { day: "Kam", amount: 165000 },
  { day: "Jum", amount: 240000 },
  { day: "Sab", amount: 195000 },
  { day: "Min", amount: 90000 },
];

const topProducts = [
  { 
    rank: 1, 
    product: MASTER_PRODUCTS[0], // Ayam Utuh Segar
    sold: 42,
  },
  { 
    rank: 2, 
    product: MASTER_PRODUCTS[2], // Dada Ayam Fillet
    sold: 31,
  },
  { 
    rank: 3, 
    product: MASTER_PRODUCTS[3], // Hati & Ampela
    sold: 28,
  },
];

export function MitraReportsScreen() {
  const [activeTab, setActiveTab] = useState<"hari" | "minggu" | "bulan">("minggu");
  const navigate = useNavigate();

  return (
    <MobileLayout showBottomNav bottomNav={<MitraBottomNav />}>
      <div className="min-h-screen bg-[#F1F8E9]">
        {/* Top App Bar */}
        <div className="bg-white shadow-sm">
          <div className="p-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <button onClick={() => navigate("/mitra/dashboard")} aria-label="Kembali ke dashboard">
                <ArrowLeft size={24} className="text-gray-700" />
              </button>
              <h1 className="text-lg font-bold text-[#1B1B1B]">Laporan Penjualan</h1>
            </div>
            <button onClick={() => alert("Unduh laporan (Coming soon)")} aria-label="Unduh laporan">
              <Download size={20} className="text-gray-700" />
            </button>
          </div>
        </div>

        {/* Tabs */}
        <div className="bg-white border-b border-gray-200">
          <div className="flex">
            <button
              onClick={() => setActiveTab("hari")}
              className={`flex-1 py-3 text-sm font-semibold border-b-2 ${
                activeTab === "hari"
                  ? "border-[#1B5E20] text-[#1B5E20]"
                  : "border-transparent text-gray-600"
              }`}
            >
              Hari Ini
            </button>
            <button
              onClick={() => setActiveTab("minggu")}
              className={`flex-1 py-3 text-sm font-semibold border-b-2 ${
                activeTab === "minggu"
                  ? "border-[#1B5E20] text-[#1B5E20]"
                  : "border-transparent text-gray-600"
              }`}
            >
              Minggu Ini
            </button>
            <button
              onClick={() => setActiveTab("bulan")}
              className={`flex-1 py-3 text-sm font-semibold border-b-2 ${
                activeTab === "bulan"
                  ? "border-[#1B5E20] text-[#1B5E20]"
                  : "border-transparent text-gray-600"
              }`}
            >
              Bulan Ini
            </button>
          </div>
        </div>

        <div className="p-4">
          {/* Summary Stats Cards */}
          <div className="grid grid-cols-3 gap-3 mb-4">
            <div className="bg-white rounded-xl p-4 shadow-sm">
              <div className="flex items-center justify-center w-10 h-10 bg-[#F1F8E9] rounded-full mb-2 mx-auto">
                <DollarSign size={20} className="text-[#1B5E20]" />
              </div>
              <p className="text-xs text-gray-600 mb-1 text-center">Total Pendapatan</p>
              <p className="text-lg font-bold text-[#1B5E20] text-center">Rp 1.240k</p>
            </div>
            <div className="bg-white rounded-xl p-4 shadow-sm">
              <div className="flex items-center justify-center w-10 h-10 bg-[#F1F8E9] rounded-full mb-2 mx-auto">
                <ShoppingCart size={20} className="text-[#1B5E20]" />
              </div>
              <p className="text-xs text-gray-600 mb-1 text-center">Total Transaksi</p>
              <p className="text-lg font-bold text-[#1B5E20] text-center">38</p>
            </div>
            <div className="bg-white rounded-xl p-4 shadow-sm">
              <div className="flex items-center justify-center w-10 h-10 bg-[#F1F8E9] rounded-full mb-2 mx-auto">
                <TrendingUp size={20} className="text-[#1B5E20]" />
              </div>
              <p className="text-xs text-gray-600 mb-1 text-center">Rata-rata Order</p>
              <p className="text-lg font-bold text-[#1B5E20] text-center">Rp 32.6k</p>
            </div>
          </div>

          {/* Chart */}
          <div className="bg-white rounded-2xl p-4 shadow-sm mb-4">
            <h3 className="text-[#1B1B1B] font-bold mb-4">Grafik Penjualan</h3>
            <div className="h-48">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
                  <XAxis dataKey="day" tick={{ fontSize: 12 }} />
                  <YAxis tick={{ fontSize: 12 }} />
                  <Bar dataKey="amount" fill="#1B5E20" radius={[8, 8, 0, 0]} key="sales-bar" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Top Products */}
          <div className="bg-white rounded-2xl p-4 shadow-sm mb-4">
            <h3 className="text-[#1B1B1B] font-bold mb-4">Top Produk Terlaris</h3>
            <div className="space-y-3">
              {topProducts.map((product) => (
                <div
                  key={product.rank}
                  className="flex items-center gap-3 p-3 bg-[#F1F8E9] rounded-xl"
                >
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-white ${
                    product.rank === 1 ? 'bg-[#FFD700]' :
                    product.rank === 2 ? 'bg-[#C0C0C0]' :
                    'bg-[#CD7F32]'
                  }`}>
                    {product.rank}
                  </div>
                  <div className="w-12 h-12 rounded-lg overflow-hidden">
                    <ImageWithFallback
                      src={product.product.image}
                      alt={product.product.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-bold text-[#1B1B1B]">{product.product.name}</p>
                    <p className="text-xs text-gray-600">
                      {product.sold} terjual
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Download Report Button */}
          <button
            onClick={() => alert("Mengunduh laporan PDF...")}
            className="w-full py-3 px-6 rounded-full border-2 border-[#1B5E20] text-[#1B5E20] font-semibold hover:bg-[#F1F8E9] transition-colors flex items-center justify-center gap-2"
          >
            <Download size={18} />
            Unduh Laporan
          </button>
        </div>
      </div>
    </MobileLayout>
  );
}