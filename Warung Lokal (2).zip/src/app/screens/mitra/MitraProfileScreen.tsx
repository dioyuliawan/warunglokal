import { useState } from "react";
import { useNavigate } from "react-router";
import { MobileLayout } from "../../components/MobileLayout";
import { MitraBottomNav } from "../../components/MitraBottomNav";
import {
  ArrowLeft,
  User,
  Store,
  MapPin,
  Phone,
  Mail,
  Clock,
  Edit,
  LogOut,
  Settings,
  HelpCircle,
  FileText,
  Info
} from "lucide-react";

export function MitraProfileScreen() {
  const navigate = useNavigate();
  const [isLoggedIn] = useState(true);

  const mitraInfo = {
    name: "Pak Hendra",
    warungName: "Kios Ayam Potong Pak Hendra",
    phone: "0812-3456-7890",
    email: "hendra@email.com",
    address: "Jl. Kebon Sirih No. 45, Menteng, Jakarta Pusat",
    joinDate: "Bergabung sejak Januari 2025",
    businessHours: "06:00 - 18:00",
  };

  const menuItems = [
    {
      icon: Edit,
      label: "Edit Profil Warung",
      onClick: () => alert("Edit profil warung (Coming soon)"),
    },
    {
      icon: Store,
      label: "Informasi Warung",
      onClick: () => alert("Informasi warung (Coming soon)"),
    },
    {
      icon: Settings,
      label: "Pengaturan",
      onClick: () => alert("Pengaturan (Coming soon)"),
    },
    {
      icon: HelpCircle,
      label: "Bantuan & Dukungan",
      onClick: () => alert("Bantuan & dukungan (Coming soon)"),
    },
    {
      icon: Info,
      label: "Tentang Warlok",
      onClick: () => alert("Tentang Warlok (Coming soon)"),
    },
    {
      icon: FileText,
      label: "Syarat & Ketentuan",
      onClick: () => alert("Syarat & ketentuan (Coming soon)"),
    },
  ];

  return (
    <MobileLayout showBottomNav bottomNav={<MitraBottomNav />}>
      <div className="min-h-screen bg-[#F1F8E9]">
        {/* Header */}
        <div className="bg-gradient-to-r from-[#1B5E20] to-[#2E7D32] shadow-sm">
          <div className="p-4 flex items-center gap-3">
            <button onClick={() => navigate("/mitra/dashboard")} aria-label="Kembali ke dashboard">
              <ArrowLeft size={24} className="text-white" />
            </button>
            <h1 className="text-lg font-bold text-white">Profil Mitra</h1>
          </div>

          {/* Profile Card */}
          <div className="px-4 pb-6">
            <div className="bg-white rounded-2xl p-5 shadow-lg">
              <div className="flex items-start gap-4">
                <div className="w-16 h-16 rounded-full bg-[#1B5E20] text-white flex items-center justify-center font-bold text-2xl flex-shrink-0">
                  H
                </div>
                <div className="flex-1">
                  <h2 className="text-lg font-bold text-[#1B1B1B] mb-1">
                    {mitraInfo.name}
                  </h2>
                  <p className="text-sm text-gray-600 mb-2">{mitraInfo.warungName}</p>
                  <p className="text-xs text-gray-500">{mitraInfo.joinDate}</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="p-4 space-y-4">
          {/* Contact Info */}
          <div className="bg-white rounded-2xl p-4 shadow-sm">
            <h3 className="text-[#1B1B1B] font-bold mb-4">Informasi Kontak</h3>
            <div className="space-y-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-[#F1F8E9] flex items-center justify-center">
                  <Phone size={18} className="text-[#1B5E20]" />
                </div>
                <div className="flex-1">
                  <p className="text-xs text-gray-600">Nomor Telepon</p>
                  <p className="text-sm font-semibold text-[#1B1B1B]">{mitraInfo.phone}</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-[#F1F8E9] flex items-center justify-center">
                  <Mail size={18} className="text-[#1B5E20]" />
                </div>
                <div className="flex-1">
                  <p className="text-xs text-gray-600">Email</p>
                  <p className="text-sm font-semibold text-[#1B1B1B]">{mitraInfo.email}</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-full bg-[#F1F8E9] flex items-center justify-center">
                  <MapPin size={18} className="text-[#1B5E20]" />
                </div>
                <div className="flex-1">
                  <p className="text-xs text-gray-600">Alamat Warung</p>
                  <p className="text-sm font-semibold text-[#1B1B1B]">{mitraInfo.address}</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-[#F1F8E9] flex items-center justify-center">
                  <Clock size={18} className="text-[#1B5E20]" />
                </div>
                <div className="flex-1">
                  <p className="text-xs text-gray-600">Jam Operasional</p>
                  <p className="text-sm font-semibold text-[#1B1B1B]">{mitraInfo.businessHours}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Menu Items */}
          <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
            {menuItems.map((item, index) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.label}
                  onClick={item.onClick}
                  className={`w-full flex items-center gap-3 p-4 hover:bg-gray-50 transition-colors ${
                    index !== menuItems.length - 1 ? "border-b border-gray-100" : ""
                  }`}
                >
                  <div className="w-10 h-10 rounded-full bg-[#F1F8E9] flex items-center justify-center">
                    <Icon size={18} className="text-[#1B5E20]" />
                  </div>
                  <span className="flex-1 text-left text-sm font-semibold text-[#1B1B1B]">
                    {item.label}
                  </span>
                  <ArrowLeft size={16} className="text-gray-400 rotate-180" />
                </button>
              );
            })}
          </div>

          {/* Logout Button */}
          <button
            onClick={() => {
              // Simple logout - redirect to customer profile
              navigate("/profile");
            }}
            className="w-full flex items-center justify-center gap-2 py-3 px-6 rounded-full border-2 border-red-500 text-red-500 font-semibold hover:bg-red-50 transition-colors"
          >
            <LogOut size={18} />
            Keluar dari Akun Mitra
          </button>
        </div>
      </div>
    </MobileLayout>
  );
}
