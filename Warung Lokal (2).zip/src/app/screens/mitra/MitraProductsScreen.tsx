import { useState } from "react";
import { useNavigate } from "react-router";
import { MobileLayout } from "../../components/MobileLayout";
import { MitraBottomNav } from "../../components/MitraBottomNav";
import { Search, Plus, ArrowLeft, MoreVertical, Package } from "lucide-react";
import { ImageWithFallback } from "../../components/figma/ImageWithFallback";
import { MASTER_PRODUCTS, PRODUCT_CATEGORIES } from "../../data/products";

export function MitraProductsScreen() {
  const navigate = useNavigate();
  const [productList, setProductList] = useState(MASTER_PRODUCTS);
  const [selectedCategory, setSelectedCategory] = useState("Semua Produk");

  const toggleActive = (id: string) => {
    setProductList(
      productList.map((p) => (p.id === id ? { ...p, active: !p.active } : p))
    );
  };

  const filteredProducts = selectedCategory === "Semua Produk"
    ? productList
    : productList.filter(p => p.category === selectedCategory);

  return (
    <MobileLayout showBottomNav bottomNav={<MitraBottomNav />}>
      <div className="min-h-screen bg-[#F1F8E9] pb-20">
        {/* Top App Bar */}
        <div className="bg-white shadow-sm">
          <div className="p-4 flex items-center">
            <button onClick={() => navigate("/mitra/dashboard")} aria-label="Kembali ke dashboard" className="mr-3">
              <ArrowLeft size={24} className="text-gray-700" />
            </button>
            <h1 className="text-lg font-bold text-[#1B1B1B]">Kelola Produk</h1>
          </div>

          {/* Search Bar */}
          <div className="px-4 pb-3">
            <div className="flex items-center gap-2 px-4 py-2.5 bg-gray-100 rounded-xl">
              <Search size={20} className="text-gray-400" />
              <input
                type="text"
                placeholder="Cari produk..."
                className="flex-1 bg-transparent outline-none text-[#1B1B1B]"
              />
            </div>
          </div>

          {/* Category Filter Tabs */}
          <div className="px-4 pb-3 overflow-x-auto">
            <div className="flex gap-2 min-w-max">
              {PRODUCT_CATEGORIES.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-4 py-2 rounded-full text-sm font-semibold whitespace-nowrap ${
                    selectedCategory === cat
                      ? "bg-[#1B5E20] text-white"
                      : "bg-gray-100 text-gray-700"
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Product Grid */}
        <div className="p-4 grid grid-cols-2 gap-3">
          {filteredProducts.map((product) => (
            <div
              key={product.id}
              className="bg-white rounded-2xl overflow-hidden shadow-sm"
            >
              {/* Product Image */}
              <div
                onClick={() => navigate(`/mitra/add-product?id=${product.id}`)}
                className="cursor-pointer"
              >
                <div className="w-full h-32 bg-gray-100 overflow-hidden relative">
                  <ImageWithFallback
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover"
                  />
                  {/* Three-dot menu */}
                  <button aria-label="Menu produk" className="absolute top-2 right-2 w-7 h-7 bg-white/90 rounded-full flex items-center justify-center shadow">
                    <MoreVertical size={16} className="text-gray-700" />
                  </button>
                </div>

                <div className="p-3">
                  <h3 className="text-sm font-bold text-[#1B1B1B] mb-1 line-clamp-2">
                    {product.name}
                  </h3>
                  <p className="text-[#1B5E20] font-bold mb-1">
                    Rp {product.price.toLocaleString()}
                  </p>
                  <div className="flex items-center gap-1 text-xs text-gray-600 mb-2">
                    <Package size={12} />
                    <span>
                      Stok: {product.stock}
                      {product.stock === 0 && (
                        <span className="text-red-500"> (Habis)</span>
                      )}
                    </span>
                  </div>
                </div>
              </div>

              {/* Toggle Active/Inactive */}
              <div className="flex items-center justify-between px-3 pb-3 pt-1 border-t border-gray-100">
                <span className="text-xs text-gray-600">
                  {product.active ? "Aktif" : "Nonaktif"}
                </span>
                <button
                  onClick={() => toggleActive(product.id)}
                  className={`w-12 h-6 rounded-full p-0.5 transition-colors ${
                    product.active ? "bg-[#1B5E20]" : "bg-gray-300"
                  }`}
                >
                  <div
                    className={`w-5 h-5 rounded-full bg-white transition-transform ${
                      product.active ? "translate-x-6" : "translate-x-0"
                    }`}
                  ></div>
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* FAB - Add Product */}
        <button
          onClick={() => navigate("/mitra/add-product")}
          aria-label="Tambah produk"
          className="fixed bottom-20 right-4 w-14 h-14 bg-[#1B5E20] rounded-full shadow-lg flex items-center justify-center text-white hover:bg-[#145018] transition-colors z-10"
        >
          <Plus size={28} />
        </button>
      </div>
    </MobileLayout>
  );
}