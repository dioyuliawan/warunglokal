/**
 * FORMAT UTILITIES
 * Helper functions for formatting data consistently across the app
 */

/**
 * Format price to Indonesian Rupiah format
 * @param price - The price in number
 * @returns Formatted price string (e.g., "Rp 15.000")
 */
export function formatPrice(price: number): string {
  return `Rp ${price.toLocaleString("id-ID")}`;
}

/**
 * Format price with unit
 * @param price - The price in number
 * @param unit - The unit (e.g., "kg", "porsi")
 * @returns Formatted price with unit (e.g., "Rp 15.000/porsi")
 */
export function formatPriceWithUnit(price: number, unit?: string): string {
  const formattedPrice = formatPrice(price);
  return unit ? `${formattedPrice}/${unit}` : formattedPrice;
}

/**
 * Format distance
 * @param distance - Distance string (e.g., "300m", "1.2km")
 * @returns Formatted distance with "dari lokasimu" text
 */
export function formatDistance(distance: string): string {
  return `${distance} dari lokasimu`;
}

/**
 * Format time range
 * @param openTime - Opening time (e.g., "06.00")
 * @param closeTime - Closing time (e.g., "20.00")
 * @returns Formatted time range (e.g., "Buka 06.00 - 20.00")
 */
export function formatTimeRange(openTime: string, closeTime: string): string {
  return `Buka ${openTime} - ${closeTime}`;
}

/**
 * Format rating with review count
 * @param rating - Rating number
 * @param reviewCount - Number of reviews
 * @returns Formatted rating string (e.g., "4.8 (156 ulasan)")
 */
export function formatRating(rating: number, reviewCount: number): string {
  return `${rating.toFixed(1)} (${reviewCount} ulasan)`;
}

/**
 * Generate order ID
 * @returns Unique order ID (e.g., "WLK-2024-0042")
 */
export function generateOrderId(): string {
  const year = new Date().getFullYear();
  const randomNumber = Math.floor(Math.random() * 10000)
    .toString()
    .padStart(4, "0");
  return `WLK-${year}-${randomNumber}`;
}

/**
 * Format date to Indonesian format
 * @param date - Date object or string
 * @returns Formatted date (e.g., "24 Mei 2024")
 */
export function formatDate(date: Date | string): string {
  const dateObj = typeof date === "string" ? new Date(date) : date;
  return dateObj.toLocaleDateString("id-ID", {
    day: "numeric",
    month: "long",
    year: "numeric",
  });
}

/**
 * Format time to Indonesian format
 * @param date - Date object or string
 * @returns Formatted time (e.g., "14:30")
 */
export function formatTime(date: Date | string): string {
  const dateObj = typeof date === "string" ? new Date(date) : date;
  return dateObj.toLocaleTimeString("id-ID", {
    hour: "2-digit",
    minute: "2-digit",
  });
}

/**
 * Format relative time
 * @param date - Date object or string
 * @returns Relative time string (e.g., "2 jam yang lalu")
 */
export function formatRelativeTime(date: Date | string): string {
  const dateObj = typeof date === "string" ? new Date(date) : date;
  const now = new Date();
  const diffMs = now.getTime() - dateObj.getTime();
  const diffMins = Math.floor(diffMs / 60000);
  const diffHours = Math.floor(diffMins / 60);
  const diffDays = Math.floor(diffHours / 24);

  if (diffMins < 1) return "Baru saja";
  if (diffMins < 60) return `${diffMins} menit yang lalu`;
  if (diffHours < 24) return `${diffHours} jam yang lalu`;
  if (diffDays < 7) return `${diffDays} hari yang lalu`;

  return formatDate(dateObj);
}

/**
 * Truncate text with ellipsis
 * @param text - Text to truncate
 * @param maxLength - Maximum length before truncation
 * @returns Truncated text
 */
export function truncateText(text: string, maxLength: number): string {
  if (text.length <= maxLength) return text;
  return text.substring(0, maxLength) + "...";
}

/**
 * Format phone number to Indonesian format
 * @param phone - Phone number string
 * @returns Formatted phone number (e.g., "0812-3456-7890")
 */
export function formatPhoneNumber(phone: string): string {
  const cleaned = phone.replace(/\D/g, "");
  const match = cleaned.match(/^(\d{4})(\d{4})(\d+)$/);
  if (match) {
    return `${match[1]}-${match[2]}-${match[3]}`;
  }
  return phone;
}
