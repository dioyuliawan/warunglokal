/**
 * VALIDATION UTILITIES
 * Helper functions for validating user input
 */

/**
 * Validate email address
 * @param email - Email string to validate
 * @returns True if valid, false otherwise
 */
export function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

/**
 * Validate Indonesian phone number
 * @param phone - Phone number string to validate
 * @returns True if valid, false otherwise
 */
export function isValidPhoneNumber(phone: string): boolean {
  // Indonesian phone numbers: 08xx-xxxx-xxxx or +628xx-xxxx-xxxx
  const phoneRegex = /^(\+62|62|0)[8][0-9]{8,11}$/;
  const cleaned = phone.replace(/[\s-]/g, "");
  return phoneRegex.test(cleaned);
}

/**
 * Validate password strength
 * @param password - Password string to validate
 * @returns Object with isValid flag and error message
 */
export function validatePassword(password: string): {
  isValid: boolean;
  error?: string;
} {
  if (password.length < 6) {
    return { isValid: false, error: "Password minimal 6 karakter" };
  }
  if (password.length > 50) {
    return { isValid: false, error: "Password maksimal 50 karakter" };
  }
  return { isValid: true };
}

/**
 * Validate required field
 * @param value - Value to validate
 * @param fieldName - Name of the field (for error message)
 * @returns Object with isValid flag and error message
 */
export function validateRequired(
  value: string | number | undefined | null,
  fieldName: string
): { isValid: boolean; error?: string } {
  if (value === undefined || value === null || value === "") {
    return { isValid: false, error: `${fieldName} harus diisi` };
  }
  return { isValid: true };
}

/**
 * Validate minimum length
 * @param value - String to validate
 * @param minLength - Minimum length required
 * @param fieldName - Name of the field (for error message)
 * @returns Object with isValid flag and error message
 */
export function validateMinLength(
  value: string,
  minLength: number,
  fieldName: string
): { isValid: boolean; error?: string } {
  if (value.length < minLength) {
    return {
      isValid: false,
      error: `${fieldName} minimal ${minLength} karakter`,
    };
  }
  return { isValid: true };
}

/**
 * Validate maximum length
 * @param value - String to validate
 * @param maxLength - Maximum length allowed
 * @param fieldName - Name of the field (for error message)
 * @returns Object with isValid flag and error message
 */
export function validateMaxLength(
  value: string,
  maxLength: number,
  fieldName: string
): { isValid: boolean; error?: string } {
  if (value.length > maxLength) {
    return {
      isValid: false,
      error: `${fieldName} maksimal ${maxLength} karakter`,
    };
  }
  return { isValid: true };
}

/**
 * Validate numeric input
 * @param value - Value to validate
 * @param fieldName - Name of the field (for error message)
 * @returns Object with isValid flag and error message
 */
export function validateNumeric(
  value: string | number,
  fieldName: string
): { isValid: boolean; error?: string } {
  const numValue = typeof value === "string" ? parseFloat(value) : value;
  if (isNaN(numValue)) {
    return { isValid: false, error: `${fieldName} harus berupa angka` };
  }
  return { isValid: true };
}

/**
 * Validate positive number
 * @param value - Value to validate
 * @param fieldName - Name of the field (for error message)
 * @returns Object with isValid flag and error message
 */
export function validatePositive(
  value: number,
  fieldName: string
): { isValid: boolean; error?: string } {
  if (value <= 0) {
    return {
      isValid: false,
      error: `${fieldName} harus lebih besar dari 0`,
    };
  }
  return { isValid: true };
}

/**
 * Validate price format
 * @param price - Price to validate
 * @returns Object with isValid flag and error message
 */
export function validatePrice(price: number): {
  isValid: boolean;
  error?: string;
} {
  if (price < 0) {
    return { isValid: false, error: "Harga tidak boleh negatif" };
  }
  if (price > 100000000) {
    // 100 million max
    return { isValid: false, error: "Harga terlalu besar" };
  }
  return { isValid: true };
}

/**
 * Validate stock quantity
 * @param stock - Stock quantity to validate
 * @returns Object with isValid flag and error message
 */
export function validateStock(stock: number): {
  isValid: boolean;
  error?: string;
} {
  if (stock < 0) {
    return { isValid: false, error: "Stok tidak boleh negatif" };
  }
  if (stock > 999999) {
    return { isValid: false, error: "Stok terlalu besar" };
  }
  return { isValid: true };
}

/**
 * Sanitize input string (remove special characters)
 * @param input - String to sanitize
 * @returns Sanitized string
 */
export function sanitizeInput(input: string): string {
  return input.replace(/[<>]/g, "");
}

/**
 * Validate warung name
 * @param name - Warung name to validate
 * @returns Object with isValid flag and error message
 */
export function validateWarungName(name: string): {
  isValid: boolean;
  error?: string;
} {
  if (name.length < 3) {
    return { isValid: false, error: "Nama warung minimal 3 karakter" };
  }
  if (name.length > 50) {
    return { isValid: false, error: "Nama warung maksimal 50 karakter" };
  }
  return { isValid: true };
}

/**
 * Validate product name
 * @param name - Product name to validate
 * @returns Object with isValid flag and error message
 */
export function validateProductName(name: string): {
  isValid: boolean;
  error?: string;
} {
  if (name.length < 2) {
    return { isValid: false, error: "Nama produk minimal 2 karakter" };
  }
  if (name.length > 100) {
    return { isValid: false, error: "Nama produk maksimal 100 karakter" };
  }
  return { isValid: true };
}

/**
 * Validate time range (opening time must be before closing time)
 * @param openTime - Opening time in HH:MM format
 * @param closeTime - Closing time in HH:MM format
 * @returns Object with isValid flag and error message
 */
export function validateTimeRange(
  openTime: string,
  closeTime: string
): { isValid: boolean; error?: string } {
  if (!openTime || !closeTime) {
    return { isValid: false, error: "Jam buka dan tutup wajib diisi" };
  }

  // Convert to minutes for comparison
  const [openHour, openMin] = openTime.split(":").map(Number);
  const [closeHour, closeMin] = closeTime.split(":").map(Number);

  const openMinutes = openHour * 60 + openMin;
  const closeMinutes = closeHour * 60 + closeMin;

  if (openMinutes >= closeMinutes) {
    return { isValid: false, error: "Jam buka harus lebih awal dari jam tutup" };
  }

  return { isValid: true };
}

/**
 * Validate dropdown selection
 * @param value - Selected value
 * @param fieldName - Name of the field (for error message)
 * @returns Object with isValid flag and error message
 */
export function validateSelection(
  value: string,
  fieldName: string
): { isValid: boolean; error?: string } {
  if (!value || value === "" || value === "undefined") {
    return { isValid: false, error: `${fieldName} wajib dipilih` };
  }
  return { isValid: true };
}

/**
 * Format phone number for display (add spaces for readability)
 * @param phone - Phone number to format
 * @returns Formatted phone number
 */
export function formatPhoneDisplay(phone: string): string {
  const cleaned = phone.replace(/[\s-]/g, "");

  // Format: 0812 3456 7890
  if (cleaned.startsWith("0")) {
    return cleaned.replace(/(\d{4})(\d{4})(\d{4})/, "$1 $2 $3");
  }

  // Format: +62 812 3456 7890
  if (cleaned.startsWith("+62")) {
    return cleaned.replace(/(\+62)(\d{3})(\d{4})(\d{4})/, "$1 $2 $3 $4");
  }

  return phone;
}
