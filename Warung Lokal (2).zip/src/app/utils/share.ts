/**
 * Share Utility Functions
 * Handle native share API with fallback to copy link
 */

interface ShareData {
  title: string;
  text: string;
  url: string;
}

/**
 * Share content using native share API or fallback to copy link
 * @param data Share data (title, text, url)
 * @returns Promise<boolean> - true if shared/copied successfully
 */
export async function shareContent(data: ShareData): Promise<boolean> {
  try {
    // Check if native share API is available
    if (navigator.share) {
      await navigator.share(data);
      return true;
    } else {
      // Fallback: copy link to clipboard
      await navigator.clipboard.writeText(data.url);
      return true;
    }
  } catch (error) {
    // User cancelled or error occurred
    console.error("Error sharing:", error);
    return false;
  }
}

/**
 * Share a warung
 * @param warungId Warung ID
 * @param warungName Warung name
 * @returns Promise<boolean>
 */
export async function shareWarung(
  warungId: string,
  warungName: string
): Promise<boolean> {
  const url = `${window.location.origin}/warung/${warungId}`;
  return shareContent({
    title: warungName,
    text: `Check out ${warungName} on Warung Lokal!`,
    url,
  });
}

/**
 * Share a product
 * @param productId Product ID
 * @param productName Product name
 * @param warungName Warung name
 * @returns Promise<boolean>
 */
export async function shareProduct(
  productId: string,
  productName: string,
  warungName: string
): Promise<boolean> {
  const url = `${window.location.origin}/product/${productId}`;
  return shareContent({
    title: productName,
    text: `Check out ${productName} from ${warungName} on Warung Lokal!`,
    url,
  });
}

/**
 * Copy link to clipboard (manual fallback)
 * @param url URL to copy
 * @returns Promise<boolean>
 */
export async function copyLink(url: string): Promise<boolean> {
  try {
    await navigator.clipboard.writeText(url);
    return true;
  } catch (error) {
    console.error("Error copying link:", error);
    return false;
  }
}
