/**
 * Vibration Utility Functions
 * Provide haptic feedback on mobile devices
 */

/**
 * Check if vibration API is supported
 */
export function isVibrationSupported(): boolean {
  return "vibrate" in navigator;
}

/**
 * Light vibration (quick tap feedback)
 */
export function vibrateLight() {
  if (isVibrationSupported()) {
    navigator.vibrate(10);
  }
}

/**
 * Medium vibration (button press feedback)
 */
export function vibrateMedium() {
  if (isVibrationSupported()) {
    navigator.vibrate(20);
  }
}

/**
 * Heavy vibration (important action feedback)
 */
export function vibrateHeavy() {
  if (isVibrationSupported()) {
    navigator.vibrate(50);
  }
}

/**
 * Success vibration pattern
 */
export function vibrateSuccess() {
  if (isVibrationSupported()) {
    navigator.vibrate([10, 50, 10]);
  }
}

/**
 * Error vibration pattern
 */
export function vibrateError() {
  if (isVibrationSupported()) {
    navigator.vibrate([50, 100, 50]);
  }
}

/**
 * Custom vibration pattern
 * @param pattern Array of durations in ms
 */
export function vibratePattern(pattern: number[]) {
  if (isVibrationSupported()) {
    navigator.vibrate(pattern);
  }
}
