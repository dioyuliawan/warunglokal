# 📁 STRUKTUR KODE WARLOK

Dokumentasi lengkap struktur kode untuk memudahkan pengembangan dan maintenance.

---

## 📂 Struktur Direktori

```
src/app/
├── components/          # Komponen React
│   ├── shared/         # Komponen reusable untuk seluruh app
│   ├── customer/       # Komponen khusus customer
│   ├── mitra/          # Komponen khusus mitra
│   ├── figma/          # Komponen dari Figma import
│   └── ui/             # UI primitives (shadcn/ui)
│
├── screens/            # Screen/Page components
│   ├── customer/       # Customer screens
│   ├── mitra/          # Mitra screens
│   └── admin/          # Admin screens
│
├── context/            # React Context untuk state management
│   └── CartContext.tsx # State management keranjang belanja
│
├── data/               # Data dan business logic
│   ├── types.ts        # TypeScript type definitions
│   ├── products.ts     # Master data products (akan dipecah)
│   └── warungs/        # Data per warung (terorganisir)
│       ├── index.ts    # Export semua warung + helper functions
│       └── warung-bu-tini.ts  # Data Warung Bu Tini
│
├── constants/          # Konstanta aplikasi
│   ├── colors.ts       # Color palette
│   └── app.ts          # App config, paths, dll
│
├── utils/              # Utility functions
│   ├── format.ts       # Format harga, tanggal, dll
│   └── validation.ts   # Validasi input
│
├── hooks/              # Custom React hooks
│   ├── useDebounce.ts  # Debounce hook
│   └── useLocalStorage.ts # LocalStorage sync hook
│
├── styles/             # Global styles
│   ├── theme.css       # Theme variables (Tailwind v4)
│   └── fonts.css       # Font imports
│
├── routes.tsx          # Route configuration
└── App.tsx             # Root component

```

---

## 🎨 Komponen Reusable

### 1. **WarungCard** (`components/shared/WarungCard.tsx`)

Komponen untuk menampilkan kartu warung.

**Props:**
```typescript
interface WarungCardProps {
  warung: WarungData;           // Data warung
  onClick: () => void;          // Handler klik
  variant?: "default" | "compact" | "list";  // Varian tampilan
  showDistance?: boolean;       // Tampilkan jarak
  showRating?: boolean;         // Tampilkan rating
  showStatus?: boolean;         // Tampilkan status buka/tutup
  className?: string;           // Custom className
}
```

**Cara pakai:**
```tsx
import { WarungCard } from "@/components/shared/WarungCard";

<WarungCard 
  warung={warungData}
  onClick={() => navigate(`/warung/${warungData.id}`)}
  variant="list"
  showDistance
  showRating
  showStatus
/>
```

---

### 2. **ProductCard** (`components/shared/ProductCard.tsx`)

Komponen untuk menampilkan kartu produk.

**Props:**
```typescript
interface ProductCardProps {
  product: Product;             // Data produk
  onClick: () => void;          // Handler klik
  onAddToCart?: (product: Product) => void;  // Handler tambah ke cart
  showAddButton?: boolean;      // Tampilkan tombol tambah
  variant?: "grid" | "list";    // Varian tampilan
  className?: string;           // Custom className
}
```

**Cara pakai:**
```tsx
import { ProductCard } from "@/components/shared/ProductCard";

<ProductCard 
  product={productData}
  onClick={() => navigate(`/product/${productData.id}`)}
  onAddToCart={(product) => addItem(product, 1)}
  showAddButton
  variant="grid"
/>
```

---

### 3. **EmptyState** (`components/shared/EmptyState.tsx`)

Komponen untuk empty state dengan icon dan action button.

**Props:**
```typescript
interface EmptyStateProps {
  icon: ReactNode;              // Icon component
  title: string;                // Judul
  message?: string;             // Pesan (opsional)
  actionLabel?: string;         // Label tombol (opsional)
  onAction?: () => void;        // Handler tombol (opsional)
  className?: string;           // Custom className
}
```

**Cara pakai:**
```tsx
import { EmptyState } from "@/components/shared/EmptyState";
import { ShoppingBag } from "lucide-react";

<EmptyState 
  icon={<ShoppingBag size={64} />}
  title="Keranjang masih kosong"
  message="Yuk, mulai belanja dari warung terdekatmu"
  actionLabel="Mulai Belanja"
  onAction={() => navigate("/home")}
/>
```

---

## 🎨 Konstanta & Konfigurasi

### **Colors** (`constants/colors.ts`)

Semua warna aplikasi terpusat di satu file.

```typescript
import { COLORS } from "@/constants/colors";

// Primary colors
COLORS.primary.main        // #1B5E20 - Dark Green
COLORS.primary.light       // #43A047 - Light Green
COLORS.primary.lighter     // #F1F8E9 - Very Light Green

// Status colors
COLORS.status.success      // Green - Buka
COLORS.status.warning      // Orange - Istirahat
COLORS.status.error        // Red - Tutup

// Neutral colors
COLORS.neutral.black       // #1B1B1B - Text
COLORS.neutral.gray[500]   // Gray shades
COLORS.neutral.white       // #FFFFFF
```

---

### **App Config** (`constants/app.ts`)

Konfigurasi aplikasi terpusat.

```typescript
import { APP_CONFIG, NAVIGATION_PATHS, DELIVERY_COSTS } from "@/constants/app";

// App info
APP_CONFIG.name            // "Warlok — Warung Lokal"
APP_CONFIG.version         // "1.0.0"
APP_CONFIG.adminPassword   // "admin2024"

// Navigation paths
NAVIGATION_PATHS.customer.home      // "/home"
NAVIGATION_PATHS.mitra.dashboard    // "/mitra/dashboard"
NAVIGATION_PATHS.admin.dashboard    // "/admin/dashboard"

// Delivery costs
DELIVERY_COSTS.antarSendiri   // 5000
DELIVERY_COSTS.ojekOnline     // 12000
DELIVERY_COSTS.ambilSendiri   // 0
```

---

## 🛠️ Utility Functions

### **Format Utils** (`utils/format.ts`)

Fungsi untuk format data.

```typescript
import { 
  formatPrice, 
  formatPriceWithUnit,
  formatDistance,
  formatRating,
  generateOrderId,
  formatDate,
  formatRelativeTime
} from "@/utils/format";

// Format harga
formatPrice(15000)                    // "Rp 15.000"
formatPriceWithUnit(15000, "porsi")   // "Rp 15.000/porsi"

// Format jarak
formatDistance("300m")                // "300m dari lokasimu"

// Format rating
formatRating(4.8, 156)                // "4.8 (156 ulasan)"

// Generate order ID
generateOrderId()                     // "WLK-2024-0042"

// Format tanggal
formatDate(new Date())                // "24 Mei 2024"
formatRelativeTime(new Date())        // "2 jam yang lalu"
```

---

### **Validation Utils** (`utils/validation.ts`)

Fungsi untuk validasi input.

```typescript
import { 
  isValidEmail,
  isValidPhoneNumber,
  validatePassword,
  validateRequired,
  validatePrice,
  validateStock
} from "@/utils/validation";

// Validasi email
isValidEmail("user@example.com")      // true

// Validasi nomor HP
isValidPhoneNumber("081234567890")    // true

// Validasi password
validatePassword("pass123")           
// { isValid: true } atau { isValid: false, error: "..." }

// Validasi harga
validatePrice(15000)                  
// { isValid: true }

// Validasi stok
validateStock(50)                     
// { isValid: true }
```

---

## 🪝 Custom Hooks

### **useDebounce** (`hooks/useDebounce.ts`)

Debounce untuk input yang cepat berubah.

```typescript
import { useDebounce } from "@/hooks/useDebounce";

const [searchQuery, setSearchQuery] = useState("");
const debouncedQuery = useDebounce(searchQuery, 500);

// debouncedQuery hanya update setelah 500ms user berhenti mengetik
useEffect(() => {
  // Lakukan search dengan debouncedQuery
}, [debouncedQuery]);
```

---

### **useLocalStorage** (`hooks/useLocalStorage.ts`)

Sync state dengan localStorage.

```typescript
import { useLocalStorage } from "@/hooks/useLocalStorage";

const [favorites, setFavorites] = useLocalStorage<string[]>('favorites', []);

// Otomatis tersimpan di localStorage
setFavorites([...favorites, newWarungId]);
```

---

## 📊 Data Management

### **Struktur Data Warung**

File baru: `data/warungs/warung-bu-tini.ts`

```typescript
export const WARUNG_BU_TINI: WarungData = {
  id: "1",
  name: "Warung Bu Tini",
  // ... data lengkap
};

export const PRODUCTS_WARUNG_BU_TINI: Product[] = [
  // ... array produk
];
```

### **Helper Functions** (`data/warungs/index.ts`)

```typescript
import { 
  getWarungById,
  getProductsByWarungId,
  getAllProductsByWarungId,
  getProductById,
  getWarungsByCategory,
  getOpenWarungs,
  searchWarungsAndProducts
} from "@/data/warungs";

// Get warung by ID
const warung = getWarungById("1");

// Get products dari warung tertentu (hanya yang aktif)
const products = getProductsByWarungId("1");

// Get semua produk (termasuk non-aktif)
const allProducts = getAllProductsByWarungId("1");

// Get product by ID
const product = getProductById("w1_p1");

// Get warungs berdasarkan kategori
const foodWarungs = getWarungsByCategory("Makanan & Minuman");

// Get hanya warung yang buka
const openWarungs = getOpenWarungs();

// Search warung dan produk
const results = searchWarungsAndProducts("ayam");
// Returns: { warungs: [...], products: [...] }
```

---

## 🛒 Cart Context

### **CartContext** (`context/CartContext.tsx`)

State management untuk keranjang belanja.

```typescript
import { useCart } from "@/context/CartContext";

const { 
  items,              // Array item di cart
  warungId,           // ID warung saat ini di cart
  warungName,         // Nama warung saat ini
  addItem,            // Tambah item ke cart
  removeItem,         // Hapus item dari cart
  updateQuantity,     // Update jumlah item
  clearCart,          // Kosongkan cart
  getTotalPrice,      // Hitung total harga
  getItemCount        // Hitung total item
} = useCart();

// Tambah produk ke cart
addItem(product, quantity, note, warungId, warungName);

// Update quantity
updateQuantity(productId, 1);  // Tambah 1
updateQuantity(productId, -1); // Kurang 1

// Hapus item
removeItem(productId);

// Get total
const total = getTotalPrice();      // Total harga
const itemCount = getItemCount();   // Total item
```

---

## 🎯 Cara Menambah Warung Baru

1. **Buat file warung baru:**
   ```
   src/app/data/warungs/warung-pak-joko.ts
   ```

2. **Copy struktur dari `warung-bu-tini.ts`:**
   ```typescript
   export const WARUNG_PAK_JOKO: WarungData = {
     id: "7",  // ID unik baru
     name: "Warung Pak Joko",
     // ... isi data lengkap
   };

   export const PRODUCTS_PAK_JOKO: Product[] = [
     {
       id: "w7_p1",  // Format: w[warungId]_p[productNumber]
       warungId: "7",
       name: "Nasi Goreng Spesial",
       // ... data produk
     }
   ];
   ```

3. **Import di `data/warungs/index.ts`:**
   ```typescript
   import { WARUNG_PAK_JOKO, PRODUCTS_PAK_JOKO } from "./warung-pak-joko";
   
   export const ALL_WARUNGS: WarungData[] = [
     // ... warungs lain
     WARUNG_PAK_JOKO,  // Tambahkan di sini
   ];

   export const ALL_PRODUCTS: Product[] = [
     // ... products lain
     ...PRODUCTS_PAK_JOKO,  // Tambahkan di sini
   ];
   ```

4. **Selesai!** Warung baru otomatis muncul di semua screen.

---

## 🎯 Cara Menambah Produk ke Warung Existing

1. **Buka file warung:** `data/warungs/warung-bu-tini.ts`

2. **Tambah produk baru di array:**
   ```typescript
   export const PRODUCTS_WARUNG_BU_TINI: Product[] = [
     // ... produk existing
     {
       id: "w1_p7",  // ID urut berikutnya
       warungId: "1",
       name: "Soto Ayam",
       price: 18000,
       unit: "porsi",
       stock: 25,
       description: "Soto ayam dengan kuah bening dan bumbu kuning...",
       active: true,
       image: "https://...",
       category: "Nasi Bungkus",
     },
   ];
   ```

3. **Selesai!** Produk langsung muncul di halaman warung.

---

## 🎨 Cara Ubah Warna Tema

Edit file `constants/colors.ts`:

```typescript
export const COLORS = {
  primary: {
    main: "#1B5E20",      // Ubah ke warna hijau lain
    light: "#43A047",     // Ubah sesuai kebutuhan
    lighter: "#F1F8E9",
  },
  // ...
}
```

Atau langsung edit di `src/styles/theme.css` untuk Tailwind v4:

```css
@theme {
  --color-primary: #1B5E20;
  --color-primary-light: #43A047;
}
```

---

## 📝 Best Practices

### ✅ DO (Lakukan)
- ✅ Gunakan komponen shared (`WarungCard`, `ProductCard`, dll)
- ✅ Gunakan utility functions untuk format data
- ✅ Gunakan konstanta dari `constants/` folder
- ✅ Pisahkan data per warung di folder `warungs/`
- ✅ Gunakan TypeScript types dari `data/types.ts`
- ✅ Gunakan `CartContext` untuk cart management
- ✅ Tambahkan comment di atas function untuk dokumentasi

### ❌ DON'T (Jangan)
- ❌ Hardcode warna langsung di komponen
- ❌ Hardcode harga/data langsung di screen
- ❌ Duplikasi kode yang sama di banyak tempat
- ❌ Langsung edit `ALL_WARUNGS` - edit file warung individual
- ❌ Buat state lokal untuk cart - gunakan `CartContext`
- ❌ Format harga manual - gunakan `formatPrice()`

---

## 🔍 Troubleshooting

### Cart tidak sinkron antar screen?
✅ Pastikan semua screen menggunakan `useCart()` hook

### Warna tidak konsisten?
✅ Gunakan `COLORS` dari `constants/colors.ts`

### Product tidak muncul di warung?
✅ Cek `warungId` di product data harus match dengan warung ID
✅ Cek `active: true` di product data

### Data warung tercampur?
✅ Setiap product harus punya `warungId` yang unik
✅ Gunakan `getProductsByWarungId()` untuk filter

---

## 📞 Kontak

Jika ada pertanyaan atau butuh bantuan, silakan buka issue atau hubungi tim development.

---

**Happy Coding! 🚀**
